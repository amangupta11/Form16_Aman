//
//  FireBaseManager.swift
//  Medtronic
//
//  Created by Praveen Ambekar on 8/3/17.
//  Copyright © 2017 Medtronic. All rights reserved.
//

import UIKit
import Firebase

struct AnalyticsPlistStr{
    static let dev = "GoogleService-Info-DEV"
    static let qa = "GoogleService-Info-QA"
    static let stg = "GoogleService-Info-STG"
    static let prod = "GoogleService-Info-PRD"
}

class FireBaseManager: NSObject{
     func setUpFireBase(){
        #if MED_TARGET_DEVLOPMENT
            let firebasePlistFileName = AnalyticsPlistStr.dev
        #elseif MED_TARGET_TESTING
            let firebasePlistFileName = AnalyticsPlistStr.qa
        #elseif MED_TARGET_STAGING
            let firebasePlistFileName = AnalyticsPlistStr.stg
        #elseif MED_TARGET_PRODUCTION
            let firebasePlistFileName = AnalyticsPlistStr.prod
        #endif
        let filePathStr = NSBundle.mainBundle().pathForResource(firebasePlistFileName, ofType: "plist")
        let fireBaseOptions = FIROptions(contentsOfFile: filePathStr)
        FIRApp.configureWithOptions(fireBaseOptions)
    }
    func getBundleVersion() -> Int{
        var bdlVer = 0
        let dictionary = NSBundle.mainBundle().infoDictionary!
        if let bundleVerStr = dictionary[bundleConstants.BundleVersion] as? Int{
            bdlVer = bundleVerStr
        }
        return bdlVer
    }
}
