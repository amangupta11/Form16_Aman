//
//  MEDOnCallCardioDiagnosisVC.swift
//  Medtronic
//
//  Created by Praveen Ambekar on 4/5/17.
//  Copyright © 2017 Medtronic. All rights reserved.
//

import UIKit

class MEDOnCallCardioDiagnosisVC: MEDBaseViewController,MEDImagePagerDelegate,MEDImagePagerDataSource {
    
    struct StringConstants {
        static  var CellIdentifier = "InfractAreaCell"
        static  let GenderMaleText = "Male"
        static  let GenderFemaleText = "Female"
        static let OtherCommentsLabel = "Others/Comments"
        static let ScreenTitle = "Case Details"
        static let UnclearECGDefaultComment = "Please provide the reason for not being able to diagnose. e.g Atypical case capture ECG again and send, Capture vitals again etc."
        static let NotAStemiConfirmationMessage = "Are you sure you want to diagnose this case as Not a STEMI?"
        static let stemiConfirmationMessage = "Are you sure you want to diagnose this case as STEMI?"
        static let ConfrimationTitle = "Confirmation"
    }
    struct KillipScoreValues {
        static let first = "I"
        static let second = "II"
        static let third = "III"
        static let fourth = "IV"
    }
    enum AlertViewTags: Int {
        case UnclearECG = 101, SuccessAction
        case AlreadyReviewdTag = 1001
    }
    enum BottomButtonTags: Int {
        case UnclearECG = 101, NotAStemi, Stemi
    }
    
    private var infractAreaRowHeight = 60
    private var defaultInfractAreaContainerViewHeight = 250
    private var defaultScrollViewContainerViewHeight = 750//680
    
    @IBOutlet weak var patientHistoryContatinerVIew: UIView!
    @IBOutlet weak var patientInfoContainerView: UIView!
    @IBOutlet weak var stemiButton: UIButton!
    @IBOutlet weak var unclearECGButton: UIButton!
    @IBOutlet weak var notAStemiButton: UIButton!
    @IBOutlet weak var ecgImagePagerView: MEDImagePager!
    @IBOutlet weak var patientNameLabel: UILabel!
    @IBOutlet weak var killipScoreValueLabel: UILabel!
    @IBOutlet weak var sp02ValueLabel: UILabel!
    @IBOutlet weak var temperatureValueLabel: UILabel!
    @IBOutlet weak var pulseValueLabel: UILabel!
    @IBOutlet weak var diastolicValueLabel: UILabel!
    @IBOutlet weak var systolicValueLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var patientAgeLabel: UILabel!
    @IBOutlet weak var patientCaseIDLbl: UILabel!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var editInfarctAreaButtn: UIButton!
    @IBOutlet weak var ecgDownloadingSyncButton: UIButton!
    @IBOutlet weak var infractAreaContainerViewHeight: NSLayoutConstraint!
    @IBOutlet weak var infractAreaTableView: UITableView!
    @IBOutlet weak var scrollViewContainerViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var infractAreaContainerView: UIView!
    var infractAreaArray: NSMutableArray? = nil
    var otherCommentsNumberOfLines: Int = 0
    var isOtherComments = false
    var otherCommentsText = ""
    var ecgImage:UIImage!
    var selectedButtonTag: Int? = nil
    var alertTag: Int?
    var alertController: UIAlertController? = nil
    
    override func viewDidLoad() {
        self.ecgImage = UIImage(named: ImageConstants.kDefaultECGImage)
        
        super.viewDidLoad()
        initialSetUp("")
        startTimer()
    }
    override func initialSetUp(bgImage: String) {
       // self.setTapGestureForView()
        setNavigationBackButtonImage()
        self.loadInfractAreas()
       // setUpECGImageContainerView()
        infractAreaTableView.scrollEnabled = false
        updateUI()
        retryButtonClick()
        rotateView(self.ecgDownloadingSyncButton)
      //  setTapActionOnImageView()
        self.scrollView.showsHorizontalScrollIndicator = false
        self.scrollView.showsVerticalScrollIndicator = false
        self.patientInfo?.patientHistory?.uncleatECGComments = nil
        self.editInfarctAreaButtn.alpha = 0.3
        self.infractAreaTableView.allowsSelection = false
        
        
    }
    func retryButtonClick () {
        getAWSBucketInformation()
    }
       func downloadECGImage() {
        enableBottomButtons(false)
        if NetworkUtil.isConnected() == false {
            showRetryButton(false, isRotating: false)
            return
        }
        if(patientInfo?.ecgInfo?.ecgURL != nil) {
            
            showRetryButton(false, isRotating: true)
            let downloadURL = String(format:"%@/%@/%@", ecgPath, (patientInfo?.caseID)!, (patientInfo?.ecgInfo?.ecgFileName)!)
            let fileName = String(format: "%@", (patientInfo?.ecgInfo?.ecgFileName)!)
            downloadImage(patientInfo!, imageURL: NSURL.fileURLWithPath(NSTemporaryDirectory().stringByAppendingString(fileName)), s3DownloadKeyName:downloadURL)
        }
    }
    func showRetryButton(isHide: Bool, isRotating: Bool) {
        self.ecgDownloadingSyncButton.hidden = isHide
        if isRotating == true {
            rotateView(self.ecgDownloadingSyncButton)
            self.ecgDownloadingSyncButton.userInteractionEnabled = false
        } else {
            self.ecgDownloadingSyncButton.userInteractionEnabled = true
            stopRotatingView(self.ecgDownloadingSyncButton)
        }
    }
    func rotateView(view: UIView, duration: Double = 1) {
        if view.layer.animationForKey(kRotationAnimationKey) == nil {
            let rotationAnimation = CABasicAnimation(keyPath: "transform.rotation")
            
            rotationAnimation.fromValue = 0.0
            rotationAnimation.toValue = Float(M_PI * 2.0)
            rotationAnimation.duration = duration
            rotationAnimation.repeatCount = Float.infinity
            view.layer.addAnimation(rotationAnimation, forKey: kRotationAnimationKey)
        }
    }
    func stopRotatingView(view: UIView) {
        if view.layer.animationForKey(kRotationAnimationKey) != nil {
            view.layer.removeAnimationForKey(kRotationAnimationKey)
        }
    }
    func handleDownloadError() {
        showRetryButton(false, isRotating: false)
    }

    func enableBottomButtons(enabled: Bool){
        self.unclearECGButton.enabled = enabled
        self.notAStemiButton.enabled = enabled
        self.stemiButton.enabled = enabled
        
        if enabled == false{
            self.unclearECGButton.alpha = 0.4
            self.notAStemiButton.alpha = 0.4
            self.stemiButton.alpha = 0.4
        }else{
            self.unclearECGButton.alpha = 1.0
            self.notAStemiButton.alpha = 1.0
            self.stemiButton.alpha = 1.0
            
        }
    }
    
    func loadInfractAreas() {
        let metaDataPList: NSDictionary!
        if let path = FileUtility.getPlistPath() {
            metaDataPList = NSDictionary(contentsOfFile: path)
            self.infractAreaArray = metaDataPList.objectForKey("InfractAreaDetails")?.mutableCopy() as? NSMutableArray
        }
        var i = 0
        let updatedArray = NSMutableArray()
        while i < 9 {
            if(self.checkIfInfractAreaSelected(i)) {
                updatedArray.addObject((self.infractAreaArray?.objectAtIndex(i))!)
            }
            i += 1
        }
        self.infractAreaArray = updatedArray
    }
    
    func checkIfInfractAreaSelected(index: Int) -> Bool {
        if(index == 0) {
            return patientInfo?.patientHistory!.anteroseptal != false ? true:false
        } else if(index == 1) {
            return patientInfo?.patientHistory!.anterior != false ? true:false
        } else if(index == 2) {
            return patientInfo?.patientHistory!.lateral != false ? true:false
        } else if(index == 3) {
            return patientInfo?.patientHistory!.extensiveanterolateral != false ? true:false
        } else if(index == 4) {
            return patientInfo?.patientHistory!.inferior != false ? true:false
        } else if(index == 5) {
            return patientInfo?.patientHistory!.posterior != false ? true:false
        } else if(index == 6) {
            return patientInfo?.patientHistory!.rightsided != false ? true:false
        } else if(index == 7) {
            return patientInfo?.patientHistory!.leftmainstem != false ? true:false
        } else if(index == 8) {
            if patientInfo?.patientHistory!.others == true {
                self.isOtherComments = true
                if self.patientInfo!.patientHistory!.otherscomments != nil {
                    otherCommentsText = self.patientInfo!.patientHistory!.otherscomments!
                }
            } else {
                self.isOtherComments = false
                otherCommentsNumberOfLines = 0
            }
            return patientInfo?.patientHistory!.others != false ? true:false
        }
        return false
    }

    
    override func viewDidLayoutSubviews() {
        self.infractAreaContainerViewHeight.constant = CGFloat(defaultInfractAreaContainerViewHeight) + CGFloat((self.infractAreaArray!.count - 1)*infractAreaRowHeight) + CGFloat(otherCommentsNumberOfLines * 15)
        self.infractAreaContainerView.frame.size.height = self.infractAreaContainerViewHeight.constant
        print("infract area container height == \(self.infractAreaContainerViewHeight.constant)")
        
        self.scrollViewContainerViewHeightConstraint.constant =  CGFloat(defaultScrollViewContainerViewHeight) + CGFloat((self.infractAreaArray!.count - 1)*infractAreaRowHeight) + CGFloat(otherCommentsNumberOfLines * 15)
        
        self.scrollView.contentSize.height = self.scrollViewContainerViewHeightConstraint.constant
        addShadow(self.patientInfoContainerView)
        addShadow(self.patientHistoryContatinerVIew)
        addShadow(self.infractAreaContainerView)
    }
    override func viewDidDisappear(animated: Bool) {
        defaultInfractAreaContainerViewHeight = 250
        defaultScrollViewContainerViewHeight = 750
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    // MARK: - MEDImagePagerDataSource
    func arrayWithImages(pager: MEDImagePager!) -> [AnyObject]! {
        return [
            self.ecgImage,
        ]
    }
    func contentModeForImage(image: UInt, inPager pager: MEDImagePager!) -> UIViewContentMode {
        return UIViewContentMode.ScaleToFill
        
    }
    func captionForImageAtIndex(index: UInt, inPager pager: MEDImagePager!) -> String! {
        let captionText = "12Lead ECG"
        return captionText
    }
    func dateCaptionForImageAtIndex(index: UInt, inPager pager: MEDImagePager!) -> String! {
        let datecaptionText = "20-Jun-2016 10:10AM"
        return datecaptionText
    }
 
    func getNumberOfLines(label: UILabel) -> Int {
        var lineCount = 0
        let textSize = CGSizeMake(label.frame.size.width, CGFloat(Float.infinity))
        let rHeight = lroundf(Float(label.sizeThatFits(textSize).height))
        let charSize = lroundf(Float(label.font.lineHeight))
        lineCount = rHeight/charSize
        return lineCount
    }
    func updateECGImage() {
        showRetryButton(true, isRotating: false)
        enableBottomButtons(true)
        self.ecgImage = UIImage(contentsOfFile: (patientInfo?.ecgInfo?.localPath)!)
        self.editInfarctAreaButtn.alpha = 1.0
        self.ecgImagePagerView.reloadData()
    }

    func handleSuccessForBottomButtonAction () {
        //navigate to home
        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        let title = "Success"
        let message = NSLocalizedString("CASE_DIAGNOSED_SUCESSFULLY", comment: "")
        alertTag = AlertViewTags.SuccessAction.rawValue
        
        alertView = alertController.showSimpleAlert(title, message:message, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)
    }
    
    
    override func setNavigationBackButtonImage() {
        let image = UIImage(named: ButtonTitles.BackIcon)
        let backButton = UIButton(type: UIButtonType.Custom)
        backButton.addTarget(self, action: #selector(backButtonAction), forControlEvents: UIControlEvents.TouchUpInside)
        backButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: -30, bottom: 0, right: -10)
        backButton.setImage(image, forState: UIControlState.Normal)
        backButton.sizeToFit()
        let backButtonItem = UIBarButtonItem(customView: backButton)
        self.navigationItem.leftBarButtonItem = backButtonItem
    }
    override func backButtonAction(button: UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    func updateUI() {
        self.patientNameLabel.text = patientInfo?.firstName as? String
        self.patientCaseIDLbl.text = "CaseID: " + (patientInfo?.hospitalCaseID)! as String
        self.patientAgeLabel.text = self.patientInfo?.age as? String
        if patientInfo?.gender == "1"{
            self.genderLabel.text = StringConstants.GenderMaleText
        } else {
            self.genderLabel.text = StringConstants.GenderFemaleText
        }
        self.genderLabel.text = self.genderLabel.text?.uppercaseString
        self.systolicValueLabel.text = patientInfo?.patientHistory?.systolic
        self.diastolicValueLabel.text = patientInfo?.patientHistory?.diastolic
        self.pulseValueLabel.text = patientInfo?.patientHistory?.pulse
        self.temperatureValueLabel.text = patientInfo?.patientHistory?.temperature
        self.sp02ValueLabel.text = patientInfo?.patientHistory?.spo2
        updateKillipScore()
    }
    func updateKillipScore() {
        if (patientInfo!.patientHistory!.killipScore)?.stringValue == "1"{
            self.killipScoreValueLabel.text = KillipScoreValues.first
        } else if (patientInfo!.patientHistory!.killipScore)?.stringValue == "2"{
            self.killipScoreValueLabel.text = KillipScoreValues.second
        } else if (patientInfo!.patientHistory!.killipScore)?.stringValue == "3"{
            self.killipScoreValueLabel.text = KillipScoreValues.third
        } else {
            self.killipScoreValueLabel.text = KillipScoreValues.fourth
        }
    }

    // Function for adding the shadow around the corners
    func addShadow(view: UIView) {
        view.layer.masksToBounds = false
        view.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        view.layer.shadowRadius = 2.0
        view.layer.shadowOpacity = 0.22
        
        let path = UIBezierPath()
        // Start at the Top Left Corner
        path.moveToPoint(CGPoint(x: 0.0, y: 0.0))
        // Move to the Left Bottom Corner
        path.addLineToPoint(CGPoint(x: 0.0, y: view.frame.size.height))
        // Move to the Bottom Right Corner
        path.addLineToPoint(CGPoint(x: view.frame.size.width, y: view.frame.size.height))
        // Move to the Top Right Corner
        path.addLineToPoint(CGPoint(x: view.frame.size.width, y: 0.0))
        
        // This is the extra point in the middle :) Its the secret sauce.
        path.addLineToPoint(CGPoint(x: view.frame.size.width/2.0, y: view.frame.size.height/2.0))
        
        path.closePath()
        view.layer.shadowPath = path.CGPath
    }

    @IBAction func editInfarctAreaAction(sender: AnyObject) {
    }
    @IBAction func ecgDownloadingButtonAction(sender: AnyObject) {
        retryButtonClick()
    }
    @IBAction func bottomButtonAction(sender: AnyObject) {
        if NetworkUtil.isConnected() == false {
            showAlert( NSLocalizedString("NO_INTERNET_CONNECTION", comment: ""), alertMsg: NSLocalizedString("YOUR_REQUEST_COULD_NOT_BE_COMPLETED", comment: ""))
            return
        }
        self.patientInfo?.patientHistory?.isFreshUpload = false
        selectedButtonTag = sender.tag
        let message = NSLocalizedString("CONFIRMATION", comment: "")
        if sender.tag == BottomButtonTags.UnclearECG.rawValue {
            showCustomAlertVithTextView()
        } else if sender.tag == BottomButtonTags.Stemi.rawValue {
            self.showConfirmationAlert(message, alertMsg: StringConstants.stemiConfirmationMessage)
        } else if sender.tag == BottomButtonTags.NotAStemi.rawValue {
            self.showConfirmationAlert(message, alertMsg: StringConstants.NotAStemiConfirmationMessage)
        }
    }
}
// MARK: - Alert View Delegates
extension MEDOnCallCardioDiagnosisVC: AlertViewControllerProtocol {
    func showCustomAlertVithTextView() {
        let alertClass = AlertController()
        alertClass.delegate = self
        alertTag = AlertViewTags.UnclearECG.rawValue
        alertController = alertClass.showAlertViewWithTextView("Provide Details", message: "fasdf", okTitle: "OK", cancelTitle: "Cancel", prefereredStyle: UIAlertControllerStyle.Alert, tag: AlertViewTags.UnclearECG.rawValue, target: self)
        alertClass.customTextView?.delegate = self
        self.presentViewController(alertController!, animated: true, completion: {
        })
    }
    func textViewCancelButtonTapped() {
        // Text View Cancel Button Tapped
        patientInfo?.patientHistory?.uncleatECGComments = nil
        self.alertController?.view.endEditing(true)
        self.alertController?.dismissViewControllerAnimated(true, completion: {})
    }
    func textViewOkButtonTapped() {
        // Text  View Done Button Tapped
        
        if (alertTag == AlertViewTags.UnclearECG.rawValue) {
            patientInfo?.timeLine?.unclearECGTime = DateUtility.getCurrentTimeInGMT()
            patientInfo?.caseStatus = status.UnderObservation.rawValue
        }
        
        if patientInfo?.patientHistory?.uncleatECGComments != nil && patientInfo?.patientHistory?.uncleatECGComments != StringConstants.UnclearECGDefaultComment && patientInfo?.patientHistory?.uncleatECGComments != "" {
            self.alertController?.view.endEditing(true)
            self.alertController?.dismissViewControllerAnimated(true, completion: {})
            updateInfractAreaDetailsFromCardiologist()
        }
    }
    
    func cancelButtonAction(alertController: UIAlertController) {
        
        // Yes button clicked
        if selectedButtonTag == BottomButtonTags.Stemi.rawValue {
            // Stemi button clicked
            patientInfo?.timeLine?.diagnoseTime = DateUtility.getCurrentTimeInGMT()
            patientInfo?.timeLine?.isStemi = true
            self.patientInfo?.patientHistory?.uncleatECGComments = ""
            patientInfo?.caseStatus = status.Diagnosed.rawValue
            updateInfractAreaDetailsFromCardiologist()
            
        } else if selectedButtonTag == BottomButtonTags.NotAStemi.rawValue {
            // Not a stemi button clicked
            patientInfo?.timeLine?.diagnoseTime = DateUtility.getCurrentTimeInGMT()
            patientInfo?.timeLine?.isStemi = false
            patientInfo?.caseStatus = status.Diagnosed.rawValue
            self.patientInfo?.patientHistory?.uncleatECGComments = ""
            updateInfractAreaDetailsFromCardiologist()
        }
        
    }
    func OKButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
    func defaultButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)
        if (alertTag == AlertViewTags.SuccessAction.rawValue) {
            if(self.navigationController?.viewControllers.first is MEDHomeViewController)
            {
                let topViewController = self.navigationController?.viewControllers.first as! MEDHomeViewController
                topViewController.shouldTableViewRefresh = true
            }
            self.navigationController?.popViewControllerAnimated(true)
        }
        if alertController.view.tag == AlertViewTags.AlreadyReviewdTag.rawValue {
            self.navigationController?.popToRootViewControllerAnimated(true)
        }
    }
    
    func navigateToInfarctAreaScreen(patientInfo: PatientInfo) {
        
    }
    
    func showConfirmationAlert(alertTile: String, alertMsg: String) {
        let alertClass = AlertController()
        alertClass.delegate = self
        let alertController = alertClass.showCustomAlertWithTwoActions(alertTile, message:alertMsg, okTitle: "NO", cancelTitle: "YES", prefereredStyle: UIAlertControllerStyle.Alert, tag:0)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
}

//MARK:- Text view delegates
extension MEDOnCallCardioDiagnosisVC: UITextViewDelegate {
    func textViewDidBeginEditing(textView: UITextView) {
        if textView.text == StringConstants .UnclearECGDefaultComment {
            textView.text = ""
            textView.textColor = ColorPicker.lightBlackColor()
        }
        
    }
    func textViewDidEndEditing(textView: UITextView) {
        
        if textView.text == ""{
            textView.text = StringConstants.UnclearECGDefaultComment
            textView.textColor = ColorPicker.steelGreyColor()
        }
        
    }
    func textViewDidChange(textView: UITextView) {
        
        self.patientInfo?.patientHistory?.uncleatECGComments = textView.text
        self.patientInfo?.patientHistory?.uncleatECGComments =  self.patientInfo?.patientHistory?.uncleatECGComments?.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        
    }
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        let charSet =  NSCharacterSet.newlineCharacterSet()
        let updatedString = (textView.text as NSString?)?.stringByReplacingCharactersInRange(range, withString: text)
        if let _ = updatedString!.rangeOfCharacterFromSet(charSet) {
            return false
        }
        if (updatedString?.characters.count)! > 140 {
            return false
        } else if ((updatedString?.characters.count) > 0 && updatedString![(updatedString?.startIndex.advancedBy(0))!] == " ") {
            return false
        }
        return true
    }
}
// MARK: - tableView Delegate methods
extension MEDOnCallCardioDiagnosisVC:UITableViewDelegate {
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        if section == (self.infractAreaArray?.count)! - 1 {
            return UIView()
        }
        let view = UIView()
        view.backgroundColor = ColorPicker.lightWarmGreyColor()
        return view
    }
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        return UIView()
    }
    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 1
    }
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return self.infractAreaArray!.count
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if isOtherComments {
            if indexPath.section == self.infractAreaArray!.count - 1 {
                return CGFloat(infractAreaRowHeight) + 160
            }
        }
        return CGFloat(infractAreaRowHeight)
    }
}

// MARK: - TableView Datasourse methods

extension  MEDOnCallCardioDiagnosisVC:UITableViewDataSource {
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("OnCallCardioInfractAreaCell", forIndexPath: indexPath) as! MEDOnCallCardioTVC
        configureCell(cell, indexPath: indexPath)
        return cell
    }
    func configureCell(cell: MEDOnCallCardioTVC, indexPath: NSIndexPath) {
        cell.infractAreaNameLabel.text = self.infractAreaArray![indexPath.section] as? String
        if isOtherComments {
            if indexPath.section == self.infractAreaArray!.count - 1 {
                cell.infractAreaNameLabel.text = "Others/Comments"
                cell.STNameLabel.lineBreakMode = .ByWordWrapping
                cell.STNameLabel.numberOfLines = 0
                cell.STNameLabel.text = otherCommentsText
                cell.STNameLabel.sizeToFit()
                self.view.layoutIfNeeded()
                otherCommentsNumberOfLines = self.getNumberOfLines(cell.STNameLabel)
                self.view.layoutIfNeeded()
                return
            }
        }
        let infractAreaDict = self.infractAreaArray?.objectAtIndex(indexPath.section)
        cell.infractAreaNameLabel.text = infractAreaDict?.valueForKey("InfractAreaName") as? String
        cell.STNameLabel.text = infractAreaDict?.valueForKey("STElevationName") as? String
        cell.STNameLabel.lineBreakMode = .ByTruncatingTail
        cell.STNameLabel.numberOfLines = 1
        self.view.layoutIfNeeded()
}
}