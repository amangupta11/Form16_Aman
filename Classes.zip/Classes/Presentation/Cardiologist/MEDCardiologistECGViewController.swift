//  MEDCardiologistECGViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import Firebase
let kRotationAnimationKey = "com.rotationanimation360.key" // Any key

class MEDCardiologistECGViewController: MEDBaseViewController {
    private var infractAreaRowHeight = 60
    private var defaultInfractAreaContainerViewHeight = 220
    private var defaultScrollViewContainerViewHeight = 680

    struct CardiologistECGStringConstants {
        static  var CellIdentifier = "InfractAreaCell"
        static  let GenderMaleText = "Male"
        static  let GenderFemaleText = "Female"
        static let OtherCommentsLabel = "Others/Comments"
        static let ScreenTitle = "Case Details"
        static let UnclearECGDefaultComment = NSLocalizedString("UNCLEAR_ECG_DEFAULT_MSG", comment: "")
        static let NotAStemiConfirmationMessage = NSLocalizedString("NOT_A_STEMI_CONFIRMATION_MSG", comment: "")
        static let stemiConfirmationMessage = NSLocalizedString("STEMI_CONFIRMATION_MSG", comment: "")
        static let ConfrimationTitle = NSLocalizedString("CONFIRMATION", comment: "")
        static  var AlertTitle = NSLocalizedString("ATTENTION", comment: "")
        static  var ReviewedAlertMessage = NSLocalizedString("THIS_CASE_HAS_ALREADY_BEEN_REVIEWED_YOUR_REQUEST_COULD_NOT_SUBMIT", comment: "")
        static  var UpdateAlertMessage = NSLocalizedString("THERE_HAS_BEEN_AN_UPDATE_ON_THIS_CASE", comment: "")

    }
    struct KillipScoreValues {
        static let first = "I"
        static let second = "II"
        static let third = "III"
        static let fourth = "IV"
    }
    enum AlertViewTags: Int {
        case UnclearECG = 101, SuccessAction
        case AlreadyReviewdTag = 1001
    }
    enum BottomButtonTags: Int {
        case UnclearECG = 101, NotAStemi, Stemi
    }
    @IBOutlet weak var editInfarctAreaButtn: UIButton!
    @IBOutlet weak var patientCaseID: UILabel!
    @IBOutlet weak var ecgDownloadingSyncButton: UIButton!
    @IBOutlet weak var ecgImageView: UIImageView!
    @IBOutlet weak var killipScoreButton: UIButton!
    @IBOutlet weak var killipScoreValueLabel: UILabel!
    @IBOutlet weak var sp02ValueLabel: UILabel!
    @IBOutlet weak var temperatureValueLabel: UILabel!
    @IBOutlet weak var pulseValueLabel: UILabel!
    @IBOutlet weak var diastolicValueLabel: UILabel!
    @IBOutlet weak var systolicValueLabel: UILabel!
    @IBOutlet weak var scrollViewContainerViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var scrollViewContainerViewHeight: NSLayoutConstraint!
    @IBOutlet weak var scrollViewContainerView: UIView!
    @IBOutlet weak var patientHistoryContatinerVIew: UIView!
    @IBOutlet weak var patientInfoContainerView: UIView!
    @IBOutlet weak var infractAreaContainerView: UIView!
    @IBOutlet weak var notAStemiButton: UIButton!
    @IBOutlet weak var stemiButton: UIButton!
    @IBOutlet weak var ecgImageContainerView: UIView!
    @IBOutlet weak var infractAreaContainerViewHeight: NSLayoutConstraint!
    @IBOutlet weak var unclearECGButton: UIButton!
    @IBOutlet weak var infractAreaTableView: UITableView!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var patientAgeLabel: UILabel!
    var otherCommentsNumberOfLines: Int = 0
    var selectedButtonTag: Int? = nil
    var isOtherComments = false
    var infractAreaArray: NSMutableArray? = nil
    var ecgImage: UIImage? = nil
    var otherCommentsText = ""
    var alertController: UIAlertController? = nil
    var alertTag: Int?
    var activeTxtView:UITextView? = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUp("")
        if Patient.sharedInfo.patientInfo != nil{
           startTimer()
        }
    }
    override func viewDidLayoutSubviews() {
        self.infractAreaContainerViewHeight.constant = CGFloat(defaultInfractAreaContainerViewHeight) + CGFloat((self.infractAreaArray!.count - 1)*infractAreaRowHeight) + CGFloat(otherCommentsNumberOfLines * 15)
        self.infractAreaContainerView.frame.size.height = self.infractAreaContainerViewHeight.constant
        self.scrollViewContainerViewHeightConstraint.constant =  CGFloat(defaultScrollViewContainerViewHeight) + CGFloat((self.infractAreaArray!.count - 1)*infractAreaRowHeight) + CGFloat(otherCommentsNumberOfLines * 15)
        addShadow(self.patientInfoContainerView)
        addShadow(self.patientHistoryContatinerVIew)
        addShadow(self.infractAreaContainerView)
    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        FIRAnalytics.setScreenName(FireBaseConstants.caseDiagnosis, screenClass: FireBaseConstants.caseDiagnosis)
        if !isCaseExist(){
            showReviewedAlert()
            return
        }
        self.hidesBottomBarWhenPushed = false
        super.addKeyboardObserver(self)
         NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.appMovedToBackground), name: UIApplicationDidEnterBackgroundNotification, object: nil)
    }
    
    override func viewDidAppear(animated: Bool) {
        addShadow(self.infractAreaContainerView)
        super.viewDidAppear(animated)
    }
    
    override func viewDidDisappear(animated: Bool) {
        defaultInfractAreaContainerViewHeight = 220
        defaultScrollViewContainerViewHeight = 680
        super.removeKeyBoardObserver(self)
        NSNotificationCenter.defaultCenter().removeObserver(self)
        super.viewDidDisappear(animated)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    private func isCaseExist()-> Bool {
        return Patient.sharedInfo.patientInfo != nil && Patient.sharedInfo.patientInfo?.patientHistory != nil
    }
    
    private func showReviewedAlert() {
        let alertCntrl = AlertController()
        alertCntrl.delegate = self
        let message = NSLocalizedString(NotificationConstants.AlreadyReviewed, comment: "")
        let alertController = alertCntrl.showSimpleAlert(StringConstants.ErrorTitle, message: message, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertController, animated: true, completion: {
        })
        alertCntrl.view.tag = AlertViewTags.AlreadyReviewdTag.rawValue
    }
    
}
//MARK: - Keyboard Notification Handling
extension MEDCardiologistECGViewController {
    override func keyboardWillHide(notification: NSNotification) {
        // Move the view Down
        UIView.performWithoutAnimation({
            self.view.frame.origin.y = 64
        })
    }
    override func keyboardWillShow(notification: NSNotification) {
               UIView.animateWithDuration(0.5, delay: 0.15, options: UIViewAnimationOptions.CurveEaseIn, animations: {
                // Move the view up
                self.view.frame.origin.y = self.view.frame.origin.y - 150
                }, completion: nil)

        }

}

// MARK: - Custom Actions
extension MEDCardiologistECGViewController {
    func handleSuccessForBottomButtonAction () {
        //navigate to home
        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        let title = NSLocalizedString("SUCCESS", comment: "")
        let message = NSLocalizedString("CASE_DIAGNOSED_SUCESSFULLY", comment: "")
        alertTag = AlertViewTags.SuccessAction.rawValue

        alertView = alertController.showSimpleAlert(title, message:message, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)
        }


    func retryButtonClick () {
        getAWSBucketInformation()
    }
    func showRetryButton(isHide: Bool, isRotating: Bool) {
        self.ecgDownloadingSyncButton.hidden = isHide
        if isRotating == true {
            rotateView(self.ecgDownloadingSyncButton)
            self.ecgDownloadingSyncButton.userInteractionEnabled = false
        } else {
            self.ecgDownloadingSyncButton.userInteractionEnabled = true
            stopRotatingView(self.ecgDownloadingSyncButton)
        }
    }
    func handleDownloadError() {
        showRetryButton(false, isRotating: false)
    }

    func updateECGImage() {
        showRetryButton(true, isRotating: false)
        enableBottomButtons(true)
        if let localPath = Patient.sharedInfo.patientInfo?.ecgInfo?.localPath {
            let image    = UIImage(contentsOfFile: localPath)
            self.ecgImage = image
            self.ecgImageView.image = self.ecgImage
            self.editInfarctAreaButtn.alpha = 1.0
        }
    }
    func downloadECGImage() {
        enableBottomButtons(false)
        if NetworkUtil.isConnected() == false {
            showRetryButton(false, isRotating: false)
            return
        }
        if(Patient.sharedInfo.patientInfo?.ecgInfo?.ecgURL != nil) {

            showRetryButton(false, isRotating: true)
            let downloadURL = String(format:"%@/%@/%@", ecgPath, (Patient.sharedInfo.patientInfo?.caseID)!, (Patient.sharedInfo.patientInfo?.ecgInfo?.ecgFileName)!)
            let fileName = String(format: "%@", (Patient.sharedInfo.patientInfo?.ecgInfo?.ecgFileName)!)
            downloadImage(NSURL.fileURLWithPath(NSTemporaryDirectory().stringByAppendingString(fileName)), s3DownloadKeyName:downloadURL)
        }
    }
    func updateUI() {
        self.patientCaseID.text = Patient.sharedInfo.patientInfo?.hospitalCaseID
        self.patientAgeLabel.text = Patient.sharedInfo.patientInfo?.age
        if Patient.sharedInfo.patientInfo?.gender == "1"{
            self.genderLabel.text = CardiologistECGStringConstants.GenderMaleText
        } else {
            self.genderLabel.text = CardiologistECGStringConstants.GenderFemaleText
        }
        self.genderLabel.text = self.genderLabel.text?.uppercaseString
        self.systolicValueLabel.text = Patient.sharedInfo.patientInfo?.patientHistory?.systolic
        self.diastolicValueLabel.text = Patient.sharedInfo.patientInfo?.patientHistory?.diastolic
        self.pulseValueLabel.text = Patient.sharedInfo.patientInfo?.patientHistory?.pulse
        self.temperatureValueLabel.text = Patient.sharedInfo.patientInfo?.patientHistory?.temperature
        self.sp02ValueLabel.text = Patient.sharedInfo.patientInfo?.patientHistory?.spo2
        updateKillipScore()
    }
    func updateKillipScore() {
        if (Patient.sharedInfo.patientInfo?.patientHistory?.killipScore)?.stringValue == "1"{
            self.killipScoreValueLabel.text = KillipScoreValues.first
        } else if (Patient.sharedInfo.patientInfo?.patientHistory?.killipScore)?.stringValue == "2"{
            self.killipScoreValueLabel.text = KillipScoreValues.second
        } else if (Patient.sharedInfo.patientInfo?.patientHistory?.killipScore)?.stringValue == "3"{
            self.killipScoreValueLabel.text = KillipScoreValues.third
        } else {
            self.killipScoreValueLabel.text = KillipScoreValues.fourth
        }
    }
    
    func appMovedToBackground(){
        if (activeTxtView != nil){
            activeTxtView?.resignFirstResponder()
        }
    }

    func loadInfractAreas() {
        let metaDataPList: NSDictionary!
        if let path = FileUtility.getPlistPath() {
            metaDataPList = NSDictionary(contentsOfFile: path)
            self.infractAreaArray = metaDataPList.objectForKey("InfractAreaDetails")?.mutableCopy() as? NSMutableArray
        }
        var i = 0
        let updatedArray = NSMutableArray()
        while i < 9 {
            if(self.checkIfInfractAreaSelected(i)) {
                updatedArray.addObject((self.infractAreaArray?.objectAtIndex(i))!)
                }
            i += 1
        }
        self.infractAreaArray = updatedArray
    }

    func checkIfInfractAreaSelected(index: Int) -> Bool {
        if(index == 0) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.anteroseptal != false ? true:false
        } else if(index == 1) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.anterior != false ? true:false
        } else if(index == 2) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.lateral != false ? true:false
        } else if(index == 3) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.extensiveanterolateral != false ? true:false
        } else if(index == 4) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.inferior != false ? true:false
        } else if(index == 5) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.posterior != false ? true:false
        } else if(index == 6) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.rightsided != false ? true:false
        } else if(index == 7) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.leftmainstem != false ? true:false
        } else if(index == 8) {
            if Patient.sharedInfo.patientInfo?.patientHistory?.others == true {
                self.isOtherComments = true
                if Patient.sharedInfo.patientInfo?.patientHistory?.otherscomments != nil {
                otherCommentsText = (Patient.sharedInfo.patientInfo?.patientHistory?.otherscomments)!
                }
            } else {
                self.isOtherComments = false
                otherCommentsNumberOfLines = 0
            }
            return Patient.sharedInfo.patientInfo?.patientHistory?.others != false ? true:false
        }
        return false
    }
    // Function for adding the shadow around the corners
    func addShadow(view: UIView) {
        view.layer.masksToBounds = false
        view.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        view.layer.shadowRadius = 2.0
        view.layer.shadowOpacity = 0.22

        let path = UIBezierPath()
        // Start at the Top Left Corner
        path.moveToPoint(CGPoint(x: 0.0, y: 0.0))
        // Move to the Left Bottom Corner
        path.addLineToPoint(CGPoint(x: 0.0, y: view.frame.size.height))
        // Move to the Bottom Right Corner
        path.addLineToPoint(CGPoint(x: view.frame.size.width, y: view.frame.size.height))
        // Move to the Top Right Corner
        path.addLineToPoint(CGPoint(x: view.frame.size.width, y: 0.0))

        // This is the extra point in the middle :) Its the secret sauce.
        path.addLineToPoint(CGPoint(x: view.frame.size.width/2.0, y: view.frame.size.height/2.0))

        path.closePath()
        view.layer.shadowPath = path.CGPath
    }
    override func initialSetUp(bgImage: String) {
        self.loadInfractAreas()
        self.setTapGestureForView()
        setNavigationBackButtonImage()
        setUpECGImageContainerView()
        infractAreaTableView.scrollEnabled = false
        self.updateUI()
        self.retryButtonClick()
        self.rotateView(self.ecgDownloadingSyncButton)
        self.setTapActionOnImageView()
        self.scrollView.showsHorizontalScrollIndicator = false
        self.scrollView.showsVerticalScrollIndicator = false
        Patient.sharedInfo.patientInfo?.patientHistory?.uncleatECGComments = nil
        self.editInfarctAreaButtn.alpha = 0.3
        self.infractAreaTableView.allowsSelection = false
    }
    // Setting tap gesture
    func setTapGestureForView() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:) ))
        self.view.addGestureRecognizer(tapGesture)
    }
    func handleTap(sender: UIView) {
        view.endEditing(true)
    }
    func setUpECGImageContainerView() {
        self.ecgImageContainerView.layer.borderColor = UIColor(red: 150/255, green: 150/255, blue: 150/255, alpha: 0.35).CGColor
        self.ecgImageContainerView.layer.borderWidth = 1
    }
    func getNumberOfLines(label: UILabel) -> Int {
        var lineCount = 0
        let textSize = CGSizeMake(label.frame.size.width, CGFloat(Float.infinity))
        let rHeight = lroundf(Float(label.sizeThatFits(textSize).height))
        let charSize = lroundf(Float(label.font.lineHeight))
        lineCount = rHeight/charSize
        return lineCount
    }


    func rotateView(view: UIView, duration: Double = 1) {
        if view.layer.animationForKey(kRotationAnimationKey) == nil {
            let rotationAnimation = CABasicAnimation(keyPath: "transform.rotation")

            rotationAnimation.fromValue = 0.0
            rotationAnimation.toValue = Float(M_PI * 2.0)
            rotationAnimation.duration = duration
            rotationAnimation.repeatCount = Float.infinity
            view.layer.addAnimation(rotationAnimation, forKey: kRotationAnimationKey)
        }
    }
    func stopRotatingView(view: UIView) {
        if view.layer.animationForKey(kRotationAnimationKey) != nil {
            view.layer.removeAnimationForKey(kRotationAnimationKey)
        }
    }

    func presentECGImagePreviewScreen() {
        if self.ecgDownloadingSyncButton.hidden == true {
        let ecgPreviewScreen = UIStoryboard(name: StroryBoardNameConstants.SBCreateCase, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.ecgPreviewScreenSBID) as? MEDPatientECGPreviewViewController
        ecgPreviewScreen?.ecgImage = self.ecgImage
        ecgPreviewScreen?.hidesBottomBarWhenPushed = true
        ecgPreviewScreen?.title = "ECG"
        self.navigationController?.pushViewController(ecgPreviewScreen!, animated: true)
        }
    }
    func setTapActionOnImageView() {
        let tapGestureRecognizer = UITapGestureRecognizer(target:self, action:#selector(MEDCardiologistECGViewController.imageTapped(_:)))
        self.ecgImageView.userInteractionEnabled = true
        self.ecgImageView.addGestureRecognizer(tapGestureRecognizer)
    }

    func imageTapped(img: AnyObject) {
        //Present ecg preview controller screen to zoom in and out
        self.presentECGImagePreviewScreen()
    }

    func showUnauthorizationAlert(alertTile: String, alertMsg: String) {
        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        alertTag = AlertViewTags.SuccessAction.rawValue
        alertView = alertController.showSimpleAlert(alertTile, message:alertMsg, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)
    }

    func showConfirmationAlert(alertTile: String, alertMsg: String) {
        let alertCntrl = AlertController()
        alertCntrl.delegate = self
        let alertController = alertCntrl.showCustomAlertWithTwoActions(alertTile, message:alertMsg, okTitle: "NO", cancelTitle: "YES", prefereredStyle: UIAlertControllerStyle.Alert, tag:0)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }

    override func backButtonAction(button: UIButton) {
        AWSTransferManager.sharedTransferManager.cancelAllTask()
        let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        if appDelegate?.currentCaseStatus == Patient.sharedInfo.patientInfo?.caseStatus{
            self.navigationController?.popViewControllerAnimated(true)
        }
        else{
            self.navigateToHome()
        }
        appDelegate?.currentCaseStatus = 0
        
    }
    func navigateToHome() {
        if self.navigationController?.viewControllers.first is MEDHomeViewController
        {
            let topViewController = self.navigationController?.viewControllers.first as! MEDHomeViewController
            topViewController.shouldTableViewRefresh = true
        }
        //DataOperation.sharedDataOperation.deleteManagedObject(patientInfo!)
        self.navigationController?.popToRootViewControllerAnimated(true)
    }

    func stopDownloadingImage(){
        AWSTransferManager.sharedTransferManager.cancelAllTask()
    }
    
    func enableBottomButtons(enabled: Bool){
        self.unclearECGButton.enabled = enabled
        self.notAStemiButton.enabled = enabled
        self.stemiButton.enabled = enabled
        
        if enabled == false{
            self.unclearECGButton.alpha = 0.4
            self.notAStemiButton.alpha = 0.4
            self.stemiButton.alpha = 0.4
        }else{
            self.unclearECGButton.alpha = 1.0
            self.notAStemiButton.alpha = 1.0
            self.stemiButton.alpha = 1.0

        }
    }
}
// MARK: - Alert View Delegates
extension MEDCardiologistECGViewController: AlertViewControllerProtocol {
    func showCustomAlertVithTextView() {
        let alertCntrl = AlertController()
        alertCntrl.delegate = self
        alertTag = AlertViewTags.UnclearECG.rawValue
        alertController = alertCntrl.showAlertViewWithTextView("Provide Details", message: "fasdf", okTitle: "OK", cancelTitle: "Cancel", prefereredStyle: UIAlertControllerStyle.Alert, tag: AlertViewTags.UnclearECG.rawValue, target: self)
        alertCntrl.customTextView?.delegate = self
        self.presentViewController(alertController!, animated: true, completion: {
        })
    }
    func textViewCancelButtonTapped() {
        // Text View Cancel Button Tapped
        Patient.sharedInfo.patientInfo?.patientHistory?.uncleatECGComments = nil
        self.alertController?.view.endEditing(true)
        self.alertController?.dismissViewControllerAnimated(true, completion: {})
    }
    func textViewOkButtonTapped() {
        // Text  View Done Button Tapped
        if (alertTag == AlertViewTags.UnclearECG.rawValue) {
            Patient.sharedInfo.patientInfo?.timeLine?.unclearECGTime = DateUtility.getCurrentTimeInGMT()
            Patient.sharedInfo.patientInfo?.caseStatus = statusKey.UnderObservation.rawValue
        }
        if Patient.sharedInfo.patientInfo?.patientHistory?.uncleatECGComments != nil && Patient.sharedInfo.patientInfo?.patientHistory?.uncleatECGComments != CardiologistECGStringConstants.UnclearECGDefaultComment && Patient.sharedInfo.patientInfo?.patientHistory?.uncleatECGComments != "" {
            FIRAnalytics.logEventWithName(FireBaseEvents.needInfoDiagnosis, parameters:nil)
            self.alertController?.view.endEditing(true)
            self.alertController?.dismissViewControllerAnimated(true, completion: {})
        updateInfractAreaDetailsFromCardiologist()
        }
    }
    func cancelButtonAction(alertController: UIAlertController) {
        // Yes button clicked
        if selectedButtonTag == BottomButtonTags.Stemi.rawValue {
            // Stemi button clicked
            FIRAnalytics.logEventWithName(FireBaseEvents.stemiDiagnosis, parameters:nil)
            Patient.sharedInfo.patientInfo?.timeLine?.diagnoseTime = DateUtility.getCurrentTimeInGMT()
            Patient.sharedInfo.patientInfo?.timeLine?.isStemi = true
            Patient.sharedInfo.patientInfo?.patientHistory?.uncleatECGComments = ""
            Patient.sharedInfo.patientInfo?.caseStatus = statusKey.Diagnosed.rawValue
            updateInfractAreaDetailsFromCardiologist()

        } else if selectedButtonTag == BottomButtonTags.NotAStemi.rawValue {
            // Not a stemi button clicked
            FIRAnalytics.logEventWithName(FireBaseEvents.notAStemiDiagnosis, parameters:nil)
            Patient.sharedInfo.patientInfo?.timeLine?.diagnoseTime = DateUtility.getCurrentTimeInGMT()
            Patient.sharedInfo.patientInfo?.timeLine?.isStemi = false
            Patient.sharedInfo.patientInfo?.caseStatus = statusKey.Diagnosed.rawValue
            Patient.sharedInfo.patientInfo?.patientHistory?.uncleatECGComments = ""
            updateInfractAreaDetailsFromCardiologist()
        }
//
    }
    func OKButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
    func defaultButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)
        if (alertTag == AlertViewTags.SuccessAction.rawValue) {
            if(self.navigationController?.viewControllers.first is MEDHomeViewController)
            {
                let topViewController = self.navigationController?.viewControllers.first as! MEDHomeViewController
                topViewController.shouldTableViewRefresh = true
            }
            else if let navigationController = self.tabBarController!.viewControllers!.first as? UINavigationController
            {
                (navigationController.viewControllers.first as! MEDHomeViewController).shouldTableViewRefresh = true
                self.tabBarController?.selectedIndex = 0
            }
            self.navigationController?.popViewControllerAnimated(true)
        }
        if alertController.view.tag == AlertViewTags.AlreadyReviewdTag.rawValue {
            self.navigationController?.popToRootViewControllerAnimated(true)
        }
    }

    func navigateToInfarctAreaScreen() {

        let storyBoard: UIStoryboard = UIStoryboard(name: StroryBoardNameConstants.SBCardiologist, bundle:nil)
        let vc = storyBoard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.cardiologistInfarctAreaControllerSBID) as? CardiologistInfarctAreaController
        vc!.ecgImage = self.ecgImageView.image
        self.navigationController?.pushViewController(vc!, animated: true)

    }


}

//MARK:- Text view delegates
extension MEDCardiologistECGViewController: UITextViewDelegate {
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        activeTxtView = textView
        return true
        
    }
    func textViewDidBeginEditing(textView: UITextView) {
        if textView.text == CardiologistECGStringConstants.UnclearECGDefaultComment {
            textView.text = ""
            textView.textColor = ColorPicker.lightBlackColor()
        }

    }
    func textViewDidEndEditing(textView: UITextView) {

        if textView.text == ""{
            textView.text = CardiologistECGStringConstants.UnclearECGDefaultComment
            textView.textColor = ColorPicker.steelGreyColor()
        }

    }
    func textViewDidChange(textView: UITextView) {

    Patient.sharedInfo.patientInfo?.patientHistory?.uncleatECGComments = textView.text
    Patient.sharedInfo.patientInfo?.patientHistory?.uncleatECGComments =  Patient.sharedInfo.patientInfo?.patientHistory?.uncleatECGComments?.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())

    }
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
          let charSet =  NSCharacterSet.newlineCharacterSet()
        let updatedString = (textView.text as NSString?)?.stringByReplacingCharactersInRange(range, withString: text)
        if let _ = updatedString!.rangeOfCharacterFromSet(charSet) {
            return false
        }
        if (updatedString?.characters.count)! > 140 {
            return false
        } else if ((updatedString?.characters.count) > 0 && updatedString![(updatedString?.startIndex.advancedBy(0))!] == " ") {
            return false
        }
        return true
    }
}

// MARK: - @IBAction Methods
extension MEDCardiologistECGViewController {
    @IBAction func ecgDownloadingButtonAction(sender: AnyObject) {
        // Again starting the downloading process
        retryButtonClick()
    }
    @IBAction func editInfarctAreaAction(sender: AnyObject) {
        if ecgImage != nil {
        self.navigateToInfarctAreaScreen()
        }
    }
    @IBAction func bottomButtonAction(sender: AnyObject) {
        if NetworkUtil.isConnected() == false {
            showAlert( NSLocalizedString("NO_INTERNET_CONNECTION", comment: ""), alertMsg: NSLocalizedString("YOUR_REQUEST_COULD_NOT_BE_COMPLETED", comment: ""))
            return
        }
        //self.patientInfo?.patientHistory?.isFreshUpload = false
        selectedButtonTag = sender.tag
        let message = NSLocalizedString("CONFIRMATION", comment: "")
        if sender.tag == BottomButtonTags.UnclearECG.rawValue {
            showCustomAlertVithTextView()
        } else if sender.tag == BottomButtonTags.Stemi.rawValue {
            self.showConfirmationAlert(message, alertMsg: CardiologistECGStringConstants.stemiConfirmationMessage)
        } else if sender.tag == BottomButtonTags.NotAStemi.rawValue {
             self.showConfirmationAlert(message, alertMsg: CardiologistECGStringConstants.NotAStemiConfirmationMessage)
        }
    }
}

// MARK: - tableView Delegate methods
extension MEDCardiologistECGViewController:UITableViewDelegate {
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        if section == (self.infractAreaArray?.count)! - 1 {
            return UIView()
        }
        let view = UIView()
        view.backgroundColor = ColorPicker.lightWarmGreyColor()
        return view
    }
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {

        return UIView()
    }
    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 1
    }
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return self.infractAreaArray!.count
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if isOtherComments {
            if indexPath.section == self.infractAreaArray!.count - 1 {
                return CGFloat(infractAreaRowHeight) + 160
            }
        }
        return CGFloat(infractAreaRowHeight)
    }
}

// MARK: - TableView Datasourse methods

extension  MEDCardiologistECGViewController:UITableViewDataSource {
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(CardiologistECGStringConstants.CellIdentifier, forIndexPath: indexPath) as! MEDCardiologistECGTableViewCell
        configureCell(cell, indexPath: indexPath)
        return cell
    }
    func configureCell(cell: MEDCardiologistECGTableViewCell, indexPath: NSIndexPath) {
        cell.infractAreaNameLabel.text = self.infractAreaArray![indexPath.section] as? String
        if isOtherComments {
            if indexPath.section == self.infractAreaArray!.count - 1 {
                cell.infractAreaNameLabel.text = CardiologistECGStringConstants.OtherCommentsLabel
                cell.STNameLabel.lineBreakMode = .ByWordWrapping
                cell.STNameLabel.numberOfLines = 0
                cell.STNameLabel.text = otherCommentsText
                cell.STNameLabel.sizeToFit()
                self.view.layoutIfNeeded()
                 otherCommentsNumberOfLines = self.getNumberOfLines(cell.STNameLabel)
                self.view.layoutIfNeeded()
                return
            }
        }
        let infractAreaDict = self.infractAreaArray?.objectAtIndex(indexPath.section)
        cell.infractAreaNameLabel.text = infractAreaDict?.valueForKey("InfractAreaName") as? String
        cell.STNameLabel.text = infractAreaDict?.valueForKey("STElevationName") as? String
        cell.STNameLabel.lineBreakMode = .ByTruncatingTail
        cell.STNameLabel.numberOfLines = 1
        self.view.layoutIfNeeded()
    }
}