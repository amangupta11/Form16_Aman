//  MEDCardiologistECGViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.


import Foundation
// MARK: -  Server Interaction
extension  MEDCardiologistECGViewController {

    func downloadImage(imageURL: NSURL, s3DownloadKeyName: String) {
        AWSTransferManager.sharedTransferManager.downloadImageRequest(imageURL, s3DownloadKeyName: s3DownloadKeyName, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                if successful {
                    self.updateECGImage()
                } else {
                    self.handleDownloadError()

                }
            })
        })
    }
        
    func getAWSBucketInformation() {
        checkInternet()
        APIRequest.sharedAPI.getAWSBucketInfo(patientInfo: "", completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    CustomAWSCredentialProvider.sharedInstance.updateAWSInfo(jsonString!)
                    self.downloadECGImage()
                    
                } else {
                   super.handleError(error) 
                }
            })
        })
    }

    func updateInfractAreaDetailsFromCardiologist() {
        checkInternet()
        APIRequest.sharedAPI.unclearPatientECG({
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.handleSuccessForBottomButtonAction()
                } else {
                    if(response?.statusCode == 427){
                        self.showUnauthorizationAlert(CardiologistECGStringConstants.AlertTitle, alertMsg: CardiologistECGStringConstants.ReviewedAlertMessage)
                    }
                    else if(response?.statusCode == 403){
                        self.showUnauthorizationAlert(CardiologistECGStringConstants.AlertTitle, alertMsg: CardiologistECGStringConstants.UpdateAlertMessage)
                    }
                    else{
                        super.handleError(error)
                    }
                }
            })
        })
    }

}
