//
//  MEDSettingsCustomCell.swift
//  Medtronic
//
//  Created by Praveen Ambekar on 5/19/17.
//  Copyright © 2017 Medtronic. All rights reserved.
//

import UIKit

class MEDSettingsCustomCell: UITableViewCell {

    @IBOutlet weak var descriptionLbl: UILabel!
    @IBOutlet weak var iconImgView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func layoutSubviews() {
        self.iconImgView.contentMode = UIViewContentMode.ScaleAspectFit
    }
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
