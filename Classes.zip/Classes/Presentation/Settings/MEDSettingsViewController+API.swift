//
//  MEDSettingsViewController+API.swift
//  Medtronic
//
//  Created by Chandrika Bhat on 15/11/16.
//  Copyright © 2016 Medtronic. All rights reserved.
//

import Foundation
extension MEDSettingsViewController {

    func performLogout() {
        checkInternet()
        APIRequest.sharedAPI.requestLogout(NotificationManager.chanelId(), completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    // Success
                    self.handleLogoutSuccess()
                } else {
                    super.handleError(error)
                }
            })
        })
    }

}
