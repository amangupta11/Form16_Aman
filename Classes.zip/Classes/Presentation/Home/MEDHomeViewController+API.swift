//  MEDHomeViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import SwiftyJSON
// MARK: -  Server Interaction
extension MEDHomeViewController {

    func performGetCASEDetails() {
        checkInternet()
        
        if  Patient.sharedInfo.patientInfo?.caseID != nil {
            let dict = [PatientInfoKey.CaseID.rawValue:Patient.sharedInfo.patientInfo?.caseID as! AnyObject]
            APIRequest.sharedAPI.getCASEDetails(dictionary:dict, completion: {
                (jsonString, successful, error, response) in
                dispatch_async(dispatch_get_main_queue(), {
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    if successful {
                        PatientManager.updateCaseDetails(jsonString)
                        if (Patient.sharedInfo.patientInfo?.caseStatus == statusKey.Diagnosed.rawValue || Patient.sharedInfo.patientInfo?.caseStatus == statusKey.UnderObservation.rawValue || Patient.sharedInfo.patientInfo?.caseStatus == statusKey.New.rawValue) {
                            self.navigateToPatientInfoView()
                        }
                        else{
                        self.navigateToViewSummary()
                        }
                    } else {
                        var errorMessage = StringConstants.ErrorTitle
                        if let error = error {
                            errorMessage = error.localizedDescription
                        }
                        super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                    }
                })
            })
        }}
    func performGetCASEList(pageNumber : Int) {
        PatientManager.clearCache { (successful) in
            // Disabling the table view interaction
            self.homeScreenListTable.userInteractionEnabled = false
            self.enableUI(false, isInternetLableHidden: true)
            if successful == true {
                self.performUIOperation(pageNumber)
                self.isRefreshing = false
                    }
            else{
                self.isRefreshing = false
            }
        }
    }
    
    func updatePatientInformation(json: JSON?, completion:(successful: Bool) -> Void) {
        var patientListArr = [PatientCaseInfo]()
        let caseList = json?[StringConstants.PatientcaseInfoList]
        for object in (caseList!.array)!{
            let patientCaseInfo = PatientCaseInfo()
            patientCaseInfo.updatePatientData(object)
            patientListArr.append(patientCaseInfo)
        }
        if let noOfPages = json?[StringConstants.NoOfPages]{
            if noOfPages != nil{
            self.pageCount = noOfPages.int!
            }
        }
        
        if currentPage == 1{
            self.caseResponseArr.removeAll()
        }
        //self.caseResponseArr = self.sortCaseList(patientListArr)
        self.caseResponseArr += patientListArr
        removeDuplicateRecordsFromArray(self.caseResponseArr)
        completion(successful: true)
    }
    
    func removeDuplicateRecordsFromArray(caseResponseArr : [PatientCaseInfo]) -> [PatientCaseInfo]{
        let caseIDArray = caseResponseArr.map { $0.caseID! }
        var uniqueCaseIDArray = Array(Set(caseIDArray))
        let uniqueArray = caseResponseArr.filter { (record) -> Bool in
            let caseID = record.caseID!
            if let index = uniqueCaseIDArray.indexOf({ (uniqueName) -> Bool in
                return uniqueName == caseID
            }) {
                uniqueCaseIDArray.removeAtIndex(index)
                return true
            } else {
                return false
            }
        }
      return uniqueArray
    }

    
    func performUIOperation(pageNumber : Int) {
        if NetworkUtil.isConnected() == true {
            var dict = [String:AnyObject]()
            dict[StringConstants.PageNumber] = pageNumber
            dict[StringConstants.SearchValue] = self.searchText
            APIRequest.sharedAPI.getCaseListWithPagination(dictionary:dict, completion: {
                (jsonString, successful, error, response) in
                dispatch_async(dispatch_get_main_queue(), {
                    if successful {
                       self.updatePatientInformation(jsonString, completion: { (successful) in
                        let delayTime = dispatch_time(DISPATCH_TIME_NOW, Int64(1.5 * Double(NSEC_PER_SEC)))
                        dispatch_after(delayTime, dispatch_get_main_queue()) {
                            ActivityIndicatorView.sharedActivityView.hideOverlayView()
                            self.navigationController?.view.userInteractionEnabled = true
                        }
                       })
                        //self.reloadTable()
                        
                    } else {
                         ActivityIndicatorView.sharedActivityView.hideOverlayView()
                        if(response?.statusCode == 453){
                            self.caseResponseArr.removeAll()
                            self.noRecordFoundStackView.hidden = false
                            self.plusIconLabel.hidden = true
                            self.view.bringSubviewToFront(self.noRecordFoundStackView)
                            self.homeScreenListTable.backgroundColor = UIColor.clearColor()
                            self.homeScreenListTable.reloadData()
                        }
                        else{
                        var errorMessage = StringConstants.ErrorTitle
                        if let error = error {
                            errorMessage = error.localizedDescription
                        }
                            super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                        }
                    }
                    self.reloadTable()
                    if let _ = self.refreshControl {
                        self.refreshControl!.endRefreshing()
                    }
                    if self.caseResponseArr.count > 0 {
                        self.noRecordFoundStackView.hidden = true
                    } else {
                        self.noRecordFoundStackView.hidden = false
                        self.view.bringSubviewToFront(self.noRecordFoundStackView)
                        self.homeScreenListTable.backgroundColor = UIColor.clearColor()
                    }
                    self.homeScreenListTable.userInteractionEnabled = true
                })
            })
            
        } else {
            if let _ = self.refreshControl {
                self.refreshControl!.endRefreshing()
            }
            self.homeScreenListTable.userInteractionEnabled = true
            ActivityIndicatorView.sharedActivityView.hideOverlayView()
            self.enableUI(false, isInternetLableHidden: false)
        }
    }

    func getUndiagnosedCaseDetails() {
        checkInternet()
            ActivityIndicatorView.sharedActivityView.showOverlay()
        
            let dict = [PatientInfoKey.CaseID.rawValue: Patient.sharedInfo.patientInfo?.caseID as! AnyObject ]
                APIRequest.sharedAPI.getUndiagnosedCaseDetails(dictionary: dict, completion: {
                    (jsonString, successful, error, response) in
                    dispatch_async(dispatch_get_main_queue(), {
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    if successful {
                        let roleID = LoginManager.getUserRoleId()
                        if (roleID == UserRoles.Cardiologist.rawValue){
                            self.navigateToCardiologistDiagnoseScreen()
                        }
                        else{
                            self.navigateToOnCallCardiologistDiagnoseScreen()
                        }
                    }
                    else{
                        if(response?.statusCode == 403){
                            self.showUnauthorizationAlert()
                        }
                        }
                })
                })
        }
}


