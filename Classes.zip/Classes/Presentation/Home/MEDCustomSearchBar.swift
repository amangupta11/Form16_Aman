//  MEDCustomSearchBar.swift
 //  Copyright © 2016 Medtronic. All rights reserved.


import UIKit
class MEDCustomSearchBar: UISearchBar {
    var preferredFont: UIFont!
    var preferredTextColor: UIColor!
    var searchBar: UISearchBar!
    init(frame: CGRect, font: UIFont, textColor: UIColor) {
        super.init(frame: frame)
        self.frame = frame
        preferredFont = font
        preferredTextColor = textColor
        searchBarStyle = UISearchBarStyle.Prominent
        translucent = false
    }
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    func indexOfSearchFieldInSubviews() -> Int! {
        var index: Int!
        let searchBarView = subviews[0]
        for i in 0 ..< searchBarView.subviews.count {
            if searchBarView.subviews[i].isKindOfClass(UITextField) {
                index = i
                break
            }
        }
        return index
    }
}
// MARK: - Custom Actions
extension MEDCustomSearchBar {
    override func drawRect(rect: CGRect) {
        if let index = indexOfSearchFieldInSubviews() {
            let searchField: UITextField = (subviews[0] ).subviews[index] as! UITextField
            searchField.font = preferredFont
            searchField.textColor = UIColor.whiteColor()
            searchField.backgroundColor = backgroundColor
            searchField.borderStyle = UITextBorderStyle.RoundedRect
            searchField.layer.borderColor = UIColor.clearColor().CGColor
            searchField.clearButtonMode = UITextFieldViewMode.Never
            searchField.attributedPlaceholder = NSAttributedString(string:NSLocalizedString("Search", comment: ""),
                                                                   attributes:[NSForegroundColorAttributeName: UIColor(colorLiteralRed: 239/255, green: 248/255, blue: 253/255, alpha: 1.0)])
        }
        let searchIcon = UIImage(named: ImageConstants.SearchIcon)
        self.setImage(searchIcon, forSearchBarIcon: .Search, state: .Normal)
        super.drawRect(rect)
    }
}
