//  MEDHomeViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.


import UIKit
import CoreData
import Firebase
class MEDHomeViewController: MEDCameraLauncher{
    @IBOutlet weak var noRecordFoundStackView: UIStackView!
    @IBOutlet var noIntConViewHeight: NSLayoutConstraint!
    @IBOutlet var homeScreenListTable: UITableView!
    @IBOutlet var homeSearchBar: MEDCustomSearchBar!
    @IBOutlet var noInternetConnectionView: UIView!
    @IBOutlet var plusIconLabel: UILabel!
    @IBOutlet var addNewCaseButton: UIBarButtonItem!
    @IBOutlet var homeScreenTitle: UINavigationItem!
    var refreshControl: UIRefreshControl?
    var savedContentOffsetY: CGFloat!
    var isServiceRunnig: Bool = false
    var capturedECGImage: UIImage? = nil
    var shouldTableViewRefresh: Bool = false
    var isNewCaseAdded = false
    var tableViewPreviousScrollOffset: CGPoint? = nil
    var isSearchRunning = false
    var isRefreshing = false
    var searchText = ""
    var caseResponseArr = [PatientCaseInfo]()
    var tempArr = [PatientCaseInfo]()
    var currentPage = Int()
    var pageCount = Int()
    struct HomeStringConstants {
        static  var CellIdentifier = "HomeScreenListCell"
        static  var ActivityIndicatorCellIdentifier = "Cell"
        static  var AlertTitle = NSLocalizedString("ATTENTION", comment: "")
        static  var AlertMessage = NSLocalizedString("THERE_HAS_BEEN_AN_UPDATE_ON_THIS_CASE", comment: "")
    }
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUp()
        self.navigationController?.view.userInteractionEnabled = false
        self.searchText = ""
        performGetCASEList(1)
        currentPage = 1
        savedContentOffsetY=0
        tableViewPreviousScrollOffset = self.homeScreenListTable.contentOffset
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(animated: Bool) {
        //self.noRecordFoundStackView.hidden = true
        let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        if(appDelegate!.refreshScreen == true){
            shouldTableViewRefresh = true
            appDelegate!.refreshScreen = false
        }
        if shouldTableViewRefresh == true {
            // Checking for any newly added case
            self.stopRefreshingTable()
            self.stopSearchingTable(self.homeSearchBar)
            ActivityIndicatorView.sharedActivityView.showOverlay()
            self.searchText = ""
            performGetCASEList(1)
            currentPage = 1
            shouldTableViewRefresh = false
            UIView.animateWithDuration(0.2, animations: {
                self.homeScreenListTable.contentOffset = CGPoint(x: 0, y: 0)
            })
        }
        handleRefreshControlAnimation()
        FIRAnalytics.setScreenName(FireBaseConstants.home, screenClass: FireBaseConstants.home)
    }

    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
//        stopRefreshingTable()
        super.viewWillDisappear(animated)
        // savedContentOffsetY = homeScreenListTable.contentOffset.y;

    }
    func handleRefreshControlAnimation() {
        // This code is to handle refresh control when each time we appear to this screen
        // when we move from this screen to any other, this refresh control gets stuck and stop spinning.
        // The below code is to handle the above case
        let offset = self.homeScreenListTable.contentOffset
        if self.refreshControl?.refreshing == true {

            self.refreshControl?.endRefreshing()
            self.refreshControl?.beginRefreshing()
        }
        self.homeScreenListTable.contentOffset = offset
    }
    func performFetch () {
//        if self.isSearchRunning == true && searchText.isEmpty == false {
//            let filteredArray = self.caseResponseArr.filter() {
//                if let firstName = ($0.firstName?.lowercaseString), let lastName = $0.lastName?.lowercaseString , let hospitalCaseID = $0.hospitalCaseID?.lowercaseString, let fmcCentre = ($0.fmcCenter?.abbreviation?.lowercaseString), let treatmentCentre = ($0.treatmentCenter?.abbreviation?.lowercaseString){
//                    return firstName.rangeOfString(self.searchText.lowercaseString) != nil
//                        || lastName.rangeOfString(self.searchText.lowercaseString) != nil || hospitalCaseID.rangeOfString(self.searchText.lowercaseString) != nil || fmcCentre.rangeOfString(self.searchText.lowercaseString) != nil || treatmentCentre.rangeOfString(self.searchText.lowercaseString) != nil
//                }
//                else {
//                    return false
//                }
//            }
//            self.caseResponseArr = filteredArray
//            self.homeScreenListTable.reloadData()
//        } else {
//            self.caseResponseArr = self.tempArr
//        }
    }
}
// MARK: - @IBAction Methods
extension MEDHomeViewController {
    @IBAction func openCameraButtonAction(sender: AnyObject) {
        self.cameraButtonTapped()

    }
}
// MARK: - Custom Actions
extension MEDHomeViewController {
    func initialSetUp() {
        self.navigationItem.rightBarButtonItem = nil
        self.enableAddNewCaseIcon()
        addRefreshControl()
        homeScreenListTable.exclusiveTouch = true
        self.homeSearchBar.keyboardType = UIKeyboardType.ASCIICapable
    }
    func navigateToCardiologistDiagnoseScreen() {
        let vc: MEDCardiologistECGViewController = UIStoryboard(name: StroryBoardNameConstants.SBCardiologist, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.cardiologistDignoseViewControllerSBID) as! MEDCardiologistECGViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func navigateToOnCallCardiologistDiagnoseScreen() {
        let vc: MEDOnCallCardioDiagnosisVC = UIStoryboard(name: StroryBoardNameConstants.SBCardiologist, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.OnCallCardiologistSBID) as! MEDOnCallCardioDiagnosisVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func addNewCase() {
        Patient.sharedInfo.patientInfo = PatientCaseInfo()
        self.view.endEditing(true)
        shouldTableViewRefresh = true
        handleFMCTime()
    }

    func stopRefreshingTable() {
        self.view.endEditing(true)
        self.homeScreenListTable.userInteractionEnabled = true
        if let _ = self.refreshControl {
            self.refreshControl!.endRefreshing()
        }
        self.reloadTable()
    }

    func stopSearchingTable(searchBar: UISearchBar?) {
        self.isSearchRunning = false
        searchBar!.text = ""
        searchBar!.showsCancelButton = false
        self.homeScreenListTable.addSubview(refreshControl!)
    }
    func navigateToViewSummary() {
        let storyBoard: UIStoryboard = UIStoryboard(name: StroryBoardNameConstants.SBNameECGCapture, bundle:nil)
        let vc = storyBoard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.viewSummaryScreenSBID) as! MEDViewSummaryViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }

    func navigateToPatientInfoView() {
        let storyBoard: UIStoryboard = UIStoryboard(name: StroryBoardNameConstants.SBCreateCase, bundle:nil)
        let vc = storyBoard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.patientBaseViewControllerSBID) as! MEDPatientBaseContainerView
        self.navigationController?.pushViewController(vc, animated: true)
    }

    func handleFMCTime() {
        Patient.sharedInfo.patientInfo?.timeLine?.addNewCaseTime = DateUtility.getCurrentTimeInGMT()
        Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInTime = DateUtility.getCurrentTimeInGMT()
    }
    func updateUI() {
        if(NetworkUtil.isConnected()) {
            if (self.caseResponseArr.count > 0) {
                enableUI(false, isInternetLableHidden: true)} else {
                enableUI(false, isInternetLableHidden:true)}
        } else {
            enableUI(false, isInternetLableHidden:false)}
    }
    func presentNoInternetConnectionLabel(isConnected: Bool) {
        noInternetConnectionView.hidden = isConnected
    }
    func enableUI(isTableHidden: Bool, isInternetLableHidden: Bool) {
        presentNoInternetConnectionLabel(isInternetLableHidden)
        homeScreenListTable.hidden = isTableHidden
        if isInternetLableHidden {
            noIntConViewHeight.constant = 0} else {
            noIntConViewHeight.constant = 28
        }
    }
    
    func enableAddNewCaseIcon() {
        let roleID = LoginManager.getUserRoleId()
            switch roleID{
            case "1":
                self.navigationItem.rightBarButtonItem = addNewCaseButton
                plusIconLabel.hidden = false
                homeScreenTitle.title = NSLocalizedString("Recent Cases", comment: "")
            case "2":
                self.navigationItem.rightBarButtonItem = nil
                plusIconLabel.hidden = true
            case "3":
                self.navigationItem.rightBarButtonItem = nil
                plusIconLabel.hidden = true
                homeScreenTitle.title = NSLocalizedString("Un-diagnosed Cases", comment: "")
            case "7":
                self.navigationItem.rightBarButtonItem = nil
                plusIconLabel.hidden = true
            default: break
            }
    }
    func showUnauthorizationAlert() {
        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        alertView = alertController.showSimpleAlert(HomeStringConstants.AlertTitle, message:HomeStringConstants.AlertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)
    }
    func configureCellData(cell: MEDHomeScreenTableViewCell, indexpath: NSIndexPath) {
        // Fetch Record
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        cell.statusView.backgroundColor = UIColor.clearColor()
        cell.statusImage.backgroundColor = UIColor.whiteColor()
        let cellPatient = self.caseResponseArr[indexpath.row] as PatientCaseInfo
        let patientName = self.getpatientName(cellPatient)
        if patientName.characters.count > 2{
        cell.patientCaseID.text = cellPatient.hospitalCaseID! + ":" + patientName.uppercaseString
        }
        else{
        cell.patientCaseID.text = cellPatient.hospitalCaseID
        }
        
        let status = cellPatient.caseStatus
        let (color) = getStatusImage(status!, cell:cell)
        cell.status.textColor = color
        cell.statusImage.image = nil//image
        cell.statusView.backgroundColor = color
        
        let doorInTimeString = DateUtility.convertGMTtoShortDate((cellPatient.timeLine?.fmcDoorInTime)!)
        cell.fmcDate?.text = doorInTimeString
        
        var fmcCenter: String? = ""
        if let _ = cellPatient.fmcCenter!.abbreviation {
            fmcCenter = cellPatient.fmcCenter!.abbreviation
        }
        var drName = ""
        if let _ = cellPatient.caseCreatedUserName {
            drName = (cellPatient.caseCreatedUserName)!
        }
        if(drName.isEmpty == false && fmcCenter?.isEmpty == false) {
            cell.drName.text = drName + " (" + fmcCenter! + ")"
        }
        
        if let _ = cellPatient.treatmentCenter?.abbreviation {
            cell.treatmentCenter.text = (cellPatient.treatmentCenter?.abbreviation)!
        }
        
        if  cellPatient.treatmentCenter?.abbreviation == nil {
            cell.treatmentCenterLineLabel.hidden = false
            cell.treatmentCenter.text = ""
        } else {
            cell.treatmentCenter.text = cellPatient.treatmentCenter?.abbreviation
            cell.treatmentCenterLineLabel.hidden = true
        }
        
        
        let roleID = LoginManager.getUserRoleId()
        if (roleID == "3") {
                cell.treatmentCenterLineLabel.hidden = true
                cell.treatmentCenter.hidden = true
                cell.treatmentCenterLabel.hidden = true
        }
        if(status == 13){
            cell.drName.textColor = ColorPicker.battleshipGrey()
            cell.treatmentCenter.textColor = ColorPicker.battleshipGrey()
            cell.fmcDate?.textColor = ColorPicker.battleshipGrey()
            cell.patientCaseID.textColor = ColorPicker.battleshipGrey()
        }
        else{
            cell.drName.textColor = ColorPicker.greyishBrown()
            cell.treatmentCenter.textColor = ColorPicker.greyishBrown()
            cell.fmcDate?.textColor = ColorPicker.greyishBrown()
            cell.patientCaseID.textColor = ColorPicker.greyishBrown()
        }
    }

    func getStatusImage(statusStr: Int, cell: MEDHomeScreenTableViewCell) -> (UIColor) {
        // var image: UIImage!
        var color: UIColor!
        switch statusStr {
        case 4:
            color = ColorPicker.steelGreyColor()
            cell.status.text = StatusConstants.Diagnosed
        case 3:
            color = ColorPicker.steelGreyColor()
            cell.status.text = StatusConstants.UnderObservation
        case 2:
            color = ColorPicker.steelGreyColor()
            cell.status.text = StatusConstants.Undiagnosed
        case 5:
            color = ColorPicker.deepOrange()
            cell.status.text = StatusConstants.STEMI
        case 1:
            color = ColorPicker.steelGreyColor()
            cell.status.text = StatusConstants.New
        case 6:
            color = ColorPicker.yellowOrange()
            cell.status.text = StatusConstants.InTransit
        case 11:
            color = ColorPicker.appleGreen()
            cell.status.text = StatusConstants.Completed
        case 7:
            color = ColorPicker.yellowOrange()
            cell.status.text = StatusConstants.InternalTransfer
        case 8:
            color = ColorPicker.yellowOrange()
            cell.status.text = StatusConstants.CathLabAccepted
        case 9:
            color = ColorPicker.appleGreen()
            cell.status.text = StatusConstants.DeviceCrossTime
        case  10:
            color = ColorPicker.appleGreen()
            cell.status.text = StatusConstants.CathLabExit
        case  12:
            color = ColorPicker.appleGreen()
            cell.status.text = StatusConstants.NotAStemi
        case  13:
            color = ColorPicker.fadedOrange()
            cell.status.text = StatusConstants.Cancelled
        default:
            color = ColorPicker.appleGreen()
            cell.status.text = StatusConstants.NotAStemi
        }
        return (color)
    }
    func reloadTable() {
        self.performFetch()
        self.updateUI()
        self.homeScreenListTable.reloadData()
//        UIView.animateWithDuration(0.2, animations: {
//            self.homeScreenListTable.contentOffset = CGPoint(x: 0, y: 0)
//        })

    }
    func getpatientName(patientInfo : PatientCaseInfo?) -> String{
        var patientName:String = ""
        var firstName:String = ""
        var middleName:String = ""
        var lastName:String = ""
        
        if patientInfo?.middleName != nil && patientInfo?.middleName != ""{
            let middleNameStr = patientInfo?.middleName
            middleName = String(middleNameStr!.characters.prefix(1))
        }
        if patientInfo?.firstName != nil{
            firstName = (patientInfo?.firstName)!
        }
        if patientInfo?.lastName != nil{
            lastName = (patientInfo?.lastName)!
        }
        patientName = firstName + " " + middleName + " " + lastName
        return patientName
    }
    // MARK: - Segue Methods
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
//        let vc = segue.destinationViewController as! MEDPatientBaseContainerView
        self.addNewCase()
        //vc.patientInfo = patientInfo
    }
    //MARK: - Image Picker Delegates
    func cameraButtonTapped() {
        self.presentCamera()
    }
    override  func imagePickerController(
        picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        capturedECGImage = info[UIImagePickerControllerOriginalImage] as? UIImage
        let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        appDelegate?.isCameraOpen = false
        addNewCase()
    }

    override func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        appDelegate?.isCameraOpen = false
        imagePicker!.dismissViewControllerAnimated(true, completion: nil)
        self.capturedECGImage = nil

    }

    func addRefreshControl() {
        refreshControl = UIRefreshControl()
        refreshControl!.addTarget(self, action: #selector(refresh(_:)), forControlEvents: .ValueChanged)
        self.homeScreenListTable.addSubview(refreshControl!)
    }
    func refresh(refreshControl: UIRefreshControl) {
        // Do your job, when done:
        if !isRefreshing{
            self.isRefreshing = true
            //self.caseResponseArr.removeAll()
             self.stopSearchingTable(self.homeSearchBar)
            self.searchText = ""
            self.performGetCASEList(1)
            currentPage = 1
        }
        //        refreshControl.endRefreshing()
    }
    
    func sortCaseList(caseList: [PatientCaseInfo]) ->[PatientCaseInfo]
    {
        return caseList.sort{$0.timeLine?.addNewCaseTime > $1.timeLine?.addNewCaseTime}
    }

}
// MARK: - tableView Delegate methods
extension MEDHomeViewController:UITableViewDelegate {
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return UIView()
    }
    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 6
    }
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return 6
        }
        return 44
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if caseResponseArr.count > 0 && self.currentPage != self.pageCount{
           return caseResponseArr.count + 1}
        else{
           return caseResponseArr.count
        }
    }
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.row == self.caseResponseArr.count{
            return 61
        }
      return 122
    }
}
// MARK: - tableView DataSource methods
extension  MEDHomeViewController:UITableViewDataSource {
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if indexPath.row == self.caseResponseArr.count && self.currentPage != self.pageCount{
            let  cell = tableView.dequeueReusableCellWithIdentifier(HomeStringConstants.ActivityIndicatorCellIdentifier, forIndexPath: indexPath) as! ActivityIndicatorTableViewCell
            cell.activityIndicator.startAnimating()
            return cell
            }
        else {
            let cell = tableView.dequeueReusableCellWithIdentifier(HomeStringConstants.CellIdentifier, forIndexPath: indexPath) as! MEDHomeScreenTableViewCell
            configureCellData(cell, indexpath: indexPath)
            return cell
        }
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        self.view.endEditing(true)
        let selectedPatientInfo = self.caseResponseArr[indexPath.row]
        PatientManager.initializePatient()
        Patient.sharedInfo.patientInfo = selectedPatientInfo
        let roleID = LoginManager.getUserRoleId()
        let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        appDelegate?.currentCaseStatus = selectedPatientInfo.caseStatus!
        if (selectedPatientInfo.caseStatus == statusKey.Undiagnosed.rawValue && (roleID == UserRoles.Cardiologist.rawValue || roleID == UserRoles.OnCallCardiologist.rawValue)) {
            getUndiagnosedCaseDetails()
        } else {
            performGetCASEDetails()
        }
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
    }


    func scrollViewDidScroll(scrollView: UIScrollView) {
        // Updating the no record found label's frame when scrolling the table view
        self.view.endEditing(true)
        //self.stopSearchingTable(self.homeSearchBar)
        let delta =  scrollView.contentOffset.y - tableViewPreviousScrollOffset!.y
        self.noRecordFoundStackView.frame.origin.y =  self.noRecordFoundStackView.frame.origin.y - delta
        self.view.layoutIfNeeded()
        tableViewPreviousScrollOffset = scrollView.contentOffset
        
        let scrollViewHeight = scrollView.frame.size.height
        let scrollContentSizeHeight = scrollView.contentSize.height
        let scrollOffset = scrollView.contentOffset.y
        if (scrollOffset + scrollViewHeight == scrollContentSizeHeight){
            // then we are at the end
            if self.currentPage != pageCount{
                self.currentPage += 1
                self.performGetCASEList(self.currentPage)
            }
        }
    }
}

// MARK: UISearchBarDelegate
extension MEDHomeViewController:UISearchBarDelegate {
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        // Search button tapped
        // Dismissing the keyboard
        FIRAnalytics.logEventWithName(FireBaseEvents.search, parameters:nil)
        ActivityIndicatorView.sharedActivityView.showOverlay()
        self.performGetCASEList(1)
        currentPage = 1
        searchBar.resignFirstResponder()
    }
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        self.stopSearchingTable(searchBar)
        if(self.searchText.isEmpty == false){
        self.searchText = ""
        ActivityIndicatorView.sharedActivityView.showOverlay()
        self.performGetCASEList(1)
        }
        searchBar.resignFirstResponder()
    }
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        FIRAnalytics.logEventWithName(FireBaseEvents.initiateSearch, parameters:nil)
        self.refreshControl?.removeFromSuperview()
        searchBar.showsCancelButton = true
        for sView in searchBar.subviews {
            for ssView in sView.subviews {
                if ssView.isKindOfClass(UIButton.self) {
                    let cancelButton = ssView as! UIButton
                    cancelButton.setTitle("Cancel", forState: .Normal)
                    cancelButton.titleLabel?.font = UIFont(name: "Effra", size: 15.0)
                    break
                } else if ssView.isKindOfClass(UITextField.self) {
                    let searchTextField = ssView as! UITextField
                    searchTextField.font = UIFont(name: "Effra", size: 14)
                }
            }
        }
    }
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        // Code for handling the search results
            isSearchRunning = true
            self.searchText = searchText
            self.reloadTable()

    }
    func searchBar(searchBar: UISearchBar, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        let updatedString = (searchText as NSString?)?.stringByReplacingCharactersInRange(range, withString: text)
        if( updatedString == " "){
            return false
        }
        return true
    }
}
//MARK: - Alert view delegates
extension MEDHomeViewController: AlertViewControllerProtocol {
    func cancelButtonAction(alertController: UIAlertController) {
    }
    func OKButtonAction(alertController: UIAlertController) {
    }
    func defaultButtonAction(alertController: UIAlertController) {
            // Moving the user to home listing screen
            self.refresh(refreshControl!)
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }
    }