//  MEDBaseViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
enum status: String {
    case New = "1"
    case Undiagnosed = "2"
    case UnderObservation = "3"
    case Diagnosed = "4"
    case STEMI = "5"
    case InTransit = "6"
    case InternalTransfer = "7"
    case CathLabAccepted = "8"
    case DeviceCrossTime = "9"
    case CathLabExit = "10"
    case Completed = "11"
    case NotAStemi = "12"
    case Cancelled = "13"

}

enum statusKey: Int {
    case New = 1
    case Undiagnosed = 2
    case UnderObservation = 3
    case Diagnosed = 4
    case STEMI = 5
    case InTransit = 6
    case InternalTransfer = 7
    case CathLabAccepted = 8
    case DeviceCrossTime = 9
    case CathLabExit = 10
    case Completed = 11
    case NotAStemi = 12
    case Cancelled = 13
    
}

enum AlertViewTag: Int {
    case AlertViewTagForBackButton = 101
    case AlertViewTagForStemiButton = 102
    case AlertViewTagForNotAStemiSuccess = 103
    case AlertViewTagForStemiTransfer = 104
}
enum GenderButtonTag: Int {
    case Male = 1011
    case Female = 1022
}
class MEDBaseViewController: UIViewController {
    var timer: NSTimer? = nil
    var currentTextFieldTag: Int?
    var keyboardNextButton: UIBarButtonItem?
    var keyboardPreviousButton: UIBarButtonItem?

    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    // MARK: - initial SetUp
    func initialSetUp(bgImage: String) {
        setBackgroundImageToView(bgImage)
    }
    // MARK: - Handling Obervers
    func addKeyboardObserver(viewController: UIViewController) {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.keyboardWillShow(_:)), name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.keyboardWillHide(_:)), name: UIKeyboardWillHideNotification, object: nil)
    }
    func removeKeyBoardObserver(viewController: UIViewController) {
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillHideNotification, object: nil)
    }
    // MARK: - Common functions
    func getBuildVersion() -> String {
        var shtVerStr = ""
        if let shortVerStr = self.getBundleShortVersion(){
            shtVerStr = shortVerStr
        }
        return String(format: "V# %@", shtVerStr)
    }
    func getBundleShortVersion() -> String?{
        let dictionary = NSBundle.mainBundle().infoDictionary!
        let shortVerStr = dictionary[bundleConstants.ShortVersion] as? String
        return shortVerStr
    }
    func getBundleVersion() -> String?{
        let dictionary = NSBundle.mainBundle().infoDictionary!
        let bundleVerStr = dictionary[bundleConstants.BundleVersion] as? String
        return bundleVerStr
    }
    
    func setBackgroundImageToView(bgImage: String) {
        let bgImageView = UIImageView()
        bgImageView.image = UIImage(named: bgImage)
        bgImageView.frame = CGRectMake(0, 0, view.frame.size.width, view.frame.size.height)
        bgImageView.layer.zPosition = -10
        self.view.addSubview(bgImageView)
    }
    func setNavigationBackButtonImage() {
        let image = UIImage(named: ButtonTitles.BackIcon)
        let backButton = UIButton(type: UIButtonType.Custom)
        backButton.addTarget(self, action: #selector(backButtonAction), forControlEvents: UIControlEvents.TouchUpInside)
        backButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: -30, bottom: 0, right: -10)
        backButton.setImage(image, forState: UIControlState.Normal)
        backButton.sizeToFit()
        let backButtonItem = UIBarButtonItem(customView: backButton)
        self.navigationItem.leftBarButtonItem = backButtonItem
    }
    func backButtonAction(button: UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    // MARK: - Internet Check
    func checkInternet() {
        if NetworkUtil.isConnected() == false {
            ActivityIndicatorView.sharedActivityView.hideOverlayView()
            showAlert( NSLocalizedString("NO_INTERNET_CONNECTION", comment: ""), alertMsg: NSLocalizedString("YOUR_REQUEST_COULD_NOT_BE_COMPLETED", comment: ""))
            return
        }
        ActivityIndicatorView.sharedActivityView.showOverlay()
    }

    func handleError(serverError: NSError?) {
        dispatch_async(dispatch_get_main_queue(), {
            ActivityIndicatorView.sharedActivityView.hideOverlayView()
            var errorMessage = StringConstants.ErrorTitle
            if let error = serverError {
                errorMessage = error.localizedDescription
            }
            self.showAlert(NSLocalizedString("ERROR", comment: ""), alertMsg:errorMessage)
        })
    }

    // MARK: - Keyboard Notification Handling
    func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.CGRectValue() {
            UIView.animateWithDuration(0.25, animations: { () -> Void in
                self.view.frame.origin.y = -keyboardSize.height+150
            })
        }
    }
    func keyboardWillHide(notification: NSNotification) {
        UIView.animateWithDuration(0.25, animations: { () -> Void in
            self.view.frame.origin.y = 0
        })
    }
    // MARK: - @DisableCopyPaste
    override func canPerformAction(action: Selector, withSender sender: AnyObject?) -> Bool {
        NSOperationQueue.mainQueue().addOperationWithBlock({
            UIMenuController.sharedMenuController().setMenuVisible(false,
                animated: false)})
        return super.canPerformAction(action, withSender: sender)
    }
    // MARK: - Handle Alert

    func showAlert(alertTile: String, alertMsg: String) {
        dispatch_async(dispatch_get_main_queue(), {
            var alertView: UIAlertController?
            let alertController = AlertController()
            alertView = alertController.showSimpleAlert(alertTile, message:alertMsg, preferredStyle: UIAlertControllerStyle.Alert)
            self.presentViewController(alertView!, animated: true, completion: nil)

        })
    }
    // MARK: - Handle Timer
    func startTimer() {
        invalidateTimer()
        if (Patient.sharedInfo.patientInfo?.caseStatus == statusKey.Completed.rawValue || Patient.sharedInfo.patientInfo?.caseStatus == statusKey.CathLabExit.rawValue || Patient.sharedInfo.patientInfo?.caseStatus == statusKey.Cancelled.rawValue) {
            displayTime()
        } else {
            timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
        }
    }
    func invalidateTimer() {
        if timer != nil {
            timer!.invalidate()
        }
    }
    func updateTimer() {
        if(Patient.sharedInfo.patientInfo?.timeLine != nil) {
            displayTime()
        } else {
            invalidateTimer()
        }
    }
    func displayTime() {
        if let fmcDoorIn = Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInTime{
        let fmcDate = NSDate(timeIntervalSince1970: fmcDoorIn)
            var interval = NSDate().timeIntervalSinceDate(fmcDate)
            if Patient.sharedInfo.patientInfo?.timeLine?.stoppedTime != nil && Patient.sharedInfo.patientInfo?.timeLine?.stoppedTime != 0 {
                let stoppeTime = Patient.sharedInfo.patientInfo?.timeLine?.stoppedTime
                let stoppedDate = NSDate(timeIntervalSince1970: stoppeTime!)
                interval = stoppedDate.timeIntervalSinceDate(fmcDate)
            }
            self.title = stringFromTimeInterval(interval)
        }
    }
    func displayCompeletedTime() {
        if let fmcDoorIn = Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInTime{
           let date = NSDate(timeIntervalSince1970: fmcDoorIn)
            if let deviceCrossTime = Patient.sharedInfo.patientInfo?.timeLine!.deviceCrossTime{
            if Patient.sharedInfo.patientInfo?.timeLine!.deviceCrossTime != 0 {
                let  completedDate = NSDate(timeIntervalSince1970: deviceCrossTime)
                let interval = completedDate.timeIntervalSinceDate(date)
                 self.title = stringFromTimeInterval(interval)
                }
                
            } else {
                displayTime()
            }
        }
    }
    func stringFromTimeInterval(interval: NSTimeInterval) -> String {

        let duration: NSTimeInterval = interval
        let s: Int = Int(duration) % 60
        let m: Int = Int(duration) / 60
        let formattedDuration = String(format: "%0d:%02d", m, s)
        return formattedDuration
        //
        //        let ti = Int(interval)
        //        let seconds = ti % 60
        //        let minutes = (ti / 60) % 60
        //        let hours = (ti / 3600)
        //        return String(format: "%0.2d:%0.2d:%0.2d", hours, minutes, seconds)
    }
    
    func updateKeyboardToolbar(inputField: AnyObject){
        
        if let _ = self.view.viewWithTag(inputField.tag-1){
            self.keyboardPreviousButton?.enabled = true
            self.keyboardPreviousButton?.image = UIImage(named:ImageConstants.PrevKeyImg)
            
        }else {
            self.keyboardPreviousButton?.enabled = false
            self.keyboardPreviousButton?.image = UIImage(named:ImageConstants.PrevKeyDisabledImg)
        }
        
        if self.view.viewWithTag(inputField.tag+1) != nil{
            self.keyboardNextButton?.enabled = true
            self.keyboardNextButton?.image = UIImage(named:ImageConstants.NextKeyImg)
        }else{
            self.keyboardNextButton?.image = UIImage(named:ImageConstants.NextKeyDisabledImg)
            
            self.keyboardNextButton?.enabled = false
            
        }
    }

    lazy var inputToolbar: UIToolbar = {
        var toolbar = UIToolbar()
        toolbar.barStyle = .Default
        toolbar.translucent = true
        toolbar.sizeToFit()
        toolbar.frame.size.height = 35
        var doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.Plain, target: self, action: #selector(inputToolbarDonePressed(_:)))
        var flexibleSpaceButton = UIBarButtonItem(barButtonSystemItem: .FlexibleSpace, target: nil, action: nil)
        var fixedSpaceButton = UIBarButtonItem(barButtonSystemItem: .FixedSpace, target: nil, action: nil)
        
        self.keyboardNextButton = UIBarButtonItem(image: UIImage(named:"nextKeyoardImage"), style: .Plain, target: self, action: #selector(keyboardNextButtonAction(_:)))
        self.keyboardNextButton!.width = 35.0
           self.keyboardPreviousButton = UIBarButtonItem(image: UIImage(named:"previousKeyboardImage"), style: .Plain, target: self, action: #selector(keyboardPreviousButtonAction(_:)))
        
        
        toolbar.setItems([fixedSpaceButton, self.keyboardPreviousButton!, fixedSpaceButton, self.keyboardNextButton!, flexibleSpaceButton, doneButton], animated: false)
        toolbar.userInteractionEnabled = true
        
        return toolbar
    }()
    
    func inputToolbarDonePressed(sender: UIBarButtonItem){
        self.view.endEditing(true)
    }
    
    func keyboardNextButtonAction(sender: UIBarButtonItem){
        if let view = self.view.viewWithTag(currentTextFieldTag!+1){
        view.becomeFirstResponder()
        }
    }
    
    func keyboardPreviousButtonAction(sender: UIBarButtonItem){
        let view = self.view.viewWithTag(currentTextFieldTag!-1)
        view?.becomeFirstResponder()
    }
}
