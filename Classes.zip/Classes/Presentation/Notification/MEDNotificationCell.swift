//  MEDNotificationCell.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

class MEDNotificationCell: UITableViewCell {
    
    @IBOutlet weak var timerImageView: UIImageView!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var hospitalCaseIdLabel: UILabel!
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var timestampLabel: UILabel!
    var leftBorderLayer : CALayer!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        bgView.layer.shadowColor = UIColor.blackColor().CGColor
        bgView.layer.shadowOpacity = 0.2
        bgView.layer.shadowOffset = CGSizeMake(1, 1)
        bgView.layer.masksToBounds = false
        bgView.layer.shadowRadius = 3
        addStatusLayer()
        read(false)
    }
    private func addStatusLayer()
    {
        leftBorderLayer = CALayer()
        leftBorderLayer.frame = CGRectMake(0, 0, 5, self.frame.size.height-10);
        bgView.layer.addSublayer(leftBorderLayer)
    }
    func read(isRead : Bool)
    {
        leftBorderLayer.backgroundColor = ColorPicker.pickerViewDoneButtonBackgroundColor().CGColor
        timerImageView.image = UIImage(named:"TimerUnread")
        timestampLabel.textColor = ColorPicker.pickerViewDoneButtonBackgroundColor()
        if isRead
        {
            leftBorderLayer.backgroundColor = ColorPicker.ligthGrey().CGColor
            timerImageView.image = UIImage(named:"TimerRead")
            timestampLabel.textColor = ColorPicker.ligthGrey()
        }
    }
}
