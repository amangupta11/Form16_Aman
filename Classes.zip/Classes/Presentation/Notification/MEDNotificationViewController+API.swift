//  MEDNotificationViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import SwiftyJSON

extension MEDNotificationViewController {
    func getNotifications() {
        APIRequest.sharedAPI.requestNotification() {
            (notifications, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                let parsedNotifs = self.parse(notifications)
                self.updateData(self.sortNotifications(parsedNotifs))
            })
        }
    }
    func getAllCases(completion: (isSuccessful: Bool) -> Void) {
        let dict = [String:String]()
        ActivityIndicatorView.sharedActivityView.showOverlay()
        APIRequest.sharedAPI.getCASEList(dictionary:dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if !successful {
                    var errorMessage = StringConstants.ErrorTitle
                    if let error = error {
                        errorMessage = error.localizedDescription
                    }
                    super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                }
                else{
                var patientListArr = [PatientCaseInfo]()
                for object in (jsonString?.array)!{
                    let patientCaseInfo = PatientCaseInfo()
                    patientCaseInfo.updatePatientData(object)
                    patientListArr.append(patientCaseInfo)
                }
                self.caseListArr = patientListArr
                }
                completion(isSuccessful: successful)
            })
        })
    }
    
    func getCaseDetails(patient: PatientCaseInfo) {
        checkInternet()
        if  patient.caseID != nil {
            let dict = [PatientInfoKey.CaseID.rawValue:patient.caseID as! AnyObject]
            APIRequest.sharedAPI.getCASEDetails(dictionary:dict, completion: {
                (jsonString, successful, error, response) in
                dispatch_async(dispatch_get_main_queue(), {
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    if successful {
                        PatientManager.updateCaseDetails(jsonString)
                        if (patient.caseStatus == statusKey.Diagnosed.rawValue || patient.caseStatus == statusKey.UnderObservation.rawValue || patient.caseStatus == statusKey.New.rawValue) {
                            self.navigateToPatient(patient)
                        } else {
                            self.navigateToSummary(patient)
                        }
                    } else {
                        var errorMessage = StringConstants.ErrorTitle
                        if let error = error {
                            errorMessage = error.localizedDescription
                        }
                        super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                    }
                })
            })
        }
    }
    
    func getUndiagnosedCaseDetails(selectedPatient: PatientCaseInfo) {
        checkInternet()
        ActivityIndicatorView.sharedActivityView.showOverlay()
        let dict = [PatientInfoKey.CaseID.rawValue: selectedPatient.caseID as! AnyObject ]
        APIRequest.sharedAPI.getUndiagnosedCaseDetails(dictionary: dict,completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    let roleID = Patient.sharedInfo.userInfo!.roleID! 
                    if (roleID == UserRoles.Cardiologist.rawValue){
                        self.navigateToCardiologist()
                    }
                    else{
                        self.navigateToOnCallCardiologist()
                    }
                }
                else {
                    if(response?.statusCode == 403){
                        self.showUnauthorizationAlert()
                    }
                    else{
                    var errorMessage = StringConstants.ErrorTitle
                    if let error = error {
                        errorMessage = error.localizedDescription
                    }
                    super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                    }
                }
            })
        })
    }
    
    func markAsRead(notification: Notification)
    {
        APIRequest.sharedAPI.requestRead(notification, completion: {
            (jsonString, successful, error, response) in
        })
    }
    
    class func unreadCount(completion: (Int)->Void)
    {
        APIRequest.sharedAPI.requestUnreadCount({(jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                if successful
                {
                    if let count : Int = jsonString?.int
                    {
                        completion(count)
                    }
                }
            })
        })
    }
    
    private func parse(notifications : JSON?) ->[Notification]
    {
        var parsedNotifs = [Notification]()
        let isAvailable = notifications != nil && notifications!.arrayObject != nil
        if !isAvailable{
            return parsedNotifs
        }
        
        for notification in notifications!.arrayObject! {
            let notificationId = notification[StringConstants.NotificationId] as! String
            let caseID = notification[StringConstants.CaseID] as! String
            let message = notification[StringConstants.Message] as! String
            let hospitalCaseID = notification[StringConstants.HospitalCaseID] as! String
            let isRead = notification[StringConstants.ReadStatus] as! Bool
            var time = notification[StringConstants.SentTime] as! NSTimeInterval
            time = time/1000 // Time in milli second
            let notif = Notification(notificationId: notificationId, caseID: caseID, hospitalCaseID: hospitalCaseID,  message: message,sentTime: time, isRead: isRead)
            parsedNotifs.append(notif)
        }
        return parsedNotifs
    }
    
    private func sortNotifications(notifications: [Notification]) ->[Notification]
    {
        return notifications.sort{$0.sentTime > $1.sentTime}
    }
    
}
