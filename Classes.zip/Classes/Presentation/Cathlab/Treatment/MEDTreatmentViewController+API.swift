//  MEDTreatmentViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
// MARK: -  Server Interaction
extension MEDTreatmentViewController {
    func performCathLabAcceptedCall() {
        checkInternet()
        var dict: NSDictionary? = nil
        var cathLabAcceptedTime: [String:AnyObject] = [:]
        cathLabAcceptedTime[TimeLineKey.Comment.rawValue] = nil
        cathLabAcceptedTime[TimeLineKey.Location.rawValue] = nil
        let myDouble = NSNumber(double: (Patient.sharedInfo.patientInfo?.timeLine?.cathLabAcceptedTime)!)
        cathLabAcceptedTime[TimeLineKey.Time.rawValue] = myDouble.stringValue
        dict = [PatientInfoKey.CaseID.rawValue:(Patient.sharedInfo.patientInfo?.caseID)!, TimeLineKey.CathLabAcceptedTime.rawValue:cathLabAcceptedTime]
        APIRequest.sharedAPI.performCathLabAccepted(dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.enableCathLabAcceptedButton()
                } else {
                    if(response?.statusCode == 403){
                        self.showUnauthorizationAlert()
                    }
                    else{
                        var errorMessage = StringConstants.ErrorTitle
                        if let error = error {
                            errorMessage = error.localizedDescription
                        }
                        super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                    }
                }
            })
        })
    }
    func performDeviceCrossTimeCall() {
        checkInternet()
        var dict: NSDictionary? = nil
        var deviceCrossTime: [String:AnyObject] = [:]
        deviceCrossTime[TimeLineKey.Comment.rawValue] = nil
        deviceCrossTime[TimeLineKey.Location.rawValue] = nil
        let myDouble = NSNumber(double: (Patient.sharedInfo.patientInfo?.timeLine?.deviceCrossTime)!)
        deviceCrossTime[TimeLineKey.Time.rawValue] = myDouble.stringValue
        var stoppedTime: [String:AnyObject] = [:]
        stoppedTime[TimeLineKey.Comment.rawValue] = nil
        stoppedTime[TimeLineKey.Location.rawValue] = nil
        stoppedTime[TimeLineKey.Time.rawValue] = myDouble.stringValue

        dict = [PatientInfoKey.CaseID.rawValue:(Patient.sharedInfo.patientInfo?.caseID)!, TimeLineKey.DeviceCrossTime.rawValue:deviceCrossTime, TimeLineKey.StoppedTime.rawValue:stoppedTime]

        APIRequest.sharedAPI.performDeviceCrossTime(dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.enableDeviceCrossTimeButton()
                } else {
                    if(response?.statusCode == 403){
                        self.showUnauthorizationAlert()
                    }
                    else{
                        var errorMessage = StringConstants.ErrorTitle
                        if let error = error {
                            errorMessage = error.localizedDescription
                        }
                        super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                    }
                }
            })
        })
    }
    func performCathLabExitCall() {
        checkInternet()
        var dict: NSDictionary? = nil
        var cathLabExitTime: [String:AnyObject] = [:]
        cathLabExitTime[TimeLineKey.Comment.rawValue] = nil
        cathLabExitTime[TimeLineKey.Location.rawValue] = nil
        let myDouble = NSNumber(double: (Patient.sharedInfo.patientInfo?.timeLine?.cathLabExitTime)!)
        cathLabExitTime[TimeLineKey.Time.rawValue] = myDouble.stringValue
        dict = [PatientInfoKey.CaseID.rawValue:(Patient.sharedInfo.patientInfo?.caseID)!, TimeLineKey.CathLabExitTime.rawValue:cathLabExitTime]
        APIRequest.sharedAPI.performCathLabExit(dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.enableCathLabExitButton()
                } else {
                    if(response?.statusCode == 403){
                        self.showUnauthorizationAlert()
                    }
                    else{
                        var errorMessage = StringConstants.ErrorTitle
                        if let error = error {
                            errorMessage = error.localizedDescription
                        }
                        super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                    }
                }
            })
        })
    }
    func performTreatmentCompleteCall() {
        checkInternet()
        var dict: NSDictionary? = nil

        var treatmentCompletedTime: [String:AnyObject] = [:]
        treatmentCompletedTime[TimeLineKey.Comment.rawValue] = nil
        treatmentCompletedTime[TimeLineKey.Location.rawValue] = nil
        let myDouble = NSNumber(double: (Patient.sharedInfo.patientInfo?.timeLine?.treatmentCompletedTime)!)
        treatmentCompletedTime[TimeLineKey.Time.rawValue] = myDouble.stringValue
        dict = [PatientInfoKey.CaseID.rawValue:(Patient.sharedInfo.patientInfo?.caseID)!, TimeLineKey.TreatmentCompletedTime.rawValue:treatmentCompletedTime]
        APIRequest.sharedAPI.performTreatmentCompleted(dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.navigateToHomeListScreen()
                } else {
                    if(response?.statusCode == 403){
                        self.showUnauthorizationAlert()
                    }
                    else{
                        var errorMessage = StringConstants.ErrorTitle
                        if let error = error {
                            errorMessage = error.localizedDescription
                        }
                        super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                    }
                }
            })
        })
    }
    
    func performCathLabReady(){
        checkInternet()
        Patient.sharedInfo.patientInfo?.timeLine?.cathLabReadyToAcceptCaseTime = DateUtility.getCurrentTimeInGMT()
        var dict: NSDictionary? = nil
        var cathLabReadyTime: [String:AnyObject] = [:]
        cathLabReadyTime[TimeLineKey.Comment.rawValue] = nil
        cathLabReadyTime[TimeLineKey.Location.rawValue] = nil
        let myDouble = NSNumber(double: (Patient.sharedInfo.patientInfo?.timeLine?.cathLabReadyToAcceptCaseTime)!)
        cathLabReadyTime[TimeLineKey.Time.rawValue] = myDouble.stringValue
        dict = [PatientInfoKey.CaseID.rawValue:(Patient.sharedInfo.patientInfo?.caseID)!, TimeLineKey.CathLabReadyToAcceptCaseTime.rawValue:cathLabReadyTime]
        APIRequest.sharedAPI.performCathLabReady(dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.animateCathLabready()
                    self.treatmentOverlayView.hidden = true
                } else {
                    if(response?.statusCode == 403){
                        self.showUnauthorizationAlert()
                    }
                    else{
                        var errorMessage = StringConstants.ErrorTitle
                        if let error = error {
                            errorMessage = error.localizedDescription
                        }
                        super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                    }
                }
            })
        })
    }
}

