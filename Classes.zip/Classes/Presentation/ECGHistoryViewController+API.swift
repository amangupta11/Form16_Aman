//  ECGHistoryViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
// MARK: -  Server Interaction
extension  ECGHistoryViewController {
    
    func getAWSBucketInformation( ) {
        checkInternet()
        APIRequest.sharedAPI.getAWSBucketInfo(patientInfo: "", completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                 ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    CustomAWSCredentialProvider.sharedInstance.updateAWSInfo(jsonString!)
                    self.updateUIAfterLoading()
                    
                } else {
                   super.handleError(error) 
                }
            })
        })
    }

    func downloadImage(imageURL: NSURL, s3DownloadKeyName: String) {
        
        AWSTransferManager.sharedTransferManager.downloadImageRequest(imageURL, s3DownloadKeyName: s3DownloadKeyName, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    // Updating the ecg array
                    let ecgFileName = imageURL.lastPathComponent
//                    let caseID = Patient.sharedInfo.patientInfo?.caseID
//                    if caseID != nil {
                        let filePath = String(format: "%@/%@", FileUtility.getECGFolder((Patient.sharedInfo.patientInfo?.caseID)!), (ecgFileName!))
                    self.updateECGImage(s3DownloadKeyName, localPath: filePath)
//                    }
                } else {
                    self.handleDownloadError()

                }
            })
        })
}
}
