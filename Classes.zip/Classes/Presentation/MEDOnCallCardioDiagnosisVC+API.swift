//
//  MEDOnCallCardioDiagnosisVC+API.swift
//  Medtronic
//
//  Created by Praveen Ambekar on 4/10/17.
//  Copyright © 2017 Medtronic. All rights reserved.
//

import Foundation
// MARK: -  Server Interaction
extension  MEDOnCallCardioDiagnosisVC {
    
    func downloadImage(patientInfo: PatientInfo, imageURL: NSURL, s3DownloadKeyName: String) {
        AWSTransferManager.sharedTransferManager.downloadImageRequest(patientInfo, imageURL: imageURL, s3DownloadKeyName: s3DownloadKeyName, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                if successful {
                    self.updateECGImage()
                } else {
                    self.handleDownloadError()
                    
                }
            })
        })
    }
    func getAWSBucketInformation() {
        checkInternet()
        APIRequest.sharedAPI.getAWSBucketInfo(patientInfo: "", completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    CustomAWSCredentialProvider.sharedInstance.updateAWSInfo(jsonString!)
                    self.downloadECGImage()
                    
                } else {
                    
                }
            })
        })
    }
    
    func updateInfractAreaDetailsFromCardiologist() {
        checkInternet()
        APIRequest.sharedAPI.unclearPatientECG(patientInfo!, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.handleSuccessForBottomButtonAction()
                } else {
                    super.handleError(error)
                    
                }
            })
        })
    }
    
}
