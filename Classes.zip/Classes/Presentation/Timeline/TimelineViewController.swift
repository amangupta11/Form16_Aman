//  TimelineViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import Foundation
import Firebase
class TimelineViewController: MEDBaseViewController {
    @IBOutlet var timelineTableView: UITableView!
    @IBOutlet var timlineDateHeader: UIView!
    @IBOutlet var treatmentTimeLabel: UILabel!
    @IBOutlet var onsetTimeLabel: UILabel!
    @IBOutlet var caseIDLabel: UILabel!
    var timelineArray: NSMutableArray!
    var diagtimeDifferenceArray: NSMutableArray!
    var underObstimeDifferenceArray: NSMutableArray!
    var sectionArray:NSMutableArray!
    var timelineHeaderArray: NSMutableArray!
    var timelineDict:NSDictionary!
    var timelineTimeDict:NSMutableDictionary!
    var timelineSectionHeaderArray: NSMutableArray!
    var hospitalType: NSString!
    var onsetDate:NSString!
    var undiagnosedTime:Int = 0
    var unObservTime:Int = 0
    var selectedCellIndexPath: NSIndexPath?
    var currentHospitalType: NSString!
    var previousHospitalType: NSString!
    struct TimelineStringConstants {
        static  var CellIdentifier = "TimelineCell"
        static  var CellHeaderIdentifier = "headerCell"
        static  var DeviceCrossTime = "Device Cross Time"
         static  var TreatmentCancelled = "Treatment Cancelled"
    }
    struct TimelineImageStringConstants {
        static  var patientAtH     = "patientAtH"
        static  var hubTimeImage   = "hubTimeImage"
        static  var hubOvalImage   = "hubOvalImage"
        static  var patientAtS     = "patientAtS"
        static  var spokeTimeImage = "spokeTimeImage"
        static  var spokeOvalmage  = "spokeOvalmage"
        static  var expandImage    = "expand"
        static  var collapseImage  = "collapse"
    }
    enum TimelineDictKey:String {
        case TimelineDate = "TimelineDate"
        case TimelineName = "TimelineName"
        case TimelineTime = "TimelineTime"
        case Time         = "Time"
        case Comment         = "Comment"
        case TimeDifference = "TimeDifference"
        case HospitalType = "HospitalType"
    }
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUp()
        // Do any additional setup after loading the view.
    }
    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
        super.viewWillDisappear(animated)
    }
    override func viewWillAppear(animated: Bool) {
        FIRAnalytics.setScreenName(FireBaseConstants.timeLine, screenClass: FireBaseConstants.timeLine)
        if Patient.sharedInfo.patientInfo != nil {
            startTimer()
        }
    }
}
// MARK: -  Custom Actions
extension TimelineViewController {
    func initialSetUp() {
        timelineHeaderArray = NSMutableArray()
        timelineSectionHeaderArray = NSMutableArray()
        timelineTimeDict = NSMutableDictionary()
        setNavigationBackButtonImage()
        getTimelineDateDifference()
        addSortedDataToArray()
        getTimelineTimeDifference()
        setOnsetDateAndTreatmentTime()
        self.timelineTableView.estimatedRowHeight = 72
        self.timelineTableView.rowHeight = UITableViewAutomaticDimension
    }
    func setOnsetDateAndTreatmentTime(){
        if(onsetDate != nil && onsetDate != ""){
            self.onsetTimeLabel.text = String(onsetDate)}
        else{
            self.onsetTimeLabel.text = "-"
        }
        let FmcDate = Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInTime
         let onsetDateTime = Patient.sharedInfo.patientInfo?.timeLine?.onSetTime
        let timeInterval = NSDate(timeIntervalSince1970: FmcDate!).timeIntervalSinceDate(NSDate(timeIntervalSince1970: onsetDateTime!))
        let duration: NSTimeInterval = timeInterval
            let hoursInMins: Int = (Int(duration) / 60) / 60
            let mins = (Int(duration) / 60) % 60
            let daysInhours: Int = hoursInMins / 24
            let hours = hoursInMins % 24
            let days = daysInhours % 365
           if(days == 0 && hours == 0 && mins != 0){
            self.treatmentTimeLabel.text = String(format: "%02d min(s)", Int(mins))
            }
           else if(days == 0 && hours != 0 && mins == 0){
            self.treatmentTimeLabel.text = String(format: "%02d hour(s)", Int(hours))
           }
           else if(days != 0 && hours == 0 && mins == 0){
            self.treatmentTimeLabel.text = String(format: "%02d day(s)", Int(days))
           }
           else if(days == 0 && hours != 0 && mins != 0){
            self.treatmentTimeLabel.text = String(format: "%02d hour(s) %02d min(s)", Int(hours), Int(mins))
           }
           else if(days != 0 && hours != 0 && mins == 0){
            self.treatmentTimeLabel.text = String(format: "%02d day(s) %02d hour(s)", Int(days), Int(hours))
           }
           else if(days != 0 && hours == 0 && mins != 0){
            self.treatmentTimeLabel.text = String(format: "%02d day(s) %02d min(s)", Int(days), Int(mins))
           }
           else if(days != 0 && hours != 0 && mins != 0){
            self.treatmentTimeLabel.text = String(format: "%02d day(s) %02d hour(s) %02d min(s)", Int(days), Int(hours), Int(mins))
           }
           else{
            self.treatmentTimeLabel.text = String(format: "     _")
        }
    }
    override func backButtonAction(button: UIButton) {
        FIRAnalytics.logEventWithName(FireBaseEvents.timeLineToSummary, parameters:nil)
        self.navigationController?.popViewControllerAnimated(true)
    }
    func addSortedDataToArray(){
        for i in 0..<timelineSectionHeaderArray.count{
            let indexarray = NSMutableArray()
            let sectionHeaderName = timelineSectionHeaderArray.objectAtIndex(i) as! String
            for j in 0..<timelineArray.count{
                let dict = timelineArray[j] as! NSDictionary
                let timelineDate = dict[TimelineDictKey.TimelineDate.rawValue] as? String
                if(sectionHeaderName == timelineDate){
                    indexarray.addObject(j)
                }
            }
            self.timelineHeaderArray.addObject(indexarray)
        }
    }
    func getTimelineTimeDifference(){
        var previousTime:Double = 0
        diagtimeDifferenceArray = NSMutableArray()
        underObstimeDifferenceArray = NSMutableArray()
        for i in 0..<timelineArray.count{
            let timeDic = timelineArray[i] as! NSMutableDictionary
            let currentTime = timeDic[TimelineDictKey.Time.rawValue] as! Double
            if(previousTime != 0){
                let previousDate = NSDate(timeIntervalSince1970: previousTime )
                let currentDate = NSDate(timeIntervalSince1970: currentTime )
                let interval = currentDate.timeIntervalSinceDate(previousDate)
                let duration: NSTimeInterval = interval
                let timeDifference: Int = Int(duration) / 60
                timeDic[TimelineDictKey.TimeDifference.rawValue] = String(timeDifference)
            }
            previousTime = currentTime as Double
        }
        
    }
    func getTimelineDateDifference(){
        var previousDateString:NSString = ""
        for i in 0..<timelineArray.count{
            let timeDic = timelineArray[i] as! NSDictionary
            let currentDateString = timeDic[TimelineDictKey.TimelineDate.rawValue] as? String
            if(i == 0){
                timelineSectionHeaderArray.addObject(currentDateString!)
            }
            if(previousDateString != ""){
                if(previousDateString != currentDateString){
                    timelineSectionHeaderArray.addObject(currentDateString!)
                }
            }
            previousDateString = currentDateString! as String
        }
    }
    func addShadowToView(cell: TimelineTableViewCell){
        cell.tableViewCellBgView.layer.masksToBounds = false
        cell.tableViewCellBgView.layer.borderWidth = 1
        cell.tableViewCellBgView.layer.borderColor = ColorPicker.warmGrey15().CGColor
        cell.tableViewCellBgView.layer.shadowColor = UIColor.blackColor().CGColor
        cell.tableViewCellBgView.layer.shadowOffset = CGSizeMake(1, 1)
        cell.tableViewCellBgView.layer.shadowOpacity = 0.1
        cell.tableViewCellBgView.layer.shadowRadius = 1
    }
    func updateUIForHubHospital(cell: TimelineTableViewCell){
        cell.topLineLabel.backgroundColor = ColorPicker.tealish()
        cell.patientStatusImage.image = UIImage(named: TimelineImageStringConstants.patientAtH)
        cell.timeLabelImageView.image = UIImage(named: TimelineImageStringConstants.hubTimeImage)
        cell.ovalImage.image = UIImage(named: TimelineImageStringConstants.hubOvalImage)
        cell.bottomOvalImage.image = UIImage(named: TimelineImageStringConstants.hubOvalImage)
        cell.bottomLineLabel.backgroundColor = ColorPicker.tealish()
    }
    func updateTreatmentCellUI(cell: TimelineTableViewCell, expand: Bool){
        if(expand == true){
            cell.dropDownArrow.image = UIImage(named: TimelineImageStringConstants.collapseImage)
            cell.reasonLabel.hidden = false
        }
        else{
            cell.reasonLabel.hidden = true
            cell.reasonLabel.text! = ""
            cell.dropDownArrow.image = UIImage(named: TimelineImageStringConstants.expandImage)
        }
    }
    func updateUIForSpokeHospital(cell: TimelineTableViewCell){
        cell.patientStatusImage.image = UIImage(named: TimelineImageStringConstants.patientAtS)
        cell.timeLabelImageView.image = UIImage(named: TimelineImageStringConstants.spokeTimeImage)
        cell.ovalImage.image = UIImage(named: TimelineImageStringConstants.spokeOvalmage)
        cell.bottomOvalImage.image = UIImage(named: TimelineImageStringConstants.spokeOvalmage)
        cell.topLineLabel.backgroundColor = ColorPicker.peaGreenColor()
        cell.bottomLineLabel.backgroundColor = ColorPicker.peaGreenColor()
    }
    func updateTimlineUI(cell: TimelineTableViewCell, indexpath: NSIndexPath){
        if(indexpath.section != 0){
            if(indexpath.row == 0){
                let lastRowIndex = self.timelineTableView.numberOfRowsInSection(indexpath.section-1)
                sectionArray = timelineHeaderArray[indexpath.section-1] as! NSMutableArray
                let index = sectionArray[lastRowIndex-1] as! NSInteger
                let prevTimelineDict =  timelineArray[index] as! NSDictionary
                previousHospitalType =  prevTimelineDict[TimelineDictKey.HospitalType.rawValue] as? String
                currentHospitalType  =  hospitalType
            }
            else{
                let index = sectionArray[indexpath.row-1] as! NSInteger
                let prevTimelineDict =  timelineArray[index] as! NSDictionary
                previousHospitalType =  prevTimelineDict[TimelineDictKey.HospitalType.rawValue] as? String
                currentHospitalType  =  hospitalType
            }
        }
        else{
            let index = sectionArray[indexpath.row-1] as! NSInteger
            let prevTimelineDict =  timelineArray[index] as! NSDictionary
            previousHospitalType =  prevTimelineDict[TimelineDictKey.HospitalType.rawValue] as? String
            currentHospitalType  =  hospitalType
        }
        if(previousHospitalType == "1" && currentHospitalType == "2"){
            cell.topLineLabel.backgroundColor = ColorPicker.peaGreenColor()
        }
        else if(previousHospitalType == "2" && currentHospitalType == "1"){
            cell.topLineLabel.backgroundColor = ColorPicker.tealish()
        }
    }
    
    func configureCellData(cell: TimelineTableViewCell, indexpath: NSIndexPath) {
        sectionArray = timelineHeaderArray[indexpath.section] as! NSMutableArray
        let index = sectionArray[indexpath.row] as! NSInteger
        let timelineDict =  timelineArray[index] as! NSDictionary
        hospitalType = timelineDict[TimelineDictKey.HospitalType.rawValue] as? NSString
        self.caseIDLabel.text = "Case ID : " + (Patient.sharedInfo.patientInfo?.hospitalCaseID)!
        cell.timeName.text = timelineDict[TimelineDictKey.TimelineName.rawValue] as? String
        cell.timeLabel.text = timelineDict[TimelineDictKey.TimelineTime.rawValue] as? String
        cell.ovalImage.hidden = true
        cell.topLineLabelTopConstraint.constant = 0
        cell.bottomOvalImage.hidden = true
        cell.reasonLabel.hidden = true
        cell.dropDownArrow.hidden = true
        cell.reasonLabel.text = ""
        addShadowToView(cell)
        if(hospitalType == "2"){
            updateUIForHubHospital(cell)
        }
        else{
            updateUIForSpokeHospital(cell)
        }
        if(indexpath.section == 0 && indexpath.row == 0){
            cell.ovalImage.hidden = false
            cell.topLineLabelTopConstraint.constant = 12
            cell.timeNameStackViewHeight.constant = 28
            cell.timedifferenceLabel.hidden = true
            cell.timeNameLabelTopConstraint.constant = 19
        }
        else{
            cell.timeNameLabelTopConstraint.constant = 13
            cell.timeNameStackViewHeight.constant = 38
            cell.timedifferenceLabel.hidden = false
            let timeDifference = timelineDict[TimelineDictKey.TimeDifference.rawValue] as? String
            cell.timedifferenceLabel.text = String(format: "%02d", Int(timeDifference! as String)!) + " " + "min(s)"
            updateTimlineUI(cell, indexpath: indexpath)
        }
        if(indexpath.section == timelineTableView.numberOfSections-1){
            let lastRowIndex = timelineTableView.numberOfRowsInSection(indexpath.section)
            if (indexpath.row == lastRowIndex - 1) {
                cell.bottomOvalImage.hidden = false
            }
        }
        if(cell.timeName.text == TimelineStringConstants.TreatmentCancelled){
            cell.dropDownArrow.hidden = false
            cell.reasonLabel.text = ""
            cell.dropDownArrow.image = UIImage(named: TimelineImageStringConstants.expandImage)
        }
    }
    func calculateHeightForReasonLabel(string: String, width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: CGFloat.max)
        let option = NSStringDrawingOptions.UsesFontLeading.union(.UsesLineFragmentOrigin)
        let boundingBox = (string as NSString).boundingRectWithSize(constraintRect, options: option, attributes: [NSFontAttributeName: font], context: nil)
        return boundingBox.height
    }
    
    func getReasonLabelText(cell: TimelineTableViewCell, indexpath: NSIndexPath){
        sectionArray = timelineHeaderArray[indexpath.section] as! NSMutableArray
        let index = sectionArray[indexpath.row] as! NSInteger
        let timelineDict =  timelineArray[index] as! NSDictionary
        let cancelReason = (timelineDict[TimelineDictKey.Comment.rawValue] as? String)!.componentsSeparatedByString(",")
        cell.reasonLabel.text = String(cancelReason[1])
    }
}

// MARK: - tableView Delegate methods
extension TimelineViewController:UITableViewDelegate {
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = tableView.dequeueReusableCellWithIdentifier(TimelineStringConstants.CellHeaderIdentifier)  as! TimlineDateHeaderTableViewCell
        let dateHeader = timelineSectionHeaderArray.objectAtIndex(section)
        headerView.lineLabel.backgroundColor = ColorPicker.peaGreenColor()
        if(section == 0){
            headerView.lineLabel.hidden = true
        }
        if(previousHospitalType == "2"){
            headerView.lineLabel.backgroundColor = ColorPicker.tealish()
        }
        else{
            headerView.lineLabel.backgroundColor = ColorPicker.peaGreenColor()
        }
        headerView.dateHeaderLabel.text = dateHeader as? String
        return headerView.contentView
    }
    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        if(section == timelineTableView.numberOfSections-1){
            return 5
        }
        else{
            return 0
        }
    }
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return timelineSectionHeaderArray.count
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (timelineHeaderArray.objectAtIndex(section) as! NSMutableArray).count
    }

    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! TimelineTableViewCell
        if selectedCellIndexPath != nil && selectedCellIndexPath == indexPath {
            selectedCellIndexPath = nil
            updateTreatmentCellUI(cell, expand: false)
        } else if(cell.timeName.text == TimelineStringConstants.TreatmentCancelled) {
            getReasonLabelText(cell, indexpath: indexPath)
            selectedCellIndexPath = indexPath
        }
        tableView.beginUpdates()
        tableView.endUpdates()
        if selectedCellIndexPath != nil {
            // This ensures, that the cell is fully visible once expanded
            tableView.scrollToRowAtIndexPath(indexPath, atScrollPosition: .None, animated: true)
            if(cell.timeName.text == TimelineStringConstants.TreatmentCancelled){
                updateTreatmentCellUI(cell, expand: true)
            }
        }
    }
}
// MARK: - tableView DataSource methods
extension  TimelineViewController:UITableViewDataSource {
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(TimelineStringConstants.CellIdentifier, forIndexPath: indexPath) as! TimelineTableViewCell
        configureCellData(cell, indexpath: indexPath)
        return cell
    }
}

