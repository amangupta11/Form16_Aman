//  TimlineDateHeaderTableViewCell.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

class TimlineDateHeaderTableViewCell: UITableViewCell {

    @IBOutlet var lineLabel: UILabel!
    @IBOutlet var dateHeaderLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
