//  TimelineTableViewCell.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

class TimelineTableViewCell: UITableViewCell {

    @IBOutlet weak var timeNameStackViewHeight: NSLayoutConstraint!
    @IBOutlet weak var timeNameLabelTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var timelineCell: UIView!
    @IBOutlet weak var dropDownArrow: UIImageView!
    @IBOutlet var tableViewCellBgView: UIView!
    @IBOutlet var bottomOvalImage: UIImageView!
    @IBOutlet var topLineLabelTopConstraint: NSLayoutConstraint!
    @IBOutlet var bottomLineLabel: UILabel!
    @IBOutlet var timeName: UILabel!
    @IBOutlet var ovalImage: UIImageView!
    @IBOutlet var topLineLabel: UILabel!
    @IBOutlet var timeLabelImageView: UIImageView!
    @IBOutlet var timedifferenceLabel: UILabel!
    @IBOutlet var patientStatusImage: UIImageView!
    @IBOutlet var timeLabel: UILabel!
    @IBOutlet weak var reasonLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
