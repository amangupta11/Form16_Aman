//  MEDCameraLauncher.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

class MEDCameraLauncher: MEDBaseViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    var imagePicker: UIImagePickerController? = nil
    // MARK: - Custom Actions
    func presentCamera() {
        imagePicker = UIImagePickerController()
        imagePicker?.navigationBar.backgroundColor = ColorPicker.navigationDeepSeaBlueColor()
        self.takePhoto()
    }
    func takePhoto() {
        imagePicker!.delegate = self
        if UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera) {
            imagePicker!.sourceType = .Camera
        } else   if UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.PhotoLibrary) {
            // Camera not available
            imagePicker!.sourceType = .PhotoLibrary
        }
        imagePicker!.allowsEditing = false
        self.presentViewController(imagePicker!, animated: true, completion: nil)
         let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
          appDelegate?.isCameraOpen = true
    }
    // MARK: - Image Picker Delegates
    func imagePickerController(
        picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        imagePicker! .dismissViewControllerAnimated(true, completion: nil)
    }
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        imagePicker!.dismissViewControllerAnimated(true, completion: nil)
    }
}
