//  MEDDatePickerViewDelegate.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
protocol pickerViewProtocol {
    func datePickerDoneButtonTapped(selectedTime: String!, selectedDate: String!)
    func pickerViewDoneButtonTapped(selectedString: String!, index: Int)
}
enum PickerViewType: String {
    case DatePicker = "DatePicker"
    case CustomPicker = "CustomPicker"
}
class MEDPickerContainerDelegate: UIDatePicker, UIPickerViewDelegate, UIPickerViewDataSource {
    var datePicker: UIDatePicker!
    var pickerView: UIPickerView!
    var pickerContainerView: UIView!
    var cancelButton: UIButton!
    var doneButton: UIButton!
    var delegate: pickerViewProtocol!
    var dataSourceArray: NSArray = [""]
    var pickerViewIdentifiers: PickerViewType!
    var index: Int! = 0
    var pickerViewSelectedString: String = ""
    var containerView: UIView!

    override init(frame: CGRect) {
        self.containerView = UIView(frame: frame)
        super.init(frame: frame)
        sharedInit()
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        sharedInit()
    }
    //MARK: -Custome Actions
    func initializeDatePickerView() {
        self.pickerViewIdentifiers = PickerViewType.DatePicker
        self.pickerContainerView = UIView(frame: CGRect(x: 0, y: self.containerView.frame.height-200, width: self.containerView.frame.width, height: 200))
        self.pickerContainerView.backgroundColor = UIColor.whiteColor()
        self.datePicker = UIDatePicker()
        self.datePicker.frame = CGRect(x: 0, y: self.pickerContainerView.frame.height - 160, width: self.containerView.frame.width, height: 160)
        self.pickerContainerView.addSubview(self.datePicker)
        self.addCustomButtons()
        self.containerView.addSubview(self.pickerContainerView)
            }
     func initializePickerView() {
        self.pickerViewIdentifiers = PickerViewType.CustomPicker
          self.pickerContainerView = UIView(frame: CGRect(x: 0, y: self.containerView.frame.height-200, width: self.containerView.frame.width, height: 200))
        self.pickerContainerView.backgroundColor = UIColor.whiteColor()
        self.pickerView = UIPickerView()
        self.pickerView.delegate = self
        self.pickerView.frame = CGRect(x: 0, y: self.pickerContainerView.frame.height -  160, width: self.pickerContainerView.frame.width, height: 160)
        self.pickerContainerView.addSubview(self.pickerView)
        self.addCustomButtons()
        self.containerView.addSubview(self.pickerContainerView)
    }
    func doneButtonAction(sender: UIButton) {
        self.containerView.removeFromSuperview()
        switch self.pickerViewIdentifiers.rawValue {
        case PickerViewType.DatePicker.rawValue:
            let dateFormatter = NSDateFormatter()
            dateFormatter.dateFormat = "dd-MMM-yyyy"
            let selectedDate = dateFormatter.stringFromDate(self.datePicker.date)
            dateFormatter.dateFormat = "h:mma"
            let selectedTime = dateFormatter.stringFromDate(self.datePicker.date)
            delegate.datePickerDoneButtonTapped(selectedTime, selectedDate: selectedDate )
        case PickerViewType.CustomPicker.rawValue:
            delegate.pickerViewDoneButtonTapped(self.pickerViewSelectedString, index: self.index)
        default:
            return
        }
    }
    func addCustomButtons() {
        self.cancelButton = UIButton()
        self.doneButton = UIButton()
        self.cancelButton.frame = CGRect(x: 0, y: 0, width: self.containerView.frame.width/2, height: 40)
        self.doneButton.frame = CGRect(x: self.cancelButton.frame.width, y: 0, width: self.cancelButton.frame.width, height: 40)
        self.cancelButton.backgroundColor = ColorPicker.pickerViewCancelButtonBackgroundColor()
        self.doneButton.backgroundColor = ColorPicker.pickerViewDoneButtonBackgroundColor()
        self.doneButton.setTitle(ButtonTitles.pickerViewDoneButtonTitle, forState: .Normal)
        self.cancelButton.setTitle(ButtonTitles.pickerViewCancelButtonTitle, forState: .Normal)
        self.doneButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        self.cancelButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
            // Adding actions for button
        self.cancelButton.addTarget(self, action: #selector(cancelButtonAction), forControlEvents: .TouchUpInside)
        self.doneButton.addTarget(self, action: #selector(doneButtonAction), forControlEvents: .TouchUpInside)
        self.pickerContainerView.addSubview(cancelButton)
        self.pickerContainerView.addSubview(doneButton)
    }
    func cancelButtonAction(sender: UIButton!) {
        self.containerView.removeFromSuperview()
    }

    //MARK: - PickerView Delegate Implementation
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(pickerView: UIPickerView,
                    numberOfRowsInComponent component: Int) -> Int {
        return self.dataSourceArray.count
            }
    func pickerView(pickerView: UIPickerView,
                    titleForRow row: Int,
                                forComponent component: Int) -> String? {
      return self.dataSourceArray[row] as? String
      }
    func pickerView(pickerView: UIPickerView,
                    didSelectRow row: Int,
                                 inComponent component: Int) {
        self.pickerViewSelectedString = self.dataSourceArray[row] as! String
        self.index = row
    }

    func datePickerView() -> UIView {
        self.initializeDatePickerView()
        return self.containerView
    }
    func customPickerView(dataSourceArray: NSArray) -> UIView {
        self.dataSourceArray = dataSourceArray
        self.initializePickerView()
        return self.containerView
    }
    private func sharedInit() {
        datePickerMode = .Date
    }
}
//MARK: - Delegates
extension pickerViewProtocol {
    func pickerViewDoneButtonTapped(selectedString: String!, index: Int) {
        // abstract body
    }
    func datePickerDoneButtonTapped(selectedTime: String!, selectedDate: String!) {
    }
}
