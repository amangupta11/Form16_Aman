//  MEDViewSummaryViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import SwiftyJSON

// MARK: -  Server Interaction
extension MEDViewSummaryViewController {
    func checkPatientStatus(completion:(successful: Bool) -> Void) {
        checkInternet()
        let dict = [PatientInfoKey.CaseID.rawValue:Patient.sharedInfo.patientInfo?.caseID as! AnyObject]
        APIRequest.sharedAPI.checkPatientStatus(dictionary:dict, completion: {
            (jsonString, successful, error, response) in

            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    completion(successful: successful)
                } else {
                    super.handleError(error)

                }
            })
        })
    }
    func getFMCDoorOutForPatient() {
        checkInternet()
        var dict: NSDictionary? = nil
        dict = [PatientInfoKey.CaseID.rawValue:(Patient.sharedInfo.patientInfo?.caseID)!]
        APIRequest.sharedAPI.getFMCDetails(dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    // Navigating to nurse time line screen
                    self.navigateTospokeNurseTimelineScreen()
                    //Save Patient info
                } else {
                    super.handleError(error)

                }
            })
        })
    }
    func performGetHospitalDetails() {
       checkInternet()
        let hospitalID = Patient.sharedInfo.userInfo!.hospitalTypeID
        ActivityIndicatorView.sharedActivityView.showOverlay()
        let caseID = Patient.sharedInfo.patientInfo?.caseID

        let dict : [String : AnyObject] = ["nurseHospitalID":hospitalID!, "neededHospitalTypeID":"2", "caseID":caseID!]
        // TODO: In future if we have a screen to cchange the hospitla type we can use this parameter : neededHospitalTypeID
        APIRequest.sharedAPI.getHospitalListing(dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.hospitalListArray = (jsonString?.array)!
                    self.navigateToViewSummaryToTransferScreen()
                } else {
                    super.handleError(error)

                }
            })
        })
    }
    func performGetTreatmentCASEDetails() {
       checkInternet()
        let dict = [PatientInfoKey.CaseID.rawValue:Patient.sharedInfo.patientInfo?.caseID as! AnyObject]
        APIRequest.sharedAPI.getCASEDetails(dictionary:dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.navigateToParticularScreen(self.navigateToScreen)
                } else {
                    super.handleError(error)

                }
            })
        })
    }
    
    func getECGInfarctAreaDetails() {
        checkInternet()
        ActivityIndicatorView.sharedActivityView.showOverlay()
        APIRequest.sharedAPI.getECGInfo({
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    var caseKey: String!
                    // Decrypt the data
                    let ecgHistoryArray = jsonString?.array
                    for i in 0..<ecgHistoryArray!.count{
                        let caseKeyDict = ecgHistoryArray![i].dictionary
                             caseKey = caseKeyDict![PatientInfoKey.CaseKey.rawValue]?.string
                    }
                    DecryptionManager.decryptECGInfarctAreaDetails(jsonString!, caseKey:caseKey as String, completion: {
                        (decryptedArray, error) in
                    self.navigateToECGHistoryScreen(decryptedArray!)
                    })
            } else{
            self.showAlert( NSLocalizedString("NO_INTERNET_CONNECTION", comment: ""), alertMsg: NSLocalizedString("YOUR_REQUEST_COULD_NOT_BE_COMPLETED", comment: ""))
                }
            })
            
        })
        
    }
    func performGetCaseTimelineDetails() {
        checkInternet()
        ActivityIndicatorView.sharedActivityView.showOverlay()
        let dict = [PatientInfoKey.CaseID.rawValue:Patient.sharedInfo.patientInfo?.caseID as! AnyObject]
        APIRequest.sharedAPI.getCaseTimelineDetails(dictionary:dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                     let(timelineArray, onsetDate) = TimeLineManager.updateCaseTimeLine(jsonString!)
                    self.timelineArray = timelineArray
                    self.onsetDate = onsetDate
                    self.navigateViewSummaryToTimelineScreen()
                } else {
                    super.handleError(error)
                    
                }
            })
        })
    }
    


    func convertStringToDictionary(text: String) -> [String:AnyObject]? {
        if let data = text.dataUsingEncoding(NSUTF8StringEncoding) {
            do {
                return try NSJSONSerialization.JSONObjectWithData(data, options: []) as? [String:AnyObject]
            } catch let error as NSError {
                print(error)
            }
        }
        return nil
    }
    
    func getPatientMedicalConditions() {
        checkInternet()
        APIRequest.sharedAPI.getMedicalConditions(Patient.sharedInfo.patientInfo!, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                if successful {
                    let dict = jsonString
                    let patientMedCondDict = dict!["patientMedicalCondition"]
                    let patientMedicationArr:Array<AnyObject> = (dict![StringConstants.PatientMedications] as? Array<AnyObject>)!
                    let medicalConditionArr:Array<AnyObject> = (patientMedCondDict!["conditions"] as? Array<AnyObject>)!
                   
                    var medicalConditionArray = [AnyObject]()
                    for dict in medicalConditionArr{
                        let conditionDict:Dictionary<String, AnyObject> = (dict as? Dictionary<String, AnyObject>)!
                        let id = conditionDict["id"]
                        let value = conditionDict["value"]
                        
                        let tempDict = NSMutableDictionary()
                        tempDict.setValue(id, forKey: "id")
                        tempDict.setValue(value, forKey: "value")
                        tempDict.setValue(false, forKey: StringConstants.isChecked)
                        medicalConditionArray.append(tempDict)
                    }
                    var patientMedicationArray = [AnyObject]()
                    for medication in patientMedicationArr{
                        let medicationDict = medication
                        let medicine = medicationDict["medicineKey"]
                        let medicineDescription = medicationDict[StringConstants.MedicineDescription]
                        let medicineDose = medicationDict[StringConstants.MedicineDose]
                        
                        let tempDict = NSMutableDictionary()
                        tempDict.setValue(medicine, forKey: "medicineKey")
                        
                        tempDict.setValue(medicineDescription, forKey: StringConstants.MedicineDescription)
                        tempDict.setValue(medicineDose, forKey: StringConstants.MedicineDose)
                        tempDict.setValue(false, forKey: StringConstants.isChecked)
                        tempDict.setValue(0, forKey: StringConstants.SelectedDosage)
                        patientMedicationArray.append(tempDict)
                        
                    }
                    self.medicalHistoryDict.setValue(patientMedicationArray, forKey: StringConstants.PatientMedications)
                    self.medicalHistoryDict.setValue(medicalConditionArray, forKey: StringConstants.MedicalHistoryConditions)
                    self.getPatientMedicalHistory()
                } else {
                    if(response?.statusCode == 403){
                        self.authorizationAlert = true
                        self.showUnauthorizationAlert()
                    }else{
                        super.handleError(error)
                    }
                }
            })
        })
    }
    func getPatientClinicalExamination() {
        checkInternet()
        APIRequest.sharedAPI.getClinicalExamination(Patient.sharedInfo.patientInfo!, completion: { (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful{
                    DecryptionManager.decryptClinicalExaminations(jsonString!, caseKey: jsonString![PatientInfoKey.CaseKey.rawValue].string!, completion: {
                        (decryptedDict, error) in
                        self.medicalHistoryDict.setValue(decryptedDict, forKey: "clinicalExaminationDetailsDict")
                        self.navigateToPatientHistory()
                    })
                }
                 else {
                    super.handleError(error)
                    
                }
            })
        })
    }

    func getPatientMedicalHistory() {
        checkInternet()
        APIRequest.sharedAPI.getMedicalHistory(Patient.sharedInfo.patientInfo!) { (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    DecryptionManager.decryptMedicalConditons(jsonString!, caseKey: jsonString![PatientInfoKey.CaseKey.rawValue].string!, completion: {
                        (decryptedDict, error) in
                        let medicalNotes = decryptedDict?.valueForKey("medicalHistoryNotes") as? String
                        if medicalNotes != nil{
                            self.medicalHistoryDict.setValue(medicalNotes, forKey: "medicalHistoryNotes")
                        }
                        let medicalHistoryImages = (decryptedDict?.valueForKey(StringConstants.MedicalHistoryImages))! as AnyObject
                        self.medicalHistoryDict.setValue(medicalHistoryImages, forKey: StringConstants.images)
                        let medicalHistoryConditions = (decryptedDict?.valueForKey(StringConstants.MedicalHistoryConditions))! as AnyObject
                        self.medicalHistoryDict.setValue(medicalHistoryConditions, forKey: StringConstants.Conditions)
                        let medications = (decryptedDict?.valueForKey(StringConstants.PatientMedications))! as AnyObject
                        self.medicalHistoryDict.setValue(medications, forKey: StringConstants.Medications)
//                        let medicalConditionArray = self.medicalHistoryDict.valueForKey(StringConstants.MedicalHistoryConditions)
//                        
//                        if selectedMedicalHistoryConditions != nil {
//                        if let swiftArray = medicalConditionArray! as! NSArray as? [NSMutableDictionary] {
//                            for condition in selectedMedicalHistoryConditions!{
//                                let index = swiftArray.indexOf {
//                                    if let dic = $0 as? Dictionary<String,AnyObject> {
//                                        if let value = dic["id"]  as? String
//                                            where value == condition as! String{
//                                            return true
//                                        }
//                                    }
//                                    return false
//                                }
//                            let conditionDict = medicalConditionArray?.objectAtIndex(index!) as? NSMutableDictionary
//                                conditionDict?.setValue(true, forKey: "isChecked")
//                            }
//                            }
//                            
//                        }
//                        self.navigateToPatientHistory()
                        self.getPatientClinicalExamination()
                        })
                } else {
                    super.handleError(error)
                }
            })
        }
    }

}
