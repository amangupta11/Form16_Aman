//  CoachMarkContentViewController.swift
//  Copyright © 2017 Medtronic. All rights reserved.

import UIKit

class CoachMarkContentViewController: UIViewController {

    @IBOutlet weak var informationLabel: UILabel!
    var contentText : String?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.informationLabel.text = contentText
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(animated: Bool) {
        self.view.alpha = 1.0
        self.popoverPresentationController?.containerView?.alpha = 1.0
        UIView.animateWithDuration(2.0, delay: 0.0, options: UIViewAnimationOptions.CurveEaseOut, animations: {
            self.view.alpha = 0.0
            self.popoverPresentationController?.containerView?.alpha = 0.0
            }, completion: {(isCompleted) in
                self.dismissViewControllerAnimated(true, completion: nil)
        })
    }
}
