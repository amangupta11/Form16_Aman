//  MEDViewSummaryViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import SwiftyJSON
import Firebase
class MEDViewSummaryViewController: MEDBaseViewController, UIPopoverPresentationControllerDelegate {
    @IBOutlet var editButton: UIButton!
    @IBOutlet var chatIcon: UIBarButtonItem!
    @IBOutlet var patientPhoneNumber: UIButton!
    @IBOutlet var patientDoorInTime: UILabel!
    @IBOutlet var patientGender: UILabel!
    @IBOutlet var patientAge: UILabel!
    @IBOutlet var patientName: UILabel!
    @IBOutlet var triageDateTimeLabel: UILabel!
    @IBOutlet var onsetDateTimeLabel: UILabel!
    @IBOutlet var icORPassportLabel: UILabel!
    @IBOutlet var citizenshipTypeLabel: UILabel!
    @IBOutlet var paymentType: UILabel!
    @IBOutlet var patientCaseID: UILabel!
    @IBOutlet weak var treatmentButton: UIButton!
    @IBOutlet weak var transferButton: UIButton!
    @IBOutlet var treatmentLabel: UILabel!
    @IBOutlet var transferLabel: UILabel!
    @IBOutlet var patientHistoryLabel: UILabel!
    @IBOutlet var ecgLabel: UILabel!
    @IBOutlet var timelineLabel: UILabel!
    @IBOutlet var dischargeLabel: UILabel!
    @IBOutlet var shadowImageTopConstraint: NSLayoutConstraint!
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet weak var highLightTransferView: UIView!
    @IBOutlet weak var highLightTreatmentView: UIView!
    @IBOutlet weak var shadowImageOutlet: UIImageView!
    @IBOutlet weak var bottomViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var transferButtonBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var patientHistoryBottomConstarint: NSLayoutConstraint!
    @IBOutlet weak var ecgButtonBottomConstarint: NSLayoutConstraint!
    @IBOutlet weak var BottomButtonDeviderLabel: UILabel!
    @IBOutlet weak var dischargeButtonOutlet: MEDDashboardCustomButton!
    @IBOutlet weak var timelineButtonOutlet: MEDDashboardCustomButton!
    @IBOutlet weak var bottomButtonHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var viewSummaryGridView: UIView!
    var  medicalHistoryDict = NSMutableDictionary()
    var authorizationAlert:Bool = false
    var navigateToScreen:Int = 0
    var medicalNotes:String? = nil
    var stopTreatmentBarButton = UIBarButtonItem()
    var transferToastViewFrame : CGRect?
    var treatmentToastViewFrame : CGRect?
    var timelineEnabled: Bool = false
    //var hospitalListArray: NSArray!
    var hospitalListArray: [JSON] = []
    var timelineArray:NSMutableArray!
    var contentViewController : CoachMarkContentViewController?
    struct ViewSummaryConstants {
        static  var AlertTitle = NSLocalizedString("ATTENTION", comment: "")
        static  var AlertMessage = NSLocalizedString("THERE_HAS_BEEN_AN_UPDATE_ON_THIS_CASE", comment: "")
    }
    var onsetDate:NSString!
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.resumeTransferTabAnimation), name: UIApplicationWillEnterForegroundNotification, object: nil)
        initialSetup()
        // Do any additional setup after loading the view.
    }
    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
        if(contentViewController != nil){
        contentViewController?.dismissViewControllerAnimated(true, completion: nil)}
        super.viewWillDisappear(animated)
    }
    override func viewWillAppear(animated: Bool) {
        if Patient.sharedInfo.patientInfo != nil {
            updateUI()
            startTimer()
            self.highLightTreatmentView.hidden = true
            self.highLightTransferView.hidden = true
            self.hightLightTheTabs()
        }
        FIRAnalytics.setScreenName(FireBaseConstants.caseSummary, screenClass: FireBaseConstants.caseSummary)
    }
}
// MARK: - @IBAction Methods
extension MEDViewSummaryViewController {
    @IBAction func ecgButtonAction(sender: AnyObject) {
        self.getECGInfarctAreaDetails()
    }
    @IBAction func timelineButtonAction(sender: AnyObject) {
        performGetCaseTimelineDetails()
    }
    @IBAction func dischargeButtonAction(sender: AnyObject) {
        //showNotImplementedUserStoryAlert()
    }
    @IBAction func patientHistoryButtonAction(sender: AnyObject) {
        // Call the getMedical history api to get the data
        getPatientMedicalConditions()
    }
    @IBAction func treatmentButtonAction(sender: AnyObject) {
        onTreatmentButtonTap()
    }
    @IBAction func transferButtonAction(sender: AnyObject) {
        onTransferButtonTap()
    }
    @IBAction func editButtonAction(sender: AnyObject) {
        FIRAnalytics.logEventWithName(FireBaseEvents.summaryToEditInfo, parameters:nil)
        self.performNavigation()
    }
    @IBAction func callButtonAction(sender: AnyObject) {
        if(self.patientPhoneNumber.titleLabel?.text?.isEmpty == false) {
            SocialNetwork.makeCall((patientPhoneNumber.titleLabel?.text)!)
        }
    }
}
// MARK: - Custom Actions
extension MEDViewSummaryViewController {
    func initialSetup() {
        self.navigationItem.rightBarButtonItem = nil
         transferToastViewFrame = CGRectMake( view.frame.size.width - 75, self.view.frame.size.height - (self.viewSummaryGridView.frame.size.height + 125 ) , 10, 10)
         treatmentToastViewFrame = CGRectMake(self.viewSummaryGridView.frame.origin.x + 52, self.view.frame.size.height - (self.viewSummaryGridView.frame.size.height/2 + 125 ), 10, 10)
        self.buttonActionEnabling()
        setNavigationBackButtonImage()
        setshadowImageForScrollView()
        getNavigationRightBarButtonItem()
    }
    func onTreatmentButtonTap() {
        self.handleTreatment ()
    }
    func onTransferButtonTap() {
        FIRAnalytics.logEventWithName(FireBaseEvents.summaryToTransfer, parameters:nil)
        if(timelineEnabled == true){
            self.performGetCaseTimelineDetails()
        }
        else{
            self.checkPatientStatus{ (successful) in
                let caseStatus = Patient.sharedInfo.patientInfo?.caseStatus
                if(caseStatus == statusKey.InTransit.rawValue || caseStatus == statusKey.STEMI.rawValue){
                    self.handleTransfer()}
                else{
                    self.authorizationAlert = true
                    self.showUnauthorizationAlert()
                }}
        }
    }
    func handleTreatment () {
        navigateToScreen = 4
        performGetTreatmentCASEDetails()
    }

    func setshadowImageForScrollView() {
        let screenRect = UIScreen.mainScreen().bounds
        if (screenRect.size.height <= 568) {
            // this is an iPhone 5s or below
            self.shadowImageTopConstraint.constant = 260
        } else if screenRect.size.height == 667.0 {
            // Iphone 6s
            self.shadowImageTopConstraint.constant = 400
        } else {
            // Iphone 6s
            self.shadowImageTopConstraint.constant = 410
        }
    }
    func showUnauthorizationAlert() {
        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        alertView = alertController.showSimpleAlert(ViewSummaryConstants.AlertTitle, message:ViewSummaryConstants.AlertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)
    }

    func navigateToHome() {
        if self.navigationController?.viewControllers.first is MEDHomeViewController
        {
            let topViewController = self.navigationController?.viewControllers.first as! MEDHomeViewController
            topViewController.shouldTableViewRefresh = true
        }
        //  DataOperation.sharedDataOperation.deleteManagedObject(patientInfo!)
        self.navigationController?.popToRootViewControllerAnimated(true)
    }

    func hightLightTheTabs(){
        let hospitalTypeID = Patient.sharedInfo.userInfo!.hospitalTypeID
        let roleID = LoginManager.getUserRoleId()
        let caseStatus = Patient.sharedInfo.patientInfo?.caseStatus
        if roleID == UserRoles.GeneralPractitioner.rawValue
        {
            if caseStatus == statusKey.STEMI.rawValue{
                self.displayCoachMark(transferToastViewFrame!)
                self.animateTransferTab()
            }
        if (hospitalTypeID == "1"){
            if(caseStatus == statusKey.InTransit.rawValue && (Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutTime == nil || Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutTime == 0)){
                self.displayCoachMark(transferToastViewFrame!)
                self.animateTransferTab()
            }}
        else{
            if caseStatus == statusKey.InTransit.rawValue{
                self.displayCoachMark(transferToastViewFrame!)
                self.animateTransferTab()
            }}
        }
        else if roleID == UserRoles.CATHLABPractitioner.rawValue{
            if(caseStatus == statusKey.STEMI.rawValue || caseStatus == statusKey.InTransit.rawValue || caseStatus == statusKey.InternalTransfer.rawValue || caseStatus == statusKey.CathLabAccepted.rawValue ){
                self.displayCoachMark(treatmentToastViewFrame!)
                self.animateTreatmentTab()
            }
        }
    }
    func resumeTransferTabAnimation() {
        hightLightTheTabs()
    }
    func animateTransferTab () {
        self.highLightTransferView.hidden = false
        self.highLightTransferView.layer.cornerRadius = 0.5 * highLightTransferView.bounds.size.width
        UIView.animateWithDuration(1.0, delay:0, options: [.Repeat, .Autoreverse], animations: {
            self.highLightTransferView.transform = CGAffineTransformMakeScale(1.3, 1.3)
            }, completion: {completion in
                self.highLightTransferView.transform = CGAffineTransformMakeScale(1, 1)
        })
    }
    func animateTreatmentTab () {
        self.highLightTreatmentView.hidden = false
        self.highLightTreatmentView.layer.cornerRadius = 0.5 * highLightTransferView.bounds.size.width
        UIView.animateWithDuration(1.0, delay:0, options: [.Repeat, .Autoreverse], animations: {
            self.highLightTreatmentView.transform = CGAffineTransformMakeScale(1.3, 1.3)
            }, completion: {completion in
                self.highLightTreatmentView.transform = CGAffineTransformMakeScale(1, 1)
        })
    }
    private func displayCoachMark(sourceRect: CGRect, forcedArrowDirection: UIPopoverArrowDirection? = nil, dismissHandler: (() -> Void)? = nil) {
        let storyBoard: UIStoryboard = UIStoryboard(name: StroryBoardNameConstants.SBNameECGCapture, bundle:nil)
         contentViewController = storyBoard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.CoachMarkContentViewController) as? CoachMarkContentViewController
        contentViewController!.modalPresentationStyle = UIModalPresentationStyle.Popover
        contentViewController!.contentText = "Action Needed"
        let popover: UIPopoverPresentationController = contentViewController!.popoverPresentationController!
        popover.delegate = self
        popover.sourceView = self.view
        popover.sourceRect = sourceRect
        popover.permittedArrowDirections = .Down
        popover.backgroundColor = ColorPicker.toastMsgBackgroundColor()
        self.presentViewController(contentViewController!, animated: true, completion:nil)
    }
    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle {
        return .None
    }
    func showNotImplementedUserStoryAlert() {
        let alertCntrl = AlertController()
        alertCntrl.delegate = self
        let alertController = alertCntrl.showSimpleAlert("", message:NSLocalizedString("Not_Yet_Implemented", comment: ""), preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
    func handleTransfer() {
        let hospitalTypeID = Patient.sharedInfo.userInfo!.hospitalTypeID
        let caseStatus = Patient.sharedInfo.patientInfo?.caseStatus
        let roleID = LoginManager.getUserRoleId()
        if roleID == UserRoles.GeneralPractitioner.rawValue // Transfer is only for Nurse
        {
            if hospitalTypeID == "1" // Handle Spoke Nurse Transfer
            {
                if caseStatus == statusKey.STEMI.rawValue // If status is STEMI then show hospital listing screen
                {
                    performGetHospitalDetails()
                } else if caseStatus == statusKey.InTransit.rawValue // If status is In Transit show Spoke  time line screen
                {
                    getFMCDoorOutForPatient()
                }
            } else if hospitalTypeID == "2" // Handle Hub Nurse Transfer
            {
                if  caseStatus == statusKey.InTransit.rawValue   // If status is STEMI|| Intransit  then show Hub internal transfer screen
                {
                    navigateToScreen = 2
                    performGetTreatmentCASEDetails()
                } else if caseStatus == statusKey.STEMI.rawValue // If status is Internal Transfer then show Hub Time Line screen
                {
                    navigateToScreen = 3
                    performGetTreatmentCASEDetails()
                    // Sprint 4
                }
            }
        } else {
            //Ignore all actions for other roles
        }
    }
    func navigateToParticularScreen(navigateToScreen:Int){
        FIRAnalytics.logEventWithName(FireBaseEvents.summaryToTreatment, parameters:nil)
        switch navigateToScreen {
        case 2:
            navigateToHubNurseTimelineScreen()
        case 3:
            navigateTohubNurseInternalTransferScreen()
        case 4:
            navigateViewSummaryToTreatmentScreen()
        default: break
        }

    }
    func navigateViewSummaryToTimelineScreen() {
        FIRAnalytics.logEventWithName(FireBaseEvents.summaryToTimeLine, parameters:nil)
        let timeLineController: TimelineViewController = UIStoryboard(name: StroryBoardNameConstants.SBTimeline, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.TimelineViewControllerSBID) as! TimelineViewController
        timeLineController.timelineArray = timelineArray
        timeLineController.onsetDate = onsetDate
        self.navigationController?.pushViewController(timeLineController, animated: true)
    }
    func navigateToHubNurseTimelineScreen() {
        let hubNurseTimeLineController: MEDHubNurseTimeLineViewController = UIStoryboard(name: StroryBoardNameConstants.SBTimeline, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.hubNurseTimeLineScreenSBID) as! MEDHubNurseTimeLineViewController
        //hubNurseTimeLineController.patientInfo = patientInfo
        self.navigationController?.pushViewController(hubNurseTimeLineController, animated: true)
    }

    func navigateViewSummaryToTreatmentScreen() {
        self.performSegueWithIdentifier(SegueIdentifierConstants.ViewSummaryToTreatmentSegueIdentifier, sender: nil)
    }
    func navigateToViewSummaryToTransferScreen() {
        self.performSegueWithIdentifier(SegueIdentifierConstants.ViewSummaryToTransferSegueIdentifier, sender: nil)
    }
    func navigateTospokeNurseTimelineScreen() {
        let spokeNurseTimelineController: MEDSpokeNurseTimeLineViewController = UIStoryboard(name: StroryBoardNameConstants.SBTimeline, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.spokeNurseTimelineScreenSBID) as! MEDSpokeNurseTimeLineViewController
        self.navigationController?.pushViewController(spokeNurseTimelineController, animated: true)
    }
    func navigateTohubNurseInternalTransferScreen() {
        let hubNurseInternalTransfer: MEDHubNurseInternalTransferViewController = UIStoryboard(name: StroryBoardNameConstants.SBTimeline, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.internalTransferScreenSBID) as! MEDHubNurseInternalTransferViewController
        self.navigationController?.pushViewController(hubNurseInternalTransfer, animated: true)
    }


    func navigateToECGHistoryScreen(withInfarctAreaArray: NSMutableArray) {
        FIRAnalytics.logEventWithName(FireBaseEvents.summaryToEcg, parameters:nil)
        let ecgHistoryController: ECGHistoryViewController = UIStoryboard(name: StroryBoardNameConstants.SBECGHistory, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.ECGHistoryControllerSBID) as! ECGHistoryViewController
        ecgHistoryController.infarctAreaHistoryArray = withInfarctAreaArray
        self.navigationController?.pushViewController(ecgHistoryController, animated: true)
    }

    override func backButtonAction(button: UIButton) {
        FIRAnalytics.logEventWithName(FireBaseEvents.homeFromSummary, parameters:nil)
        let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        if appDelegate?.currentCaseStatus == Patient.sharedInfo.patientInfo?.caseStatus{
            self.navigationController?.popToRootViewControllerAnimated(true)
        }
        else{
            self.navigateToHome()
        }
        appDelegate?.currentCaseStatus = 0
    }

    func getpatientName() -> String{
        var patientName = ""
        var firstName = Patient.sharedInfo.patientInfo?.firstName
        var middleName = Patient.sharedInfo.patientInfo?.middleName
        var lastName = Patient.sharedInfo.patientInfo?.lastName

        if middleName != nil && middleName != ""{
            middleName = String(middleName!.characters.prefix(1))
        }
        if firstName != nil{
            firstName = firstName!
        }
        if lastName != nil{
            lastName = lastName!
        }
        patientName = firstName! + " " + middleName! + " " + lastName!
        return patientName
    }

    func updateUI() {
        let countryCode = Patient.sharedInfo.patientInfo?.countryCode
        let mobileNumber = Patient.sharedInfo.patientInfo?.mobileNumber

        let paymentType = Patient.sharedInfo.patientInfo?.paymentType
        self.patientCaseID.text = "Case ID : " + (Patient.sharedInfo.patientInfo?.hospitalCaseID)!
        self.paymentType.text = paymentType?.uppercaseString
        self.citizenshipTypeLabel.text = Patient.sharedInfo.patientInfo?.citizenship?.uppercaseString
        let patientName = self.getpatientName()
        self.patientName.text = patientName.uppercaseString

        self.patientAge.text = Patient.sharedInfo.patientInfo?.age
        self.icORPassportLabel.text = Patient.sharedInfo.patientInfo?.icNoOrPassport?.uppercaseString

        self.patientGender.text = "FEMALE"
        if(Patient.sharedInfo.patientInfo?.gender == "1") {
            self.patientGender.text = "MALE"}
        let fmcDoorInTime = Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInTime
        let doorInTimeString = DateUtility.convertGMTtoLongDate(fmcDoorInTime!)
        self.patientDoorInTime.text = doorInTimeString.uppercaseString

        if(Patient.sharedInfo.patientInfo?.timeLine?.onSetTime != nil && Patient.sharedInfo.patientInfo?.timeLine?.onSetTime != 0) {
            let onsetDateTime = Patient.sharedInfo.patientInfo?.timeLine?.onSetTime
            let onsetDateTimeString = DateUtility.convertGMTtoLongDate(onsetDateTime!)
            self.onsetDateTimeLabel.text = onsetDateTimeString.uppercaseString
        }
        if(Patient.sharedInfo.patientInfo?.timeLine?.triageTime != nil && Patient.sharedInfo.patientInfo?.timeLine?.triageTime != 0) {
            let traigeTime = Patient.sharedInfo.patientInfo?.timeLine?.triageTime
            let triageTimeString = DateUtility.convertGMTtoLongDate(traigeTime!)
            self.triageDateTimeLabel.text = triageTimeString.uppercaseString}
        if(mobileNumber != nil) {
            if(countryCode != nil && mobileNumber!.isEmpty == false) {
                self.patientPhoneNumber.setTitle(countryCode! + " " + mobileNumber!, forState: .Normal)
            }
            else{
                self.patientPhoneNumber.setTitle(("") + " " + "", forState: .Normal)
            }
        }
    }
    func stopTreatmentButtonAction(){
        FIRAnalytics.logEventWithName(FireBaseEvents.summaryToStopTreatment, parameters:nil)
        let storyBoard: UIStoryboard = UIStoryboard(name: StroryBoardNameConstants.SBNameECGCapture, bundle:nil)
        let vc = storyBoard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.StopTreatmentScreenSBID) as? MEDStopTreatmentController
        self.navigationController?.pushViewController(vc!, animated: true)

    }
    func getNavigationRightBarButtonItem() {
        stopTreatmentBarButton = UIBarButtonItem(title: "Stop Treatment", style: .Plain, target: self, action: #selector(stopTreatmentButtonAction))
        let color : UIColor = UIColor.whiteColor()
        let titleFont : UIFont = UIFont(name: "effra-regular", size: 14.0)!
        let attributes = [
            NSForegroundColorAttributeName : color,
            NSFontAttributeName : titleFont
        ]
        stopTreatmentBarButton.setTitleTextAttributes(attributes, forState: UIControlState.Normal)
        switch LoginManager.getUserRoleId(){
        case "1"://Spoke or Hub
            if Patient.sharedInfo.patientInfo?.caseStatus == statusKey.STEMI.rawValue || Patient.sharedInfo.patientInfo?.caseStatus == statusKey.InTransit.rawValue || Patient.sharedInfo.patientInfo?.caseStatus == statusKey.Undiagnosed.rawValue{
                self.navigationItem.rightBarButtonItem = stopTreatmentBarButton

            }else{
                self.navigationItem.rightBarButtonItem = nil
            }
            enableEditButton()
        case "2"://CathLab
            if Patient.sharedInfo.patientInfo?.caseStatus == statusKey.InternalTransfer.rawValue || Patient.sharedInfo.patientInfo?.caseStatus == statusKey.InTransit.rawValue || Patient.sharedInfo.patientInfo?.caseStatus == statusKey.CathLabAccepted.rawValue{
                self.navigationItem.rightBarButtonItem = stopTreatmentBarButton

            }else{
                self.navigationItem.rightBarButtonItem = nil
            }
        case "3"://Cardio
            self.navigationItem.rightBarButtonItem = nil// chatIcon
        case "7"://Cardio
            self.navigationItem.rightBarButtonItem = nil// chatIcon
        default: break
        }
    }

    func buttonActionEnabling() {
        let userId = LoginManager.getUserRoleId()
        transferButton.enabled = false
        transferLabel.alpha = 0.4
        editButton.hidden = true
        switch userId {
        case "1":
            self.navigationItem.rightBarButtonItem = nil// chatIcon
            enableEditButton()
        case "2":
            self.navigationItem.rightBarButtonItem = nil
            handleTreatmentButton()
        case "3":
            self.navigationItem.rightBarButtonItem = nil// chatIcon
        case "7":
            self.navigationItem.rightBarButtonItem = nil// chatIcon
            handleBottomButtonForOnCallCardio()
        default: break
        }
    }
    func handleBottomButtonForOnCallCardio(){
        treatmentButton.hidden = true
        dischargeButtonOutlet.hidden = true
        timelineButtonOutlet.hidden = true
        bottomButtonHeightConstraint.constant = 80
        ecgButtonBottomConstarint.constant = 0
        patientHistoryBottomConstarint.constant = 0
        transferButtonBottomConstraint.constant = 0
        BottomButtonDeviderLabel.hidden = true
        timelineLabel.hidden = true
        dischargeLabel.hidden = true
        treatmentLabel.hidden = true
        transferButton.enabled = true
        transferLabel.alpha = 1.0
        transferLabel.text = "Timeline"
        transferButton.setImage(UIImage(named:"timeline"), forState: UIControlState.Normal)
        timelineEnabled = true
        bottomViewHeightConstraint.constant = -50
        shadowImageOutlet.hidden = true
    }
    func handleTreatmentButton(){
        let caseStatus = Patient.sharedInfo.patientInfo?.caseStatus!
        if(caseStatus == statusKey.Cancelled.rawValue){
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4
        }
    }

    func enableEditButton() {

        let caseStatus = Patient.sharedInfo.patientInfo?.caseStatus
        switch (caseStatus) {
        case statusKey.UnderObservation.rawValue?:
            editButton.hidden = false
            transferButton.enabled = false
            transferLabel.alpha = 0.4
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4

        case statusKey.Undiagnosed.rawValue?:
            editButton.hidden = false
            transferButton.enabled = false
            transferLabel.alpha = 0.4
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4
        case statusKey.NotAStemi.rawValue?:
            editButton.hidden = false
            transferButton.enabled = false
            transferLabel.alpha = 0.4
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4

        case statusKey.STEMI.rawValue?:
            editButton.hidden = false
            transferButton.enabled = true
            transferLabel.alpha = 1.0
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4
        case statusKey.InTransit.rawValue?:
            editButton.hidden = false
            transferButton.enabled = true
            transferLabel.alpha = 1.0
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4
        case statusKey.InternalTransfer.rawValue?:
            editButton.hidden = false
            transferButton.enabled = false
            transferLabel.alpha = 0.4
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4
        case statusKey.CathLabAccepted.rawValue?:
            editButton.hidden = false
        case statusKey.DeviceCrossTime.rawValue?:
            editButton.hidden = false
        case statusKey.CathLabExit.rawValue?:
            editButton.hidden = false
        case statusKey.Completed.rawValue?:
            editButton.hidden = true
            transferButton.enabled = false
            transferLabel.alpha = 0.4
            treatmentButton.enabled = true
            treatmentLabel.alpha = 1.0
        case statusKey.Cancelled.rawValue?:
            editButton.hidden = true
            transferButton.enabled = false
            transferLabel.alpha = 0.4
            treatmentButton.enabled = false
            treatmentLabel.alpha = 0.4
        default:
            editButton.hidden = true
        }
    }
    func performNavigation() {
        if let viewControllers = self.navigationController?.viewControllers {
            var count = 0
            for viewController in viewControllers {
                count += 1
                if viewController.isKindOfClass(MEDEditCaseViewController) {
                    viewController.hidesBottomBarWhenPushed = true
                    self.hidesBottomBarWhenPushed = true
                    self.navigationController?.popViewControllerAnimated(true)
                    return
                }
            }
            self.pushViewSummaryToEditCaseController(count, viewControllers: viewControllers)
        }
    }
    func pushViewSummaryToEditCaseController(count: Int, viewControllers: [UIViewController]) {
        if(count == viewControllers.count) {
            self.performSegueWithIdentifier(SegueIdentifierConstants.ViewSummaryToEditCaseSegueIdentifier, sender: nil)
        }
    }
    // MARK: - Segue Methods
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == SegueIdentifierConstants.ViewSummaryToEditCaseSegueIdentifier) {
            let vc = segue.destinationViewController as! MEDEditCaseViewController
            //vc.patientInfo = patientInfo
        } else if(segue.identifier == SegueIdentifierConstants.ViewSummaryToTransferSegueIdentifier) {
            let vc = segue.destinationViewController as! MEDHospitalListViewController
            //vc.patientInfo = patientInfo
            vc.hospitalListArray = hospitalListArray
        } else if(segue.identifier == SegueIdentifierConstants.ViewSummaryToTreatmentSegueIdentifier) {
            let vc = segue.destinationViewController as! MEDTreatmentViewController
            //vc.patientInfo = patientInfo
        }else if(segue.identifier == SegueIdentifierConstants.ViewSummaryToPatientHistorySegueIdentifier) {
            let vc = segue.destinationViewController as! BasePatientHistoryViewController
            vc.medicalHistoryDict = self.medicalHistoryDict
            //vc.patientInfo = patientInfo
        }
        else {

        }
    }
    func navigateToPatientHistory(){
        FIRAnalytics.logEventWithName(FireBaseEvents.summaryToPatientHistory, parameters:nil)
        self.performSegueWithIdentifier("ViewSummaryToPatientHistory", sender: self)
    }
}
//MARK: - Alert view delegates
extension MEDViewSummaryViewController: AlertViewControllerProtocol {
    func cancelButtonAction(alertController: UIAlertController) {
    }
    func OKButtonAction(alertController: UIAlertController) {
    }
    func defaultButtonAction(alertController: UIAlertController) {
        if (authorizationAlert == true){
            navigateToHome()
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }
        else{
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }
    }
}
