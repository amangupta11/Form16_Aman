//  MEDPatientGeneralInfoViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
extension MEDPatientGeneralInfoViewController {


    func postPatientGeneralInfoDetails() {
        checkInternet()
        let dict:NSDictionary
        if(Patient.sharedInfo.patientInfo?.caseID != nil){
            dict = [PatientInfoKey.CaseID.rawValue:Patient.sharedInfo.patientInfo?.caseID as! AnyObject]
        }
        else{
            Patient.sharedInfo.patientInfo?.tempCaseID = StringUtility.uniqueId()
            dict = [PatientInfoKey.TempCaseID.rawValue:Patient.sharedInfo.patientInfo?.tempCaseID as! AnyObject]
        }
        APIRequest.sharedAPI.updatePatientGeneralDetails(dictionary:dict, completion: {
            (jsonString, successful, error, response) in
                if successful {
                    //PatientManager.managePatientData(jsonString!)
                    PatientManager.updateCaseDetailsOnStep1(jsonString)
                    dispatch_async(dispatch_get_main_queue(), {
                    self.handleResponse()
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    })
                } else {
                    super.handleError(error)
                }

        })
    }
//
}
