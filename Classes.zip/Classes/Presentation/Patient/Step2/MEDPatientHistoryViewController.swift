//  MEDPatientHistoryViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import Firebase
enum textFieldTag: Int {
    case TempTxtFld = 103
    case SPO2TxtFld = 104
}
class MEDPatientHistoryViewController: MEDBaseViewController {
    @IBOutlet var systolicTextField: UITextField!
    @IBOutlet var nextButton: UIButton!
    @IBOutlet var diastolicTextField: UITextField!
    @IBOutlet var pulseTextField: UITextField!
    @IBOutlet var tempTextField: UITextField!
    @IBOutlet var spo2TextField: UITextField!
    @IBOutlet var scoreButton1: UIButton!
    @IBOutlet var scoreButton2: UIButton!
    @IBOutlet var scoreButton3: UIButton!
    @IBOutlet var scoreButton4: UIButton!
    @IBOutlet var pulseLineLabel: UILabel!
    @IBOutlet var spo2LineLabel: UILabel!
    @IBOutlet var tempLineLabel: UILabel!
    @IBOutlet var diastolicLineLabel: UILabel!
    @IBOutlet var systolicLineLabel: UILabel!
    var currentTextField: UITextField!
    var newString: String!
    var selectedKillipScore: Int = 1
    var scrollOffset: CGPoint!
    @IBOutlet weak var vitalSignView: UIView!
    @IBOutlet weak var presentationView: UIView!

    @IBOutlet weak var patientHistoryScrollView: UIScrollView!
    @IBOutlet weak var scrollView: UIScrollView!
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        self.newString = ""
        super.viewDidLoad()
        scoreButton1.selected = true
        initialSetUp()
    }
    override func viewWillAppear(animated: Bool) {
         //initialSetUp()
        if Patient.sharedInfo.patientInfo != nil {
            updateUI()
        }
        self.addKeyboardObserver(self)
    }
    override func viewWillDisappear(animated: Bool) {
        self.removeKeyBoardObserver(self)
    }
}
// MARK: -  @IBActions
extension MEDPatientHistoryViewController {

    @IBAction func previousButtonAction(sender: AnyObject) {
        navigateToStep1View()
    }

    @IBAction func nextButtonAction(sender: AnyObject) {
        if Patient.sharedInfo.patientInfo?.caseStatus == statusKey.Diagnosed.rawValue {
            navigateToStep3View()
        } else {
        self.normalizeTheLabelsColor()
        self.view.endEditing(true)
        let isValid = self.validateFields()
        if isValid == true {
            //Server Call
            saveData()
            postPatientHistoryInfoDetails()
            }
        }
    }
    @IBAction func killipScoreButtonAction(sender: AnyObject) {
        enableKillipScoreButton(sender.tag)
    }
}
// MARK: - Custom Actions
extension MEDPatientHistoryViewController {
    func handleResponse() {
        navigateToStep3View()
    }
    func saveData() {
        Patient.sharedInfo.patientInfo?.patientHistory?.systolic = systolicTextField.text
        Patient.sharedInfo.patientInfo?.patientHistory?.diastolic = diastolicTextField.text
        Patient.sharedInfo.patientInfo?.patientHistory?.pulse = pulseTextField.text
        Patient.sharedInfo.patientInfo?.patientHistory?.temperature = tempTextField.text
        Patient.sharedInfo.patientInfo?.patientHistory?.spo2 = spo2TextField.text
        Patient.sharedInfo.patientInfo?.patientHistory?.killipScore = selectedKillipScore
    }
    func initialSetUp() {
        setNavigationBackButtonImage()
        setTapGestureForView()
        if(Patient.sharedInfo.patientInfo?.caseStatus == statusKey.Diagnosed.rawValue) {
            handleUserInteractionForFields(false)
            self.nextButton.setTitle("Next", forState: UIControlState.Normal)
            self.nextButton.titleEdgeInsets = UIEdgeInsets(top: 0, left: 56, bottom: 0, right: 0)
        } else {
            handleUserInteractionForFields(true)
        }
        self.patientHistoryScrollView.scrollEnabled = false
    }

    func handleUserInteractionForFields(enabled: Bool) {
        systolicTextField.userInteractionEnabled = enabled
        diastolicTextField.userInteractionEnabled = enabled
        pulseTextField.userInteractionEnabled = enabled
        tempTextField.userInteractionEnabled = enabled
        spo2TextField.userInteractionEnabled = enabled
        scoreButton1.userInteractionEnabled = enabled
        scoreButton2.userInteractionEnabled = enabled
        scoreButton3.userInteractionEnabled = enabled
        scoreButton4.userInteractionEnabled = enabled
    }
    func setTapGestureForView() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:) ))
        self.view.addGestureRecognizer(tapGesture)
    }
    func handleTap(sender: UIView) {
        view.endEditing(true)
    }
    override func backButtonAction(button: UIButton) {
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    func navigateToStep3View() {
        FIRAnalytics.logEventWithName(FireBaseEvents.saveStep2, parameters:nil)
        // Navigate to next screen
        let baseController =  self.parentViewController as! MEDPatientBaseContainerView
        baseController.handleSaveAndContinueBtnActions(baseController.step3ButtonOutlet)
    }
    func navigateToStep1View() {
        FIRAnalytics.logEventWithName(FireBaseEvents.step2Previous, parameters:nil)
        // Navigate to next screen
        let baseController =  self.parentViewController as! MEDPatientBaseContainerView
        baseController.handleSaveAndContinueBtnActions(baseController.step1ButtonOutlet)
    }
    func enableKillipScoreButton(tag: Int) {
        switch tag {
        case 1:
            handleScoreButton1Action()
        case 2:
            handleScoreButton2Action()
        case 3:
            handleScoreButton3Action()
        case 4:
            handleScoreButton4Action()
        default:
            break
        }
    }
    func updateUI() {
        if(Patient.sharedInfo.patientInfo?.patientHistory?.systolic != nil) {
            systolicTextField.text = Patient.sharedInfo.patientInfo?.patientHistory?.systolic
            diastolicTextField.text = Patient.sharedInfo.patientInfo?.patientHistory?.diastolic
            pulseTextField.text = Patient.sharedInfo.patientInfo?.patientHistory?.pulse
            tempTextField.text = Patient.sharedInfo.patientInfo?.patientHistory?.temperature
            spo2TextField.text = Patient.sharedInfo.patientInfo?.patientHistory?.spo2

            if (Patient.sharedInfo.patientInfo?.patientHistory?.killipScore != nil) {
                selectedKillipScore = Patient.sharedInfo.patientInfo?.patientHistory?.killipScore as! Int
                enableKillipScoreButton(selectedKillipScore)
            }
        }
    }
    func validateFields() -> Bool {
        // Validate fields
        var isValid = true
        // Checking invalid details
        if self.systolicTextField.text?.characters.count == 0 {
            systolicLineLabel.backgroundColor = ColorPicker.textFieldHighlightedColor()
            isValid = false
        }
        if self.diastolicTextField.text?.characters.count == 0 {
            diastolicLineLabel.backgroundColor = ColorPicker.textFieldHighlightedColor()
            isValid = false
        }
        if self.pulseTextField.text?.characters.count == 0 {
            pulseLineLabel.backgroundColor = ColorPicker.textFieldHighlightedColor()
            isValid = false
        }
        if self.tempTextField.text?.characters.count == 0 {
            tempLineLabel.backgroundColor = ColorPicker.textFieldHighlightedColor()
            isValid = false
        }
        if self.spo2TextField.text?.characters.count == 0 {
            spo2LineLabel.backgroundColor = ColorPicker.textFieldHighlightedColor()
            isValid = false
        }
        if MEDPatientValidations.isValidTextWithDecimal(self.tempTextField.text!) == false {
            tempLineLabel.backgroundColor = ColorPicker.textFieldHighlightedColor()
            isValid = false
        }
        if(Double(self.tempTextField.text!) > 50.0) {
            tempLineLabel.backgroundColor = ColorPicker.textFieldHighlightedColor()
            isValid = false
        }
        if(Double(self.tempTextField.text!) < 30.0) {
            tempLineLabel.backgroundColor = ColorPicker.textFieldHighlightedColor()
            isValid = false
        }
        if(Double(self.spo2TextField.text!) > 100.0) {
            spo2LineLabel.backgroundColor = ColorPicker.textFieldHighlightedColor()
            isValid = false
        }
        return isValid
    }
    func normalizeTheLabelsColor() {
        systolicLineLabel.backgroundColor = ColorPicker.warmGreyColor()
        diastolicLineLabel.backgroundColor = ColorPicker.warmGreyColor()
        pulseLineLabel.backgroundColor = ColorPicker.warmGreyColor()
        tempLineLabel.backgroundColor = ColorPicker.warmGreyColor()
        spo2LineLabel.backgroundColor = ColorPicker.warmGreyColor()
    }
    func handleScoreButton1Action() {
        if(scoreButton1.selected == false) {
            scoreButton1.selected = true
            scoreButton2.selected = false
            scoreButton3.selected = false
            scoreButton4.selected = false
            self.selectedKillipScore = scoreButton1.tag
        }
    }
    func handleScoreButton2Action() {
        if(scoreButton2.selected == false) {
            scoreButton1.selected = false
            scoreButton2.selected = true
            scoreButton3.selected = false
            scoreButton4.selected = false
            self.selectedKillipScore = scoreButton2.tag
        }
    }
    func handleScoreButton3Action() {
        if(scoreButton3.selected == false) {
            scoreButton1.selected = false
            scoreButton2.selected = false
            scoreButton3.selected = true
            scoreButton4.selected = false
            self.selectedKillipScore = scoreButton3.tag
        }
    }
    func handleScoreButton4Action() {
        if(scoreButton4.selected == false) {
            scoreButton1.selected = false
            scoreButton2.selected = false
            scoreButton3.selected = false
            scoreButton4.selected = true
            self.selectedKillipScore = scoreButton4.tag
        }
    }
}

//MARK: - KEYBOARD NOTIFICATIONS
extension MEDPatientHistoryViewController{
    override func keyboardWillShow(notification: NSNotification) {
        
        self.scrollOffset = self.patientHistoryScrollView.contentOffset
        let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, 25.0, 0.0)
        
        self.patientHistoryScrollView.contentInset = contentInsets
        self.patientHistoryScrollView.scrollRectToVisible(currentTextField.frame, animated: true)
    }
    override func keyboardWillHide(notification: NSNotification) {
        self.patientHistoryScrollView.contentInset = UIEdgeInsetsZero
        self.patientHistoryScrollView.contentOffset = CGPoint(x: 0, y: 0)
        
    }
}

// MARK: - UITextFieldDelegate
extension MEDPatientHistoryViewController: UITextFieldDelegate {
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        let updatedString = (textField.text as NSString?)?.stringByReplacingCharactersInRange(range, withString: string)
        if (textField.text == "" && updatedString == "0" ) {
            return false
        }
        if textField == self.systolicTextField || textField == self.diastolicTextField || textField == self.pulseTextField {
            if(MEDPatientValidations.isValidText(updatedString!) == false) {
                return false
            }
        } else if(textField.tag == textFieldTag.TempTxtFld.rawValue && updatedString?.characters.count > 4) {
            return false
        } else if(textField.tag == textFieldTag.SPO2TxtFld.rawValue && MEDPatientValidations.isValidTextWithMaxTwoNum(updatedString!) == false) {
            return false
        }
        return true

    }
    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        textField.inputAccessoryView = self.inputToolbar
        updateKeyboardToolbar(textField)
        currentTextField = textField
        return true
    }
    func textFieldDidBeginEditing(textField: UITextField) {
        self.currentTextFieldTag = textField.tag
    }

}
