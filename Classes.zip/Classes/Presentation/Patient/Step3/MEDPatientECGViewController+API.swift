//  MEDPatientHistoryViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
extension MEDPatientECGViewController {

    func getAWSBucketInformation(upload: Bool) {
        checkInternet()
        APIRequest.sharedAPI.getAWSBucketInfo(patientInfo: "", completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                if successful {
                    CustomAWSCredentialProvider.sharedInstance.updateAWSInfo(jsonString!)
                    if(upload == true){
                        self.startUploadingOfImage()}
                    else{
                        self.downloadECGImage()
                    }
                } else {

                }
            })
        })
    }
    func downloadImage(imageURL: NSURL, s3DownloadKeyName: String) {
        AWSTransferManager.sharedTransferManager.downloadImageRequest(imageURL, s3DownloadKeyName: s3DownloadKeyName, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.updateECGImage()
                } else {
                    self.handleDownloadError()

                }
            })
        })
    }
    func uploadImage(imageURL: NSURL, s3UploadKeyName: String) {
        checkInternet()
        AWSTransferManager.sharedTransferManager.uploadImageRequest(imageURL, s3UploadKeyName: s3UploadKeyName, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                if successful {
                    //Store this url in db ecg info
                    self.handleUplaodResponse()
                } else {
                    super.handleError(error)

                }
            })
        })
    }
    func postPatientECGInfoDetails() {
        checkInternet()
        APIRequest.sharedAPI.updatePatientECGInfo({
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.handleBottonButtonActionResponse()
                     self.previousState = Patient.sharedInfo.patientInfo?.caseStatus

                } else {
                    Patient.sharedInfo.patientInfo?.caseStatus = self.previousState
                    if(response?.statusCode == 403){
                        self.authorizationAlert = true
                        self.showUnauthorizationAlert()
                    }else{
                        super.handleError(error)
                    }


                }
            })
        })
    }
    func performGetHospitalDetails() {
        checkInternet()
        let hospitalID = Patient.sharedInfo.userInfo!.hospitalTypeID
        ActivityIndicatorView.sharedActivityView.showOverlay()
        let caseID = Patient.sharedInfo.patientInfo?.caseID
        
        let dict : [String : AnyObject] = ["nurseHospitalID":hospitalID!, "neededHospitalTypeID":"2", "caseID":caseID!]
        // TODO: In future if we have a screen to cchange the hospitla type we can use this parameter : neededHospitalTypeID
        APIRequest.sharedAPI.getHospitalListing(dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.hospitalListArray = (jsonString?.array)!
                    self.navigateToHospitalListScreen()
                } else {
                    super.handleError(error)
                    
                }
            })
        })
    }

    func performGetCASEDetails() {
        checkInternet()
        if  Patient.sharedInfo.patientInfo?.caseID != nil {
            let dict = [PatientInfoKey.CaseID.rawValue:Patient.sharedInfo.patientInfo?.caseID as! AnyObject
            ]
            APIRequest.sharedAPI.getCASEDetails(dictionary:dict,completion: {
                (jsonString, successful, error, response) in
                dispatch_async(dispatch_get_main_queue(), {
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    if successful {
                          PatientManager.updateCaseDetails(jsonString)
                          let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
                          appDelegate?.refreshScreen = true
                          self.navigateToViewSummary()
                    } else {
                        var errorMessage = StringConstants.ErrorTitle
                        if let error = error {
                            errorMessage = error.localizedDescription
                        }
                        super.showAlert(StringConstants.ErrorTitle, alertMsg:errorMessage)
                    }
                })
            })
        }
}

}
