//  MEDPatientInfractAreaTableViewCell.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

class MEDPatientInfractAreaTableViewCell: UITableViewCell {

   
    @IBOutlet weak var otherCommentsPlaceholderLabel: UILabel!
    @IBOutlet weak var otherCommentsCellBgImage: UIImageView!
    @IBOutlet weak var otherCommentsTextView: UITextView!
    @IBOutlet weak var otherCommentsCheckedButton: UIButton!
    @IBOutlet weak var stElevationLabel: UILabel!
    @IBOutlet weak var checkMarkButtonOutlet: UIButton!
    @IBOutlet weak var infractAreaLabel: UILabel!
    @IBOutlet weak var otherCommentsLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
