//  MEDPatientECGPreviewViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

class MEDPatientECGPreviewViewController: MEDBaseViewController, UIScrollViewDelegate {
    @IBOutlet weak var imageView: UIImageView!
    var ecgImage: UIImage!
    @IBOutlet weak var imageViewHeightConstraint: NSLayoutConstraint?
    var caption:String?
    var addCaptionTime:String?
    var isFromMedicalHistory:Bool = false
    @IBOutlet weak var addCaptionTimeLabel: UILabel?
    @IBOutlet weak var addCaptionLabel: UILabel?
    @IBOutlet weak var scrollView: UIScrollView?
    @IBOutlet weak var addCaptionView: UIView?
    struct ECGPreviewStringConstants {
        static var imageTitle = "ECG"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp("")
        
    }
    override func viewDidAppear(animated: Bool) {
        super.addKeyboardObserver(self)
        super.viewDidAppear(animated)
    }
    override func viewDidDisappear(animated: Bool) {
        super.removeKeyBoardObserver(self)
        super.viewDidDisappear(animated)
    }
    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
        super.viewWillDisappear(animated)
    }
    
    func addImageView() {
        scrollView?.contentMode = UIViewContentMode.ScaleAspectFit
        scrollView?.maximumZoomScale = 4.0
        scrollView?.minimumZoomScale = 1.0
        imageView?.contentMode =  .ScaleAspectFit
        imageView?.userInteractionEnabled = true
        imageView?.image = self.ecgImage
        imageViewHeightConstraint?.constant = 10
        if(isFromMedicalHistory == true){
            imageViewHeightConstraint?.constant = 50
            self.addCaptionView?.hidden = false
            self.addCaptionLabel?.text = self.caption
            if(self.addCaptionTime == "101010101"){
                self.addCaptionTimeLabel?.hidden = true
            }else{
                self.addCaptionTimeLabel?.hidden = false
                let time = DateUtility.convertGMTtoLongDate((self.addCaptionTime! as NSString).doubleValue)
                self.addCaptionTimeLabel?.text = time as String
            }
        }
    }
    func toggle(sender: AnyObject) {
        if(self.navigationController?.navigationBar.hidden==true) {
            self.navigationController?.navigationBar.hidden=false
            self.view.backgroundColor=UIColor.whiteColor()
        } else {
            
            self.navigationController?.navigationBar.hidden=true
            self.view.backgroundColor=UIColor.blackColor()
        }
    }
    func cancelButton(sender: AnyObject) {
        scrollView?.removeFromSuperview()
        self.navigationController?.navigationBar.backgroundColor=UIColor.blackColor()
        self.navigationController?.navigationBar.items = nil
    }
    func galleryButton(sender: AnyObject) {
        
    }
    func viewForZoomingInScrollView(scrollView: UIScrollView) -> UIView? {
        return imageView
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
// MARK: - Custom Actions
extension MEDPatientECGPreviewViewController {
    override func initialSetUp(bgImage: String) {
        setNavigationBackButtonImage()
        addImageView()
        
    }
    
}
