//  MEDStopTreatmentController.swift
//  Copyright © 2017 Medtronic. All rights reserved.

import UIKit

class MEDStopTreatmentController: MEDBaseViewController {
    var doneBarButton = UIBarButtonItem()
    @IBOutlet weak var stopTreatmentTV: UITableView!
    var cancelTrtArrForEDN = NSMutableArray()
    var cancelTrtArrForCATHLAB = NSMutableArray()
    var commonArr = NSMutableArray()
    var test = NSArray()
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetup()
    }
    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
        super.viewWillDisappear(animated)
    }
    override func viewWillAppear(animated: Bool) {
        if patientInfo != nil {
            startTimer()
        }
    }
}
// MARK: - Custom Actions
extension MEDStopTreatmentController {
    func initialSetup() {
        self.navigationItem.rightBarButtonItem = nil
        setNavigationBackButtonImage()
        getNavigationRightBarButtonItem()
        getDataFromPlist()
        setReasonsForUser()
    }
    
    func getDataFromPlist(){
        if let path = FileUtility.getPlistPath() {
            if let metaDataPList = NSDictionary(contentsOfFile: path) {
                let array = metaDataPList.objectForKey("CancelTreatmentOptionsForEDNurse") as! NSArray
                self.cancelTrtArrForEDN = array.mutableCopy() as! NSMutableArray
                self.cancelTrtArrForCATHLAB = metaDataPList.objectForKey("CancelTreatmentOptionsForCathLab") as! NSMutableArray
                self.test = (metaDataPList.objectForKey("test") as? NSArray)!
            }
        }
    }
    
    func setReasonsForUser(){
        let user = LoginManager.getLoggedInUser()
        if (user != nil) {
            print(user?.roleID)
            switch (user?.roleID)! as String {
            case "1"://Spoke or Hub
                commonArr = cancelTrtArrForEDN
            case "2"://CathLab
                commonArr = cancelTrtArrForCATHLAB
            case "3": break//Cardio
            //DO Nothing
            default: break
            }
        }
    }
    
    override func setNavigationBackButtonImage() {
        let image = UIImage(named: ButtonTitles.BackIcon)
        let backButton = UIButton(type: UIButtonType.Custom)
        backButton.addTarget(self, action: #selector(backButtonAction), forControlEvents: UIControlEvents.TouchUpInside)
        backButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: -30, bottom: 0, right: -10)
        backButton.setImage(image, forState: UIControlState.Normal)
        backButton.sizeToFit()
        let backButtonItem = UIBarButtonItem(customView: backButton)
        self.navigationItem.leftBarButtonItem = backButtonItem
    }
    
    override func backButtonAction(button: UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    func getNavigationRightBarButtonItem() {
        doneBarButton = UIBarButtonItem(title: "Done", style: .Plain, target: self, action: #selector(doneBtnAction))
        
        let color : UIColor = UIColor.whiteColor()
        let titleFont : UIFont = UIFont(name: "effra-regular", size: 14.0)!
        let attributes = [
            NSForegroundColorAttributeName : color,
            NSFontAttributeName : titleFont
        ]
        doneBarButton.setTitleTextAttributes(attributes, forState: UIControlState.Normal)
        self.navigationItem.rightBarButtonItem = doneBarButton
        
        
    }
    func doneBtnAction()
    {
        print("DONE BUTTON ACTION")
    }
}
 // MARK: - tableView delegate methods
 extension MEDStopTreatmentController: UITableViewDelegate{
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return commonArr.count
    }
}

 // MARK: - tableView data source methods
 extension MEDStopTreatmentController: UITableViewDataSource{
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = stopTreatmentTV.dequeueReusableCellWithIdentifier("STOPTREATMENTCELLIDENTIFIER", forIndexPath: indexPath) as! MEDStopTreatmentCustomCell
        let dataDict : NSMutableDictionary = commonArr[indexPath.row] as! NSMutableDictionary
        cell.trtReasonLbl.text = dataDict["VALUE"] as? String
        print(dataDict)
        let isSelected = dataDict["SELECTED"] as! Bool
        if isSelected
        {
            cell.trtCheckMarkIV.image = UIImage(named: "checkedGenderImage")
        }
        return cell
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        var i = 0
        for dict in commonArr {
            i += 1
            let mutableDict = dict.mutableCopy()
            mutableDict.setValue(false, forKey: "SELECTED")
            print("~~ \(mutableDict)")
            let immutableDict = mutableDict.copy()
            commonArr[i] = immutableDict
        }
        
        let selDataDict = commonArr.objectAtIndex(indexPath.row).mutableCopy()
        selDataDict.setValue(true, forKey: "SELECTED")
        
        let immDict = selDataDict.copy()
        commonArr[indexPath.row] = immDict
        
        //        let testArr = commonArr.mutableCopy()
        //        let selDataDict = testArr.objectAtIndex(indexPath.row).mutableCopy()
        //        print(selDataDict)
        //        selDataDict.setValue(true, forKey: "SELECTED")
        //        //selDataDict["SELECTED"] = true
        //        print("testArr",testArr)
        //
        //
        //        commonArr = testArr as! NSMutableArray
        //        print("testArr",testArr)
        //        print("commonArr",commonArr)
        stopTreatmentTV.reloadData()
    }
}




    