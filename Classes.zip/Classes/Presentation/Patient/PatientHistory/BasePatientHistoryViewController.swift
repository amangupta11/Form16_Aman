//  BasePatientHistoryViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import Firebase
enum PatientHistoryTabs: String {
    case ClinicalExamination = "ClinicalExamination"
    case MedicalHistory = "MedicalHistory"
}
class BasePatientHistoryViewController: MEDBaseViewController,AlertViewControllerProtocol {
    @IBOutlet weak var clinicalExaminationButtonOutlet: UIButton!
    @IBOutlet weak var ClinicalExaminationHilightView: UIView!
    @IBOutlet weak var medicalHistoryButtonOutlet: UIButton!
    @IBOutlet weak var MedicalHistoryHilightView: UIView!
    @IBOutlet weak var containerView: UIView!
    var saveBarbutton: UIBarButtonItem!
    var currentTab: PatientHistoryTabs!
    var medicalHistoryDict: NSMutableDictionary? = nil
    var medicalHistoryViewController:MedicalHistoryViewController!
    var isClinicalExaminationDataChanged = false
    var isMedicalHistoryDataChanged = false
    var clinicalExaminationViewController:ClinicalExaminationViewController!
    var alertViewIdentifier:alertViewIdentifiers?
    enum alertViewIdentifiers{
        case BackButtonConfirmation
    }
    struct PatientHistoryConstants {
        static  var DataUnsavedMsgForClicnicalExam = NSLocalizedString("YOU_WILL_LOSE_DATA_FOR_CLINICAL_EXAMINATION", comment: "")
        static  var DataUnsavedMsgForMedicalHistory = NSLocalizedString("YOU_WILL_LOSE_DATA_FOR_MEDICAL_HISTORY", comment: "")
        static  var DataUnsavedMsgForClicnicalExamAndMedicalHistory = NSLocalizedString("YOU_WILL_LOSE_DATA_FOR_CLINICAL_EXAMINATION_AND_MEDICAL_HISTORY", comment: "")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetup()
    }
    func initialSetup() {
        setNavigationBackButtonImage()
        self.navigationController!.navigationBar.tintColor = UIColor.whiteColor()
        saveBarbutton = UIBarButtonItem(barButtonSystemItem: .Save, target: self, action: #selector(saveButtonAction(_:)))
        self.clinicalExaminationButtonAction()
        if Patient.sharedInfo.patientInfo?.caseStatus == statusKey.Completed.rawValue || Patient.sharedInfo.patientInfo?.caseStatus == statusKey.Cancelled.rawValue{
            // Case is completed
            // Read only. Do not add save button
        }else{
            self.navigationItem.rightBarButtonItem = saveBarbutton
        }
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        startTimer()
        FIRAnalytics.setScreenName(FireBaseConstants.patientHistory, screenClass: FireBaseConstants.patientHistory)
    }
    override func viewDidLayoutSubviews() {
        self.adjustButtonColors()
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
    }
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        invalidateTimer()
    }
    func adjustButtonColors(){
        if self.currentTab.rawValue == PatientHistoryTabs.ClinicalExamination.rawValue {
            self.clinicalExaminationButtonOutlet.setTitleColor(UIColor.whiteColor(), forState: .Normal)
            self.medicalHistoryButtonOutlet.setTitleColor(ColorPicker.whiteColorFade(), forState: .Normal)
        }
        else if self.currentTab.rawValue == PatientHistoryTabs.MedicalHistory.rawValue {
            self.medicalHistoryButtonOutlet.setTitleColor(UIColor.whiteColor(), forState: .Normal)
            self.clinicalExaminationButtonOutlet.setTitleColor(ColorPicker.whiteColorFade(), forState: .Normal)
        }
    }
    func saveButtonAction(sender: AnyObject) {
        if self.currentTab.rawValue == PatientHistoryTabs.ClinicalExamination.rawValue {
           if self.clinicalExaminationViewController.validateClinicalExaminationUI()
           {
            self.clinicalExaminationViewController.saveClinicalExamiation()
            }
        }
        else if self.currentTab.rawValue == PatientHistoryTabs.MedicalHistory.rawValue {
            self.medicalHistoryViewController.saveMedicalHistory()
        }
        self.adjustButtonColors()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func clinicalExaminationButtonAction() {
        currentTab = PatientHistoryTabs.ClinicalExamination
        self.clinicalExaminationButtonOutlet.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        self.medicalHistoryButtonOutlet.setTitleColor(ColorPicker.whiteColorFade(), forState: .Normal)
        self.ClinicalExaminationHilightView.hidden = false
        self.MedicalHistoryHilightView.hidden = true
        removeMedicalHistoryViewControllerAsChild()
        self.navigationItem.rightBarButtonItem?.enabled = true
        addClinicalExaminationViewControllerAsChild()
    }
    @IBAction func medicalHistoryButtonAction() {
        dispatch_async(dispatch_get_main_queue(), {
            self.currentTab = PatientHistoryTabs.MedicalHistory
            self.medicalHistoryButtonOutlet.setTitleColor(UIColor.whiteColor(), forState: .Normal)
            self.clinicalExaminationButtonOutlet.setTitleColor(ColorPicker.whiteColorFade(), forState: .Normal)
            self.ClinicalExaminationHilightView.hidden = true
            self.MedicalHistoryHilightView.hidden = false
            self.removeClinicalExaminationViewControllerAsChild()
            self.addMedicalHistoryViewControllerAsChild()
        })
    }
    func addClinicalExaminationViewControllerAsChild() {
        if clinicalExaminationViewController == nil {
            let storyBoard = UIStoryboard(name: "MedicalHistory", bundle: nil)
            self.clinicalExaminationViewController = storyBoard.instantiateViewControllerWithIdentifier("ClinicalExaminationViewController") as! ClinicalExaminationViewController
            //self.clinicalExaminationViewController.patientInfo = self.patientInfo
            self.clinicalExaminationViewController.clinicalExaminationDetailsDict = self.medicalHistoryDict?.valueForKey("clinicalExaminationDetailsDict") as? NSMutableDictionary
            if self.clinicalExaminationViewController == nil {
                return
            }
        }
        self.addChildViewController(self.clinicalExaminationViewController)
        // Adding Constraints to root view of child view controller
        if self.clinicalExaminationViewController != nil {
        self.clinicalExaminationViewController.view!.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(self.clinicalExaminationViewController.view!)
        let leadingConstraint = NSLayoutConstraint(item: self.clinicalExaminationViewController.view!, attribute: NSLayoutAttribute.Leading, relatedBy: NSLayoutRelation.Equal, toItem: self.containerView, attribute: NSLayoutAttribute.Leading, multiplier: 1, constant: 0)
        let trailingConstraint = NSLayoutConstraint(item: self.clinicalExaminationViewController.view!, attribute: NSLayoutAttribute.Trailing, relatedBy: NSLayoutRelation.Equal, toItem: self.containerView, attribute: NSLayoutAttribute.Trailing, multiplier: 1, constant: 0)
        let topConstraint = NSLayoutConstraint(item: self.clinicalExaminationViewController.view!, attribute: NSLayoutAttribute.Top, relatedBy: NSLayoutRelation.Equal, toItem: self.containerView, attribute: NSLayoutAttribute.Top, multiplier: 1, constant: 0)
        let bottomConstraint = NSLayoutConstraint(item: self.clinicalExaminationViewController.view!, attribute: NSLayoutAttribute.Bottom, relatedBy: NSLayoutRelation.Equal, toItem: self.containerView, attribute: NSLayoutAttribute.Bottom, multiplier: 1, constant: 0)
        NSLayoutConstraint.activateConstraints([leadingConstraint, trailingConstraint,topConstraint, bottomConstraint])
        self.clinicalExaminationViewController.didMoveToParentViewController(self)
        }
    }
    func removeClinicalExaminationViewControllerAsChild() {
        if (self.childViewControllers.count >= 1 && self.clinicalExaminationViewController != nil){
            self.clinicalExaminationViewController.willMoveToParentViewController(nil)
            self.clinicalExaminationViewController.view!.removeFromSuperview()
            self.clinicalExaminationViewController.removeFromParentViewController()
        }
    }
    func addMedicalHistoryViewControllerAsChild() {
        if medicalHistoryViewController == nil {
            let storyBoard = UIStoryboard(name: "PatientHistory", bundle: nil)
            self.medicalHistoryViewController = storyBoard.instantiateViewControllerWithIdentifier("MedicalHistoryViewController") as! MedicalHistoryViewController
           // self.medicalHistoryViewController.patientInfo = self.patientInfo
            self.medicalHistoryViewController.medicalHistoryDict = self.medicalHistoryDict
            self.medicalHistoryViewController.medicalNotes = self.medicalHistoryDict?.valueForKey("medicalHistoryNotes") as? String
            self.medicalHistoryViewController.medicalHistoryImagesArray = self.medicalHistoryDict?.valueForKey("images") as? NSMutableArray
            if self.medicalHistoryViewController == nil {
                return
            }
        }
        self.addChildViewController(self.medicalHistoryViewController)
        self.view.addSubview(self.medicalHistoryViewController.view!)
        self.medicalHistoryViewController.view?.frame = self.containerView.frame
        self.medicalHistoryViewController.didMoveToParentViewController(self)
    }
    func removeMedicalHistoryViewControllerAsChild() {
            if (self.childViewControllers.count >= 1 && self.medicalHistoryViewController != nil){
            self.medicalHistoryViewController.willMoveToParentViewController(nil)
            self.medicalHistoryViewController.view!.removeFromSuperview()
            self.medicalHistoryViewController.removeFromParentViewController()
        }
    }
    override func backButtonAction(button: UIButton) {
        FIRAnalytics.logEventWithName(FireBaseEvents.patientHisToSummary, parameters:nil)
        if isMedicalHistoryDataChanged == true || isClinicalExaminationDataChanged == true {
            if Patient.sharedInfo.patientInfo?.caseStatus == statusKey.Completed.rawValue || Patient.sharedInfo.patientInfo?.caseStatus == statusKey.Cancelled.rawValue{
                self.navigationController?.popViewControllerAnimated(true)
            }
            else{
                // show alert if any data is unsaved
                var alertMessage = ""
                if isMedicalHistoryDataChanged == true && isClinicalExaminationDataChanged == true {
                    alertMessage = PatientHistoryConstants.DataUnsavedMsgForClicnicalExamAndMedicalHistory
                } else if isClinicalExaminationDataChanged == true{
                    alertMessage = PatientHistoryConstants.DataUnsavedMsgForClicnicalExam
                }else{
                    alertMessage = PatientHistoryConstants.DataUnsavedMsgForMedicalHistory
                }
                self.alertViewIdentifier = alertViewIdentifiers.BackButtonConfirmation
                self.showAlertWithTwoButtons(StringConstants.ConfirmationTitle, alertMsg: alertMessage)
            }
        }else{
            self.navigationController?.popViewControllerAnimated(true)
        }
    }
}

// MARK: - ALERT VIEW DELEGATES
extension BasePatientHistoryViewController{
    func showAlertWithTwoButtons(alertTitle: String, alertMsg: String) {
        let alertCntrl = AlertController()
        alertCntrl.delegate = self
        let alertController = alertCntrl.showCustomAlertWithTwoActions(alertTitle, message:alertMsg, okTitle: AlertViewButtonTitle.NoButtonTitle, cancelTitle: AlertViewButtonTitle.YesButtonTitle, prefereredStyle: UIAlertControllerStyle.Alert, tag:AlertViewTag.AlertViewTagForStemiButton.rawValue)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
    func cancelButtonAction(alertController: UIAlertController) {
         alertController.dismissViewControllerAnimated(true, completion: nil)
        if alertViewIdentifier == alertViewIdentifiers.BackButtonConfirmation{
            // User has tapped on yes for the confirmation alert
            self.navigationController?.popViewControllerAnimated(true)
        }
    }
    func OKButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
    func defaultButtonAction(alertController: UIAlertController) {
        self.view.endEditing(true)
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
}