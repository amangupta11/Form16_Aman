//  ClinicalExaminationViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import Firebase
let MAXIMUM_ALLOWED_CHARACTERS_FOR_DESCRIPTION = 50.0
let MAXIMUM_ALLOWED_CHARACTERS_FOR_ESTIMATED_WEIGHT = 6.0
let MAXIMUM_ALLOWED_CHARACTERS_FOR_TROPONIN = 6.0
let MAXIMUM_ALLOWED_CHARACTERS_FOR_SYSTOLIC = 3.0
let MAXIMUM_ALLOWED_CHARACTERS_FOR_DIASTOLIC = 3.0
let MAXIMUM_ALLOWED_CHARACTERS_FOR_PULSE = 3.0
let MAXIMUM_ALLOWED_CHARACTERS_FOR_TEMPERATURE = 5.0
let MAXIMUM_ALLOWED_CHARACTERS_FOR_SPO2 = 3.0

class ClinicalExaminationViewController: MEDBaseViewController, UITextFieldDelegate {
    @IBOutlet var complaintTypeDropDown: UIImageView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var complaintTypeLabel: UILabel!
    @IBOutlet weak var PatientPointOfFirstMedicalContact_Label: UILabel!
    @IBOutlet weak var estimatedWeight_Label: UILabel!
    @IBOutlet weak var complaintType_Label: UILabel!
    @IBOutlet weak var complaintType_BorderView: UIView!
    @IBOutlet weak var lastEpisodeAndDescription_BorderView: UIView!
    @IBOutlet weak var systolicTextField: UITextField!
    @IBOutlet weak var systolicLineLabel: UILabel!
    @IBOutlet weak var diastolicTextField: UITextField!
    @IBOutlet weak var diastolicLineLabel: UILabel!
    @IBOutlet weak var pulseTextField: UITextField!
    @IBOutlet weak var pulseLineLabel: UILabel!
    @IBOutlet weak var tempTextField: UITextField!
    @IBOutlet weak var tempLineLabel: UILabel!
    @IBOutlet weak var spo2TextField: UITextField!
    @IBOutlet weak var spo2LineLabel: UILabel!
    @IBOutlet weak var estimatedWeight_TextField: UITextField!
    @IBOutlet weak var estimatedWeight_Border: UIView!
    @IBOutlet weak var troponin_TextField: UITextField!
    @IBOutlet weak var troponin_Border: UIView!
    @IBOutlet weak var complaintTypeView: UIView!
    @IBOutlet weak var contentViewHeight: NSLayoutConstraint!
    @IBOutlet weak var complaintTypeViewHeight: NSLayoutConstraint!
    @IBOutlet weak var lastEpisodeLabel: UILabel!
    @IBOutlet weak var LastEpisodeView: UIView!
    @IBOutlet weak var lastEpisodeDateTimeLogo: UIImageView!
    @IBOutlet weak var LastEpisode_TextField: UITextField!
    @IBOutlet weak var generalPractitioner_Label: UILabel!
    @IBOutlet weak var description_TextField: UITextField!
    @IBOutlet weak var lastEpisode_TransparentButton: UIButton!
    @IBOutlet weak var killipScoreOneButton: UIButton!
    @IBOutlet weak var killipScoreTwoButton: UIButton!
    @IBOutlet weak var killipScoreThreeButton: UIButton!
    @IBOutlet weak var killipScoreFourButton: UIButton!
    @IBOutlet weak var patientPointOfFMC_ThisCenter_Button: UIButton!
    @IBOutlet weak var patientPointOfFMC_GeneralPractitioner_Button: UIButton!
    @IBOutlet weak var scrollViewContainerView: UIView!
    @IBOutlet weak var patientPointOfFMC_Other_Button: UIButton!
    var pickerContainerDelegate: MEDPickerContainerDelegate!
    var pickerContainerView: UIView!
    var complaintTypeArray: NSArray!
    var primaryComplaintId: Int = 0
    var pickerViewIdentifierString: PickerViewIdentifiers!
    var pickerViewtag: Int!
    var initialIndex: Int! = 0
    var scrollOffset: CGPoint!
    var currentTextField: UITextField!
    var killipScore:Int! = 1
    var patientPointOfFMC:Int! = 0
    var clinicalExaminationDetailsDict: NSMutableDictionary? = nil
    var authorizationAlert:Bool = false
    var lastEpisodeTime:NSString? = nil
    var presentingComplaintDescription:NSString? = nil
    static var defaultComplaintType = "Chest Pain"
    struct ClinicalExamStringConstants {
        static  var AlertTitle = NSLocalizedString("ATTENTION", comment: "")
        static  var AlertMessage = NSLocalizedString("THERE_HAS_BEEN_AN_UPDATE_ON_THIS_CASE", comment: "")
    }
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUp("")
        self.automaticallyAdjustsScrollViewInsets = false
    }
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        checkStatus()
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        super.addKeyboardObserver(self)
        checkStatus()
    }
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        super.removeKeyBoardObserver(self)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }
    // MARK: - @IBAction Methods
    @IBAction func complaintTypeButtonAction(sender: AnyObject) {
        FIRAnalytics.logEventWithName(FireBaseEvents.presentingComplaints, parameters:nil)
        self.view.endEditing(true)
        var selectedIndex: Int = 0
        if self.complaintTypeLabel.text?.characters.count > 0 {
            for i in 0..<self.complaintTypeArray.count {
                if self.complaintTypeLabel.text! == self.complaintTypeArray[i] as? String {
                    selectedIndex = i
                    break
                }
            }
        }
        self.initializePickerContainerView()
        self.pickerContainerDelegate.index = selectedIndex
        self.primaryComplaintId = selectedIndex
        self.pickerContainerView =
            self.pickerContainerDelegate.customPickerView(self.complaintTypeArray)
        self.makeTransparentScreenColor()
        self.pickerViewIdentifierString = PickerViewIdentifiers.ComplaintType
        if(self.complaintTypeLabel.text == nil || self.complaintTypeLabel.text == "") {
            self.pickerContainerDelegate.pickerView.selectRow(self.complaintTypeArray.indexOfObject(ClinicalExaminationViewController.defaultComplaintType), inComponent: 0, animated: true)
        }
        else{
        self.pickerContainerDelegate.pickerView.selectRow(self.complaintTypeArray.indexOfObject(self.complaintTypeLabel.text!), inComponent: 0, animated: true)
        }
        self.addPickerContainerView()
    }
    @IBAction func lastEpisodeButtonAction(sender: AnyObject) {
        addPickerView(20)
    }
    // MARK: - Custom Methods
    override func initialSetUp(bgImage: String) {
        setTapGestureForView()
        updateConstraints ()
        self.loadComplaintTypes()
        setDefaultUIInitializations()
        let parentController = self.parentViewController as! BasePatientHistoryViewController
        parentController.isClinicalExaminationDataChanged = false
        if Patient.sharedInfo.patientInfo?.caseStatus == statusKey.Completed.rawValue || Patient.sharedInfo.patientInfo?.caseStatus == statusKey.Cancelled.rawValue{
            //Case is completed
            // MARK it as read only
            self.scrollViewContainerView.userInteractionEnabled = false
        }
    }
    func navigateToHome() {
        if self.navigationController?.viewControllers.first is MEDHomeViewController
        {
            let topViewController = self.navigationController?.viewControllers.first as! MEDHomeViewController
            topViewController.shouldTableViewRefresh = true
        }
        //DataOperation.sharedDataOperation.deleteManagedObject(patientInfo!)
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    func showUnauthorizationAlert() {
        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        alertView = alertController.showSimpleAlert(ClinicalExamStringConstants.AlertTitle, message:ClinicalExamStringConstants.AlertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)
    }
    func updateUI(){
        
    }
    func checkStatus() {
        if (Patient.sharedInfo.patientInfo?.caseStatus == statusKey.Completed.rawValue || Patient.sharedInfo.patientInfo?.caseStatus == statusKey.Cancelled.rawValue ) {
            enableScreenToReadOnlyMode()
        }
    }
    func enableScreenToReadOnlyMode(){
        complaintTypeDropDown.hidden = true
        lastEpisodeDateTimeLogo.hidden = true
        complaintType_BorderView.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
        lastEpisodeAndDescription_BorderView.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
        systolicLineLabel.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
        diastolicLineLabel.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
        pulseLineLabel.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
        tempLineLabel.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
        spo2LineLabel.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
        estimatedWeight_Border.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
        troponin_Border.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
    }
    func showSimpleAlert(alertTitle: String, message: String){
        let alertCntrl = AlertController()
        alertCntrl.delegate = self
        let alertController = alertCntrl.showSimpleAlert(alertTitle, message: message, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
    func saveClinicalExamiation (){
        if let _ = self.currentTextField{
        self.currentTextField.resignFirstResponder()
        }
        self.clinicalExaminationDetailsDict?.setValue(Patient.sharedInfo.patientInfo?.caseID, forKey: PatientHistoryInfoKey.CaseID.rawValue)
        // PrimaryComplaint Details
        if self.complaintTypeLabel.text != "" {
            let primaryComplaintDetailsDict: NSMutableDictionary! = NSMutableDictionary()
            primaryComplaintDetailsDict.setValue(self.primaryComplaintId, forKey: PatientHistoryInfoKey.Id.rawValue)
            primaryComplaintDetailsDict.setValue(self.complaintTypeLabel.text, forKey: PatientHistoryInfoKey.Value.rawValue)
            self.clinicalExaminationDetailsDict?.setValue(primaryComplaintDetailsDict, forKey: PatientHistoryInfoKey.PrimaryComplaint.rawValue)
        }
        if (self.primaryComplaintId == 0 && LastEpisode_TextField.text!.characters.count != 0) {
            let dateString = String(format: "%@", (LastEpisode_TextField.text)!)
            var hubDoorInTime: [String:AnyObject] = [:]
            hubDoorInTime[TimeLineKey.Comment.rawValue] = nil
            hubDoorInTime[TimeLineKey.Location.rawValue] = nil
            hubDoorInTime[TimeLineKey.Time.rawValue] = DateUtility.convertStringToDate(dateString)
            self.clinicalExaminationDetailsDict?.setObject(hubDoorInTime, forKey: PatientHistoryInfoKey.Time.rawValue)
            self.clinicalExaminationDetailsDict?.removeObjectForKey(PatientHistoryInfoKey.Description.rawValue)
        }
        else if self.primaryComplaintId == 2{
            self.manageLeadingAndTrailingSpacesForDescription()
            self.clinicalExaminationDetailsDict?.setValue(self.description_TextField.text, forKey: PatientHistoryInfoKey.Description.rawValue)
            self.clinicalExaminationDetailsDict?.removeObjectForKey(PatientHistoryInfoKey.Time.rawValue)
        }
        else
        {
            self.description_TextField.text = ""
            self.LastEpisode_TextField.text = ""
            self.clinicalExaminationDetailsDict?.removeObjectForKey(PatientHistoryInfoKey.Time.rawValue)
            self.clinicalExaminationDetailsDict?.removeObjectForKey(PatientHistoryInfoKey.Description.rawValue)
        }
        // VitalSigns Details
        let vitalSignsDetailsDict: NSMutableDictionary! = NSMutableDictionary()
        vitalSignsDetailsDict.setValue(self.killipScore, forKey: PatientHistoryInfoKey.KillipScore.rawValue)
        vitalSignsDetailsDict.setValue(self.tempTextField.text, forKey: PatientHistoryInfoKey.Temperature.rawValue)
        vitalSignsDetailsDict.setValue(self.diastolicTextField.text, forKey: PatientHistoryInfoKey.Diastolic.rawValue)
        vitalSignsDetailsDict.setValue(self.pulseTextField.text, forKey: PatientHistoryInfoKey.Pulse.rawValue)
        vitalSignsDetailsDict.setValue(self.spo2TextField.text, forKey: PatientHistoryInfoKey.Spo2.rawValue)
        vitalSignsDetailsDict.setValue(self.systolicTextField.text, forKey: PatientHistoryInfoKey.Systolic.rawValue)
        self.clinicalExaminationDetailsDict?.setValue(vitalSignsDetailsDict, forKey: PatientHistoryInfoKey.VitalSigns.rawValue)
        if self.estimatedWeight_TextField.text != "" {
            self.clinicalExaminationDetailsDict?.setValue(self.estimatedWeight_TextField.text, forKey: PatientHistoryInfoKey.patientEstimatedWeight.rawValue)
        }
        if self.troponin_TextField.text != "" {
            self.clinicalExaminationDetailsDict?.setValue(self.troponin_TextField.text, forKey: PatientHistoryInfoKey.patientTroponin.rawValue)
        }
        self.clinicalExaminationDetailsDict?.setValue(self.patientPointOfFMC, forKey: PatientHistoryInfoKey.patientPointOfFMC.rawValue)
        setPatientClinicalExamination()
    }
    func manageLeadingAndTrailingSpacesForDescription() {
        let myString = self.description_TextField.text!
        self.description_TextField.text = myString.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
    }
    func adjustDynamicBehaviourOfPresentingComplaintSection(){
        complaintTypeView.clipsToBounds = true
        lastEpisodeLabel.hidden = true
        LastEpisodeView.hidden = true
        complaintTypeViewHeight.constant = 81
        contentViewHeight.constant = 660
    }
    func updateConstraints(){
        self.scrollOffset = self.scrollView.contentOffset
        self.PatientPointOfFirstMedicalContact_Label.adjustsFontSizeToFitWidth = true
        self.estimatedWeight_Label.adjustsFontSizeToFitWidth = true
        self.generalPractitioner_Label.adjustsFontSizeToFitWidth = true
    }
    func setTapGestureForView() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:) ))
        self.view.addGestureRecognizer(tapGesture)
    }
    func handleTap(sender: UIView) {
        view.endEditing(true)
    }
    func setDefaultUIInitializations() {
        if let value = self.clinicalExaminationDetailsDict![PatientHistoryInfoKey.patientPointOfFMC.rawValue]?.intValue! {
            self.patientPointOfFMC = Int(value)
        }
        self.adjustPatientPointOfFMCButtons()
        if self.clinicalExaminationDetailsDict![PatientHistoryInfoKey.PrimaryComplaint.rawValue] != nil {
            let presentingComplaintDict:NSDictionary! = self.clinicalExaminationDetailsDict![PatientHistoryInfoKey.PrimaryComplaint.rawValue]! as! NSDictionary
            if  presentingComplaintDict != nil {
                if let value = presentingComplaintDict![PatientHistoryInfoKey.Id.rawValue]?.intValue! {
                    let complaintType = self.complaintTypeArray[Int(value)] as! String
                    self.initialIndex = Int(value)
                    self.complaintTypeLabel.text = presentingComplaintDict![PatientHistoryInfoKey.Value.rawValue] as? String
                    if self.clinicalExaminationDetailsDict![PatientHistoryInfoKey.Time.rawValue] != nil{
                        lastEpisodeTime =  self.clinicalExaminationDetailsDict![PatientHistoryInfoKey.Time.rawValue]! as! String
                    }
                    if self.clinicalExaminationDetailsDict![PatientHistoryInfoKey.Description.rawValue] != nil{
                        presentingComplaintDescription = self.clinicalExaminationDetailsDict![PatientHistoryInfoKey.Description.rawValue]! as! String
                    }
                    dynamicHandlingForPAtientComplaint(complaintType)
                }
            }
        }
        else{
            adjustDynamicBehaviourOfPresentingComplaintSection()
        }
        let vitalSignsDict:NSDictionary! = self.clinicalExaminationDetailsDict![PatientHistoryInfoKey.VitalSigns.rawValue]! as! NSDictionary
        if let value = vitalSignsDict![PatientHistoryInfoKey.Systolic.rawValue]?.intValue! {
            self.systolicTextField.text = String(value)
        }
        if let value = vitalSignsDict![PatientHistoryInfoKey.Diastolic.rawValue]?.intValue! {
            self.diastolicTextField.text = String(value)
        }
        if let value = vitalSignsDict![PatientHistoryInfoKey.Pulse.rawValue]?.intValue! {
            self.pulseTextField.text = String(value)
        }
        if let value = vitalSignsDict![PatientHistoryInfoKey.Temperature.rawValue]?.doubleValue! {
            self.tempTextField.text = String(value)
        }
        if let value = vitalSignsDict![PatientHistoryInfoKey.Spo2.rawValue]?.intValue! {
            self.spo2TextField.text = String(value)
        }
        if let value = vitalSignsDict![PatientHistoryInfoKey.KillipScore.rawValue]?.intValue! {
            self.killipScore = Int(value)
        }
        self.adjustKillipScoreButtons()
        if let value = self.clinicalExaminationDetailsDict![PatientHistoryInfoKey.patientEstimatedWeight.rawValue]?.doubleValue! {
            if value != 0 {
                self.estimatedWeight_TextField.text = String(value)
            }
        }
        if let value = self.clinicalExaminationDetailsDict![PatientHistoryInfoKey.patientTroponin.rawValue]?.intValue! {
            if value != 0 {
                self.troponin_TextField.text = String(value)
            }
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func loadComplaintTypes() {
        let metaDataPList: NSDictionary!
        if let path = FileUtility.getPlistPath() {
            metaDataPList = NSDictionary(contentsOfFile: path)
            self.complaintTypeArray = metaDataPList.objectForKey("ComplaintTypes") as? NSArray
        }
    }
    @IBAction func killipScoreButtonAction(sender: AnyObject) {
        self.killipScore = sender.tag - 11;
        self.adjustKillipScoreButtons()
    }
    @IBAction func patientPointOfFirstMCButtonAction(sender: AnyObject) {
        FIRAnalytics.logEventWithName(FireBaseEvents.pointOfFMC, parameters:nil)
        self.patientPointOfFMC = sender.tag - 16;
        self.adjustPatientPointOfFMCButtons()
    }
    func adjustPatientPointOfFMCButtons()  {
        if self.patientPointOfFMC == 0 {
            if (self.patientPointOfFMC_ThisCenter_Button.selected == false){
                let parentController = self.parentViewController as! BasePatientHistoryViewController
                parentController.isClinicalExaminationDataChanged = true
            }
            self.patientPointOfFMC_ThisCenter_Button.selected = true
            self.patientPointOfFMC_GeneralPractitioner_Button.selected = false
            self.patientPointOfFMC_Other_Button.selected = false
        }
        else if self.patientPointOfFMC == 1{
            if (self.patientPointOfFMC_GeneralPractitioner_Button.selected == false){
                let parentController = self.parentViewController as! BasePatientHistoryViewController
                parentController.isClinicalExaminationDataChanged = true
            }
            self.patientPointOfFMC_ThisCenter_Button.selected = false
            self.patientPointOfFMC_GeneralPractitioner_Button.selected = true
            self.patientPointOfFMC_Other_Button.selected = false
        }
        else if self.patientPointOfFMC == 2{
            if (self.patientPointOfFMC_Other_Button.selected == false){
                let parentController = self.parentViewController as! BasePatientHistoryViewController
                parentController.isClinicalExaminationDataChanged = true
            }
            self.patientPointOfFMC_ThisCenter_Button.selected = false
            self.patientPointOfFMC_GeneralPractitioner_Button.selected = false
            self.patientPointOfFMC_Other_Button.selected = true
        }
    }
    func adjustKillipScoreButtons()  {
        if self.killipScore == 1 {
            if (self.killipScoreOneButton.selected == false){
                let parentController = self.parentViewController as! BasePatientHistoryViewController
                parentController.isClinicalExaminationDataChanged = true
            }
            self.killipScoreOneButton.selected = true
            self.killipScoreTwoButton.selected = false
            self.killipScoreThreeButton.selected = false
            self.killipScoreFourButton.selected = false
        }
        else if self.killipScore == 2{
            if (self.killipScoreTwoButton.selected == false){
                let parentController = self.parentViewController as! BasePatientHistoryViewController
                parentController.isClinicalExaminationDataChanged = true
            }
            self.killipScoreOneButton.selected = false
            self.killipScoreTwoButton.selected = true
            self.killipScoreThreeButton.selected = false
            self.killipScoreFourButton.selected = false
        }
        else if self.killipScore == 3{
            if (self.killipScoreThreeButton.selected == false){
                let parentController = self.parentViewController as! BasePatientHistoryViewController
                parentController.isClinicalExaminationDataChanged = true
            }
            self.killipScoreOneButton.selected = false
            self.killipScoreTwoButton.selected = false
            self.killipScoreThreeButton.selected = true
            self.killipScoreFourButton.selected = false
        }
        else if self.killipScore == 4{
            if (self.killipScoreFourButton.selected == false){
                let parentController = self.parentViewController as! BasePatientHistoryViewController
                parentController.isClinicalExaminationDataChanged = true
            }
            self.killipScoreOneButton.selected = false
            self.killipScoreTwoButton.selected = false
            self.killipScoreThreeButton.selected = false
            self.killipScoreFourButton.selected = true
        }
    }
    func initializePickerContainerView() {
        self.pickerContainerDelegate = MEDPickerContainerDelegate(frame: self.navigationController!.view.frame)
        self.pickerContainerDelegate.delegate = self
    }
    func addPickerView(tag: Int) {
        self.view.endEditing(true)
        self.pickerContainerDelegate = MEDPickerContainerDelegate(frame: self.navigationController!.view.frame)
        self.pickerContainerDelegate.delegate = self
        self.pickerContainerView = self.pickerContainerDelegate.datePickerView()
        self.pickerViewtag = 1110
        self.pickerContainerDelegate.datePicker.tag = self.pickerViewtag
        self.pickerContainerDelegate.datePicker.maximumDate = NSDate(timeIntervalSince1970: DateUtility.getCurrentTimeInGMT())
        self.pickerContainerView.backgroundColor = ColorPicker.transparentScreenBackgroundColor()
        self.pickerContainerView.tag = tag
        pickerViewValidation(tag)
        let window = UIApplication.sharedApplication().delegate?.window
        window!!.addSubview(self.pickerContainerView)
    }
    func pickerViewValidation(tag: Int) {
        switch tag {
        case 10:
            validateDATDateAndTime()
            break
        default:
            break
        }
    }
    func makeTransparentScreenColor() {
        self.pickerContainerView.backgroundColor = ColorPicker.transparentScreenBackgroundColor()
    }
    func addPickerContainerView() {
        let window = UIApplication.sharedApplication().delegate?.window
        window!!.addSubview(self.pickerContainerView)
    }
    // MARK: - Validations
    func validateClinicalExaminationUI() -> Bool{
        var isValid = true
        if validatePresetingComplaintFields() == false {
            isValid = false
        }
        if validateVitalSignsFields() == false {
            isValid = false
        }
        if validatePresentationFields() == false {
            isValid = false
        }
        return isValid
    }
    func validateDATDateAndTime() {
        
    }
    // Function for adding the shadow around the corners
    func addShadow(view: UIView) {
        self.complaintTypeView.layer.shadowColor = UIColor.blackColor().CGColor
        self.complaintTypeView.layer.shadowOpacity = 0.15
        self.complaintTypeView.layer.shadowOffset = CGSizeMake(1, 1)
    
        self.complaintTypeView.layer.masksToBounds = false
        self.complaintTypeView.layer.shadowRadius = 2
    }
    func validatePresetingComplaintFields() -> Bool {
        // Validate fields
        var isValid = true
        // Checking invalid details
        if self.complaintTypeLabel.text?.characters.count != 0 {
            if self.complaintTypeLabel.text! == self.complaintTypeArray[0] as! String {
                if self.LastEpisode_TextField.text?.characters.count == 0 {
                    self.lastEpisodeAndDescription_BorderView.backgroundColor = ColorPicker.textFieldHighlightedColor()
                    isValid = false
                }
                else{
                    self.lastEpisodeAndDescription_BorderView.backgroundColor = ColorPicker.warmGreyColor()
                }
            }
            else if self.complaintTypeLabel.text! == self.complaintTypeArray[2] as! String {
                
                if ((self.description_TextField.text?.characters.count == 0) || (self.description_TextField.text?.characters.count > 50)) {
                    self.lastEpisodeAndDescription_BorderView.backgroundColor = ColorPicker.textFieldHighlightedColor()
                    isValid = false
                }
                else{
                    self.lastEpisodeAndDescription_BorderView.backgroundColor = ColorPicker.warmGreyColor()
                }
            }
        }
        return isValid
    }
    func validateVitalSignsFields() -> Bool {
        // Validate fields
        var isValid = true
        // Checking invalid details
        //Systolic TextField
        if self.systolicTextField.text?.characters.count == 0 {
            systolicLineLabel.backgroundColor = ColorPicker.textFieldHighlightedColor()
            isValid = false
        }
        else{
            self.systolicLineLabel.backgroundColor = ColorPicker.warmGreyColor()
        }
        //Diastolic TextField
        if self.diastolicTextField.text?.characters.count == 0 {
            diastolicLineLabel.backgroundColor = ColorPicker.textFieldHighlightedColor()
            isValid = false
        }
        else{
            self.diastolicLineLabel.backgroundColor = ColorPicker.warmGreyColor()
        }
        //Pulse TextField
        if self.pulseTextField.text?.characters.count == 0 {
            pulseLineLabel.backgroundColor = ColorPicker.textFieldHighlightedColor()
            isValid = false
        }
        else{
            self.pulseLineLabel.backgroundColor = ColorPicker.warmGreyColor()
        }
        //Temperature TextField
        if ((self.tempTextField.text?.characters.count == 0) || (MEDPatientValidations.isValidTextWithDecimal(self.tempTextField.text!) == false) || (Double(self.tempTextField.text!) > 50.0) || (Double(self.tempTextField.text!) < 30.0)) {
            
            tempLineLabel.backgroundColor = ColorPicker.textFieldHighlightedColor()
            isValid = false
        }
        else{
            self.tempLineLabel.backgroundColor = ColorPicker.warmGreyColor()
        }
        //Spo2 TextField
        if self.spo2TextField.text?.characters.count == 0 {
            spo2LineLabel.backgroundColor = ColorPicker.textFieldHighlightedColor()
            isValid = false
        }
        else{
            self.spo2LineLabel.backgroundColor = ColorPicker.warmGreyColor()
        }
        if(Double(self.spo2TextField.text!) > 100.0) {
            spo2LineLabel.backgroundColor = ColorPicker.textFieldHighlightedColor()
            isValid = false
        }
        return isValid
    }
    func validatePresentationFields() -> Bool {
        // Validate fields
        var isValid = true
        // Checking invalid details
        if self.estimatedWeight_TextField.text?.characters.count != 0 {
            if ((Double(self.estimatedWeight_TextField.text!) < 0.0) || (Double(self.estimatedWeight_TextField.text!) > 500.0)) {
                self.estimatedWeight_Border.backgroundColor = ColorPicker.textFieldHighlightedColor()
                isValid = false
            }
            else{
                self.estimatedWeight_Border.backgroundColor = ColorPicker.warmGreyColor()
            }
        }
        else{
            self.estimatedWeight_Border.backgroundColor = ColorPicker.warmGreyColor()
        }
        if self.troponin_TextField.text?.characters.count != 0 {
            if ((MEDPatientValidations.isValidTextForTroponin(self.troponin_TextField.text!) == false) || (Double(self.troponin_TextField.text!) < 0.0) || (Double(self.troponin_TextField.text!) > 1000.0)) {
                self.troponin_Border.backgroundColor = ColorPicker.textFieldHighlightedColor()
                isValid = false
            }
            else{
                self.troponin_Border.backgroundColor = ColorPicker.warmGreyColor()
            }
        }
        else{
            self.troponin_Border.backgroundColor = ColorPicker.warmGreyColor()
        }
        return isValid
    }
    // MARK: - Keyboard Notification Handling
    override func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.CGRectValue() {
            UIView.animateWithDuration(0.25, animations: { () -> Void in
                let contentInset = UIEdgeInsetsMake(0, 0, keyboardSize.height-41, 0)
                self.scrollView.contentInset = contentInset
                self.scrollView.scrollIndicatorInsets = contentInset
            })
        }
    }
    override func keyboardWillHide(notification: NSNotification) {
        UIView.animateWithDuration(0.25, animations: { () -> Void in
            self.scrollView.contentInset = UIEdgeInsetsZero
        })
    }
    
    // MARK: - TextField Delegates
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        textField.inputAccessoryView = self.inputToolbar
        self.updateKeyboardToolbar(textField)
        return true
    }
    func textFieldDidBeginEditing(textField: UITextField){
        currentTextFieldTag = textField.tag
        self.currentTextField = textField
    }
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool{
        var shouldAllowEditing = true
        let parentController = self.parentViewController as! BasePatientHistoryViewController
        parentController.isClinicalExaminationDataChanged = true
        if textField.tag == 100 {
            if string == ""{
                shouldAllowEditing = true
                return shouldAllowEditing
            }
            else if (string == " " && textField.text!.characters.count == 0){
                return false
            }
            else{
                if Double(textField.text!.characters.count) >= MAXIMUM_ALLOWED_CHARACTERS_FOR_DESCRIPTION  {
                    shouldAllowEditing = false
                }
            }
        }
        if textField.tag == 110 {
            if string == ""{
                shouldAllowEditing = true
                return shouldAllowEditing
            }
            else if (string == "0" && textField.text!.characters.count == 0){
                return false
            }
            else{
                if Double(textField.text!.characters.count) >= MAXIMUM_ALLOWED_CHARACTERS_FOR_SYSTOLIC  {
                    shouldAllowEditing = false
                }
            }
        }
        if textField.tag == 111 {
            if string == ""{
                shouldAllowEditing = true
                return shouldAllowEditing
            }
            else if (string == "0" && textField.text!.characters.count == 0){
                return false
            }
            else{
                if Double(textField.text!.characters.count) >= MAXIMUM_ALLOWED_CHARACTERS_FOR_DIASTOLIC  {
                    shouldAllowEditing = false
                }
            }
        }
        if textField.tag == 112 {
            if string == ""{
                shouldAllowEditing = true
                return shouldAllowEditing
            }
            else if (string == "0" && textField.text!.characters.count == 0){
                return false
            }
            else{
                if Double(textField.text!.characters.count) >= MAXIMUM_ALLOWED_CHARACTERS_FOR_PULSE  {
                    shouldAllowEditing = false
                }
            }
        }
        if textField.tag == 113 {
            if string == ""{
                shouldAllowEditing = true
                return shouldAllowEditing
            }
            else if (string == "0" && textField.text!.characters.count == 0){
                return false
            }
            else{
                if Double(textField.text!.characters.count) >= MAXIMUM_ALLOWED_CHARACTERS_FOR_TEMPERATURE  {
                    shouldAllowEditing = false
                }
            }
        }
        if textField.tag == 114 {
            if string == ""{
                shouldAllowEditing = true
                return shouldAllowEditing
            }
            else if (string == "0" && textField.text!.characters.count == 0){
                return false
            }
            else{
                if Double(textField.text!.characters.count) >= MAXIMUM_ALLOWED_CHARACTERS_FOR_SPO2  {
                    shouldAllowEditing = false
                }
            }
        }
        if textField.tag == 115 {
            if string == ""{
                shouldAllowEditing = true
                return shouldAllowEditing
            }
            else{
                if Double(textField.text!.characters.count) >= MAXIMUM_ALLOWED_CHARACTERS_FOR_ESTIMATED_WEIGHT  {
                    shouldAllowEditing = false
                }
            }
        }
        if textField.tag == 116 {
            if string == ""{
                shouldAllowEditing = true
                return shouldAllowEditing
            }
            else{
                if Double(textField.text!.characters.count) >= MAXIMUM_ALLOWED_CHARACTERS_FOR_TROPONIN  {
                    shouldAllowEditing = false
                }
            }
        }
        return shouldAllowEditing
    }
}
// MARK:- ALERT VIEW DELEGATES
extension ClinicalExaminationViewController:AlertViewControllerProtocol {
    func cancelButtonAction(alertController: UIAlertController) {
        
    }
    func OKButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
    func defaultButtonAction(alertController: UIAlertController) {
        // Single button alert view presented
        // Handle action on button action
        if(authorizationAlert == true){
            self.navigateToHome()
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }
        else{
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }
    }
}
// MARK: - Picker Delegates
extension ClinicalExaminationViewController: pickerViewProtocol {
    //Picker View delegates
    func datePickerDoneButtonTapped(selectedTime: String!, selectedDate: String!) {
        let parentController = self.parentViewController as! BasePatientHistoryViewController
        parentController.isClinicalExaminationDataChanged = true
        if(pickerViewtag == 1110) {
            self.LastEpisode_TextField.text = selectedDate+" "+selectedTime
        }
    }
    func pickerViewDoneButtonTapped( selectedString: String!, index: Int) {
        let parentController = self.parentViewController as! BasePatientHistoryViewController
        parentController.isClinicalExaminationDataChanged = true
          var localSelectedString = selectedString
        switch self.pickerViewIdentifierString.rawValue {
        case PickerViewIdentifiers.ComplaintType.rawValue:
            if (selectedString == "" && index == self.initialIndex) {
                localSelectedString = self.complaintTypeArray[initialIndex] as! String
            }
            if(localSelectedString == "None") {
                //self.paymentTypeButtonLabel.text = "None"
            }
            else if localSelectedString != "" {
                self.complaintTypeLabel.text = localSelectedString
                dynamicHandlingForPAtientComplaint(localSelectedString)
            }
        default:
            return
        }
    }
    func dynamicHandlingForPAtientComplaint(localSelectedString:String)
    {
        self.view.setNeedsUpdateConstraints()
        self.view.setNeedsLayout()
        self.lastEpisodeAndDescription_BorderView.backgroundColor = ColorPicker.warmGreyColor()
                if localSelectedString == self.complaintTypeArray[0] as! String {
            self.primaryComplaintId = 0
            lastEpisodeLabel.hidden = false
            lastEpisodeLabel.text = "Last Episode"
            LastEpisode_TextField.hidden = false
            lastEpisode_TransparentButton.hidden = false
            lastEpisodeDateTimeLogo.hidden = false
            if self.lastEpisodeTime != nil{
                if self.lastEpisodeTime?.length != 0 {
                    LastEpisode_TextField.text = self.lastEpisodeTime as? String
                }
            }
            description_TextField.hidden = true
            LastEpisodeView.hidden = false
            complaintTypeViewHeight.constant = 144
            contentViewHeight.constant = 723
        }
        else if localSelectedString == self.complaintTypeArray[1] as! String {
            self.primaryComplaintId = 1
            lastEpisodeLabel.hidden = true
            LastEpisodeView.hidden = true
            complaintTypeViewHeight.constant = 81
            contentViewHeight.constant = 660
        }
        else if localSelectedString == self.complaintTypeArray[2] as! String {
            self.primaryComplaintId = 2
            lastEpisodeLabel.hidden = false
            LastEpisodeView.hidden = false
            lastEpisode_TransparentButton.hidden = true
            LastEpisode_TextField.hidden = true
            lastEpisodeDateTimeLogo.hidden = true
            description_TextField.hidden = false
            if self.presentingComplaintDescription != nil{
                if self.presentingComplaintDescription?.length != 0 {
                    description_TextField.text = self.presentingComplaintDescription as? String
                }
            }
            lastEpisodeLabel.text = "Description"
            complaintTypeViewHeight.constant = 144
            contentViewHeight.constant = 723
        }
            self.view.layoutIfNeeded()
    }
}