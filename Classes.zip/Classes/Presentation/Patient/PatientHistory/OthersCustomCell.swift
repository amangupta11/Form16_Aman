//
//  OthersCustomCell.swift
//  Medtronic
//
//  Created by Praveen Ambekar on 5/8/17.
//  Copyright © 2017 Medtronic. All rights reserved.
//

import UIKit

class OthersCustomCell: UITableViewCell {

    @IBOutlet weak var othersTextView: UITextView!
    @IBOutlet weak var checkMarkBtn: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    override func layoutSubviews() {
        let shadowPath = UIBezierPath(rect: bounds)
        self.layer.masksToBounds = false
        self.layer.shadowColor = UIColor.grayColor().CGColor
        self.layer.shadowOffset = CGSizeMake(0.0, 2.0)
        self.layer.shadowOpacity = 0.1
        self.layer.shadowRadius = 0.2
        self.layer.shadowPath = shadowPath.CGPath
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.whiteColor().CGColor
    }
}
