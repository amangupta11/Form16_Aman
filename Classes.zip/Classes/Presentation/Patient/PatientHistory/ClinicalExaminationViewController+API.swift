//  ClinicalExaminationViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
// MARK: -  Server Interaction
extension ClinicalExaminationViewController {

func getPatientClinicalExamination() {
    checkInternet()
    APIRequest.sharedAPI.getClinicalExamination(Patient.sharedInfo.patientInfo!, completion: { (jsonString, successful, error, response) in
        dispatch_async(dispatch_get_main_queue(), {
            ActivityIndicatorView.sharedActivityView.hideOverlayView()
            if successful {
                self.updateUI()
            } else {
                super.handleError(error)
                
            }
        })
    })
}
    func setPatientClinicalExamination() {
        checkInternet()
        APIRequest.sharedAPI.saveClinicalExamination(self.clinicalExaminationDetailsDict!, completion: { (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    
                    let parentController = self.parentViewController as! BasePatientHistoryViewController
                    parentController.isClinicalExaminationDataChanged = false

                    self.showSimpleAlert("Success", message: "Information saved successfully")
                } else {
                    if(response?.statusCode == 403){
                        self.authorizationAlert = true
                        self.showUnauthorizationAlert()
                    }else{
                    super.handleError(error)
                    }
                }
            })
        })
    }

}