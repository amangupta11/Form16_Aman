//  AddCaptionViewController.swift
//  Copyright © 2017 Medtronic. All rights reserved.

import UIKit

class AddCaptionViewController: MEDCameraLauncher {

    @IBOutlet weak var captionViewHeightConstraint: NSLayoutConstraint?
    @IBOutlet weak var captionLabel: UILabel?
    @IBOutlet weak var captionTextView: UITextView?
    @IBOutlet weak var scrollView: UIScrollView?
    @IBOutlet weak var checkMarkButtonOutlet: UIButton?
    @IBOutlet weak var imageView: UIImageView?
    var ecgImage: UIImage!
    var scrollOffset: CGPoint!
    var imageInfo : [String : AnyObject] = [:]
    
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
    }
    override func viewDidAppear(animated: Bool) {
        super.addKeyboardObserver(self)
        super.viewDidAppear(animated)
    }
    override func viewDidDisappear(animated: Bool) {
        super.removeKeyBoardObserver(self)
        super.viewDidDisappear(animated)
    }
    
    
    // MARK: - @IBAction Methods
    
    @IBAction func camerButtonAction(sender: AnyObject) {
        self.cameraButtonTapped()
    }
    @IBAction func checkMarkButtonAction(sender: AnyObject) {
        let vc = self.navigationController?.viewControllers[(self.navigationController?.viewControllers.count)!-2] as! BasePatientHistoryViewController
        let medicalHisVC = vc.childViewControllers[0] as! MedicalHistoryViewController
        medicalHisVC.info = self.imageInfo
        medicalHisVC.caption = self.captionTextView?.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        medicalHisVC.imageAdded = true
        medicalHisVC.imageClickedTime = String(DateUtility.getCurrentTimeInGMT())
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    
    
    // MARK: - Custom Methods
        func initialSetUp() {
        self.setTapGestureForView()
        setNavigationBackButtonImage()
        self.navigationController?.navigationBar.barTintColor = UIColor.blackColor()
        setImageToImageView()
    }
    // Setting tap gesture
    func setTapGestureForView() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:) ))
        self.view.addGestureRecognizer(tapGesture)
    }
    func handleTap(sender: UIView) {
        view.endEditing(true)
        self.captionViewHeightConstraint?.constant = 34
        if(self.captionTextView?.text.isEmpty == false){
         self.captionTextView?.layer.cornerRadius = 13
         self.captionViewHeightConstraint?.constant = 45
        }
    }
    func cameraButtonTapped() {
        self.presentCamera()
    }
    func setImageToImageView(){
        self.imageView?.image = self.ecgImage
    }
    override func backButtonAction(button: UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK: - Keyboard Notification Handling
    override func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.CGRectValue() {
            UIView.animateWithDuration(0.25, animations: { () -> Void in
                self.view.frame.origin.y = -keyboardSize.height+70
            })
        }
    }
    override func keyboardWillHide(notification: NSNotification) {
        UIView.animateWithDuration(0.25, animations: { () -> Void in
            self.view.frame.origin.y = 70
        })
    }
}

//MARK:- Text view delegates
extension AddCaptionViewController: UITextViewDelegate {
    
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        return true
        
    }
    func textViewDidBeginEditing(textView: UITextView) {
        self.captionLabel?.hidden = true
        textView.autocorrectionType = UITextAutocorrectionType.No
        textView.autocapitalizationType = UITextAutocapitalizationType.Sentences
    }
    func textViewDidEndEditing(textView: UITextView) {
        if textView.text == ""{
            self.captionLabel?.hidden = false
        }
    }
    
    func textViewDidChange(textView: UITextView) {
    }
    func adjustFrames(){
        self.captionViewHeightConstraint?.constant = (self.captionTextView?.contentSize.height)!
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        let charSet =  NSCharacterSet.newlineCharacterSet()
        let updatedString = (textView.text as NSString?)?.stringByReplacingCharactersInRange(range, withString: text)
        // checking if typed character is new line character
        // Return false if yes
        if (text == "\n") {
            self.captionViewHeightConstraint?.constant = 34
            if(self.captionTextView?.text.isEmpty == false){
            self.captionTextView?.layer.cornerRadius = 13
            self.captionViewHeightConstraint?.constant = 45
            }
            textView.resignFirstResponder()
            return false
        }
        if let _ = updatedString!.rangeOfCharacterFromSet(charSet) {
            return false
        }
        
        if updatedString?.characters.count > 140 {
            return false
        } else if ((updatedString?.characters.count) > 0 && updatedString![(updatedString?.startIndex.advancedBy(0))!] == " ") {
            return false
        }
        self.adjustFrames()
        return true
    }
}


//MARK:- Image picker delegates
extension AddCaptionViewController {
    override  func imagePickerController(
        picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        // image is getting changed
        let image = (info[UIImagePickerControllerOriginalImage] as? UIImage)
        let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        appDelegate?.isCameraOpen = false
        imagePicker! .dismissViewControllerAnimated(true, completion: nil)
        self.ecgImage = image
        self.imageInfo = info
        setImageToImageView()
    }
    override func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        appDelegate?.isCameraOpen = false
        imagePicker!.dismissViewControllerAnimated(true, completion: nil)
    }
}


