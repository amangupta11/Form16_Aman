//  MHImageSourceInfo.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation

class MHImageSourceInfo : NSObject {
    
    var imageURL = String()
    var localPath = String()
    var fileName = String()
    var caption = String()
    var time = String()
    var transferType:MHImageTransferType
    var imageCaptured:UIImage?
    var downloadError:Bool = false
    
    init(url: String?, typeOfTransfer: MHImageTransferType) {
        
        if url != nil {
            
            self.imageURL = url!
        
        }
        
        self.transferType = typeOfTransfer;
        
    }
    
}