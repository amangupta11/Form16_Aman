//  MHUploadImageCell.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation

class MHUploadImageCell: UICollectionViewCell {
    
    @IBOutlet weak var cameraIconTopConstraint: NSLayoutConstraint?
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var captureIcon: UIImageView!
    

}