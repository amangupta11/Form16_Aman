//  MedicalHistoryViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
// MARK: -  Server Interaction
extension MedicalHistoryViewController {
    
    func getPatientMedicalHistory() {
        checkInternet()
        APIRequest.sharedAPI.getMedicalHistory(Patient.sharedInfo.patientInfo!) { (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {

                } else {
                    super.handleError(error)
                }
            })
        }
    }
    func setPatientMedicalHistory(requestDict: NSMutableDictionary?) {
        checkInternet()
        APIRequest.sharedAPI.saveMedicalHistory(requestDict!, completion: { (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    
                    let parentController = self.parentViewController as! BasePatientHistoryViewController
                    parentController.isMedicalHistoryDataChanged = false
                    self.showSimpleAlert(MedicalHisConstants.SuccessAlertTitle , message: MedicalHisConstants.SuccessAlertMsg)
                } else {
                    if(response?.statusCode == 403){
                        self.authorizationAlert = true
                        self.showUnauthorizationAlert()
                    }else{
                    super.handleError(error)
                    }
                }
            })
        })
    }
    func getAWSBucketInformation(captureCount:Int) {
        checkInternet()
        APIRequest.sharedAPI.getAWSBucketInfo(patientInfo: "", completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    CustomAWSCredentialProvider.sharedInstance.updateAWSInfo(jsonString!)
                    self.uploadNewImages(captureCount)
                } else {
                    super.handleError(error)
                }
            })
        })
    }
    func getAWSBucketInformationToDownloadImage() {
        checkInternet()
        APIRequest.sharedAPI.getAWSBucketInfo(patientInfo: "", completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    CustomAWSCredentialProvider.sharedInstance.updateAWSInfo(jsonString!)
                    self.downloadMedicalHistoryImage()
                } else {
                    super.handleError(error)
                }
            })
        })
    }
    
    func uploadImage (patientInfo: PatientCaseInfo, imageURL: NSURL, s3UploadKeyName: String, completed: (success: Bool, error: NSError?) -> Void) {
        
        checkInternet()
        AWSTransferManager.sharedTransferManager.uploadImageRequest(imageURL, s3UploadKeyName: s3UploadKeyName, completion: {
            (jsonString, successful, error, response) in
            
            completed (success: successful, error:error)
            
        })
        
    }

}