//  MethodsViewController.swift
//  Copyright © 2017 Medtronic. All rights reserved.

import UIKit

class MethodsViewController: MEDBaseViewController {

    enum cellIdentifierConstants: String{
        case ConditionCellIdentifier = "ConditionCell"
        case StepperCellIdentifier = "StepperCell"
        case OthersCellIdentifier = "othersCell"
    }
    
    private var defaultCellRowHt:CGFloat = 40.0
    private var defaultFooterHt:CGFloat = 7.0
    private var defaultHeaderHt:CGFloat = 30.0
    private var defaultScrollViewContainerViewHeight = 750
    
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var medicationTV: UITableView!
    @IBOutlet weak var headerLbl: UILabel!
    @IBOutlet weak var methodTVHt: NSLayoutConstraint!
    @IBOutlet weak var contentViewHt: NSLayoutConstraint!
    @IBOutlet weak var condtionScrollView: UIScrollView!
    @IBOutlet weak var methodsTV: UITableView!
    
    
    var medicalHistoryDataDict:NSMutableDictionary?
    var dataArr = [AnyObject]()
    var isFromMedication:Bool?
    var doseArrIndex:Int?
    var commentsTV = UITextView()
    var isTextViewMarkedRed = false
    var isMedicalHistoryDataChanged = false
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        invalidateTimer()
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillHideNotification, object: nil)
    }
    override func viewWillAppear(animated: Bool) {
        if Patient.sharedInfo.patientInfo != nil {
            startTimer()
        }
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.keyboardWillShow(_:)), name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.keyboardWillHide(_:)), name: UIKeyboardWillHideNotification, object: nil)
    }
    func initialSetUp(){
        self.setNavigationBackButtonImage()
        self.getDataArray()
    }
    func getDataArray(){
        
        if self.isFromMedication == true
        {
            self.dataArr = self.medicalHistoryDataDict![StringConstants.PatientMedications] as! Array
            self.headerLbl.text = NSLocalizedString("MEDICATION", comment: "")
        }
        else{
            self.dataArr = self.medicalHistoryDataDict![StringConstants.MedicalHistoryConditions] as! Array
            self.headerLbl.text = NSLocalizedString("CONDITIONS", comment: "")
        }
    }
    override func viewDidLayoutSubviews() {
       
        self.methodTVHt.constant = (CGFloat(dataArr.count) * self.defaultCellRowHt) + (defaultFooterHt * CGFloat(dataArr.count)) + 130
        self.contentViewHt.constant = self.defaultHeaderHt + self.methodTVHt.constant + 10
//        self.condtionScrollView.contentSize.height = self.contentViewHt.constant
        super.viewDidLayoutSubviews()

    }
    
    override func setNavigationBackButtonImage() {
        let image = UIImage(named: ButtonTitles.BackIcon)
        let backButton = UIButton(type: UIButtonType.Custom)
        backButton.addTarget(self, action: #selector(backButtonAction), forControlEvents: UIControlEvents.TouchUpInside)
        backButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: -30, bottom: 0, right: -10)
        backButton.setImage(image, forState: UIControlState.Normal)
        backButton.sizeToFit()
        let backButtonItem = UIBarButtonItem(customView: backButton)
        self.navigationItem.leftBarButtonItem = backButtonItem
    }
    
    override func backButtonAction(button: UIButton) {
        self.navigateToMedicalHistory()
    }
    
    func updateDataSource(sender: UIButton, isStepperSelected: Bool) {
        let selectedConditon = self.dataArr[sender.tag]
        if isFromMedication == true && isStepperSelected == true{
            let indexPath = NSIndexPath(forRow: 0, inSection: sender.tag)
            let cell = self.medicationTV.cellForRowAtIndexPath(indexPath) as! StepperCell
            selectedConditon.setValue(cell.checkMarkBtn.selected, forKey: StringConstants.isChecked)
            selectedConditon.setValue(self.doseArrIndex, forKey: StringConstants.SelectedDosage)
        }
        else{
            selectedConditon.setValue(sender.selected, forKey: StringConstants.isChecked)
        }
    }
    
    func updateDataSourceForOthers(sender: UIButton) {
        let selectedConditon = self.dataArr[sender.tag]
        selectedConditon.setValue(sender.selected, forKey: StringConstants.isChecked)
        if !sender.selected{
        isTextViewMarkedRed = false
        self.handleTextViewUI(self.commentsTV)
        selectedConditon.setValue("", forKey: StringConstants.MedicineDescription)
        }
    }
    
    func checkMarkButtonTapped(sender: UIButton!, isOthersRowSelected: Bool) {
        switch sender.selected {
        case false:
            sender.selected = true
            
        case true:
            sender.selected = false
        }
        if isOthersRowSelected{
            self.updateDataSourceForOthers(sender)
        }
        else{
            self.updateDataSource(sender, isStepperSelected: false)
        }
    }
    
    func othersRowSelected(sender: UIButton!) {
        switch sender.selected {
        case false:
            sender.selected = true
        case true:
            sender.selected = false
        }
        self.updateDataSourceForOthers(sender)
    }
 
    func handleStepperCell(cell : StepperCell, index : Int)
    {
        let conditionDict = self.dataArr[index]
        let medicineDoseArr = conditionDict[StringConstants.MedicineDose] as! [AnyObject]
        if doseArrIndex == medicineDoseArr.count - 1{
            cell.stepUpBtn.enabled = false
        }
        else{
            cell.stepUpBtn.enabled = true
//            if !cell.stepUpBtn.enabled{
//            UIView.animateWithDuration(0.3, animations: {
//                cell.stepUpBtn.transform = CGAffineTransformMakeScale(1.5, 1.5)
//                }, completion: {
//                    (value: Bool) in
//                    cell.stepUpBtn.transform = CGAffineTransformIdentity
//                    cell.stepUpBtn.enabled = true
//            })
//            }
        }
        if doseArrIndex == self.dataArr.startIndex{
            cell.stepdownBtn.enabled = false
        }
        else{
            cell.stepdownBtn.enabled = true
//             if !cell.stepdownBtn.enabled{
//            UIView.animateWithDuration(0.3, animations: {
//                cell.stepdownBtn.transform = CGAffineTransformMakeScale(1.5, 1.5)
//                }, completion: {
//                    (value: Bool) in
//                    cell.stepdownBtn.transform = CGAffineTransformIdentity
//                    cell.stepdownBtn.enabled = true
//            })
 //       }
        }
    }
    func descriptionLblTapped(sender: UIButton!) {
            let indexPath = NSIndexPath(forRow: 0, inSection: sender.tag)
            let cell = self.medicationTV.cellForRowAtIndexPath(indexPath) as! StepperCell
            switch cell.checkMarkBtn.selected {
            case false:
                cell.checkMarkBtn.selected = true
                self.handleStepperCell(cell, index: sender.tag)
                case true:
                cell.checkMarkBtn.selected = false
                cell.stepUpBtn.enabled = false
                cell.stepdownBtn.enabled = false
        }
        self.updateDataSource(sender, isStepperSelected: true)
    }
    func navigateToMedicalHistory(){
        if isFromMedication! == true{
            let dict = self.dataArr[dataArr.count-1]
            if dict[StringConstants.isChecked] as! Bool == true && self.commentsTV.text.utf16.count == 0{
                isTextViewMarkedRed = true
                self.handleTextViewUI(self.commentsTV)
                return
            }
            else if dict[StringConstants.isChecked] as! Bool == true && self.commentsTV.text.utf16.count > 0{
                let commentStr =  self.commentsTV.text.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
                dict.setValue(commentStr, forKey: StringConstants.MedicineDescription)
                }
                isTextViewMarkedRed = false
                self.handleTextViewUI(self.commentsTV)
        }
        let vc = self.navigationController?.viewControllers[(self.navigationController?.viewControllers.count)!-2] as! BasePatientHistoryViewController
            vc.view.layoutIfNeeded()
              let medicalHisVC = vc.childViewControllers[0] as! MedicalHistoryViewController
              medicalHisVC.dataArray = self.dataArr
              medicalHisVC.arrangeDataArray = true
              medicalHisVC.isMedicalHistoryDataChanged = self.isMedicalHistoryDataChanged
            self.navigationController?.popViewControllerAnimated(true)
            return
        }
}
    // MARK: - tableView Delegate methods
    extension MethodsViewController: UITableViewDelegate {
        func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
            let view = UIView()
            view.backgroundColor = UIColor.clearColor()
            return view
        }
         func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
            return UIView()
        }
         func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
            return 7
        }
         func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
            return 0
        }
         func numberOfSectionsInTableView(tableView: UITableView) -> Int {
            return self.dataArr.count
        }
         func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return 1
        }
         func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
            let dict = dataArr[indexPath.section] as! [String : AnyObject]
            if self.isFromMedication == true{
                if indexPath.section == dataArr.count - 1{
                    if dict[StringConstants.isChecked]?.boolValue == true{
                        return 128
                    }
                    return defaultCellRowHt
                    
                }
            }
            return defaultCellRowHt
        }
        
         func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
            if isFromMedication == false{
                isMedicalHistoryDataChanged = true
                let cell = tableView.cellForRowAtIndexPath(indexPath) as! ConditionsTVCell
                self.checkMarkButtonTapped(cell.checkMarkButton, isOthersRowSelected: false)
            }
            else{
                isMedicalHistoryDataChanged = true
                if indexPath.section == dataArr.count - 1{
                    let cell = tableView.cellForRowAtIndexPath(indexPath) as! OthersCustomCell
                    cell.checkMarkBtn.tag = indexPath.section
                    self.checkMarkButtonTapped(cell.checkMarkBtn, isOthersRowSelected: true)
                    self.methodsTV.reloadData()
                   return
                }
                let dict = dataArr[indexPath.section] as! [String : AnyObject]
                let medicineDoseArr = dict[StringConstants.MedicineDose] as! [AnyObject]
                if medicineDoseArr.count <= 0{
                    let cell = tableView.cellForRowAtIndexPath(indexPath) as! ConditionsTVCell
                    self.checkMarkButtonTapped(cell.checkMarkButton, isOthersRowSelected: false)
                }
            }
    }
}
    
    // MARK: - TableView Datasourse method
    extension  MethodsViewController:UITableViewDataSource {
        func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
            tableView.separatorStyle = UITableViewCellSeparatorStyle.None
            let cell:UITableViewCell?
            if self.isFromMedication == true{
                if indexPath.section == dataArr.count - 1
                {
                    cell = self.otherCommentCustomCell(tableView, cellForRowAtIndexPath: indexPath)
                }
                else{
                    let dict = dataArr[indexPath.section] as! [String : AnyObject]
                    let medicineDoseArr = dict[StringConstants.MedicineDose] as! [AnyObject]
                    if medicineDoseArr.count > 0{
                        cell = self.getMedicationCustomCell(tableView, cellForRowAtIndexPath: indexPath)
                    }
                    else{
                        cell = self.getConditionCustomCell(tableView, cellForRowAtIndexPath: indexPath)
                    }
                }
            }
            else{
                cell = self.getConditionCustomCell(tableView, cellForRowAtIndexPath: indexPath)
            }
            return cell!
        }
        func otherCommentCustomCell(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
        {
            let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifierConstants.OthersCellIdentifier.rawValue, forIndexPath: indexPath) as! OthersCustomCell
            cell.othersTextView.layer.borderWidth = 1
            self.commentsTV = cell.othersTextView
            self.handleTextViewUI(self.commentsTV)
            let conditionDict = self.dataArr[indexPath.section]
            if conditionDict.valueForKey(StringConstants.isChecked)?.boolValue == true{
                cell.checkMarkBtn.selected = true
            }else{
                cell.checkMarkBtn.selected = false
            }
            let medDesStr = conditionDict[StringConstants.MedicineDescription] as! String
            if conditionDict[StringConstants.isChecked] as! Bool == true && (medDesStr.caseInsensitiveCompare("other") != NSComparisonResult.OrderedSame){
                cell.othersTextView.text = medDesStr
            }
            return cell
        }
        func getConditionCustomCell(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
        {
            let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifierConstants.ConditionCellIdentifier.rawValue, forIndexPath: indexPath) as! ConditionsTVCell
            cell.checkMarkButton.selected = true
            cell.checkMarkButton.tag = indexPath.section
            let conditionDict = self.dataArr[indexPath.section]
             if self.isFromMedication == true{
                cell.medicalConditionLabel.text = conditionDict.valueForKey(StringConstants.MedicineDescription) as? String
            }
             else{
                cell.medicalConditionLabel.text = conditionDict.valueForKey("value") as? String
            }
            if conditionDict.valueForKey(StringConstants.isChecked)?.boolValue == true{
                cell.checkMarkButton.selected = true
            }else{
                cell.checkMarkButton.selected = false
            }
            return cell
        }
        func getMedicationCustomCell(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
        {
            var cell : StepperCell!
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifierConstants.StepperCellIdentifier.rawValue, forIndexPath: indexPath) as! StepperCell
            cell.checkMarkBtn.tag = indexPath.section
            let conditionDict = self.dataArr[indexPath.section]
            cell.descriptionLbl.setTitle(conditionDict.valueForKey(StringConstants.MedicineDescription) as? String, forState: UIControlState.Normal)
            cell.descriptionLbl.contentHorizontalAlignment = UIControlContentHorizontalAlignment.Left
            if conditionDict.valueForKey(StringConstants.isChecked)?.boolValue == true{
                cell.checkMarkBtn.selected = true
                cell.stepUpBtn.enabled = true
                cell.stepdownBtn.enabled = true

            }else{
                cell.checkMarkBtn.selected = false
                cell.stepUpBtn.enabled = false
                cell.stepdownBtn.enabled = false
            }
            cell.stepUpBtn.tag = indexPath.section
            cell.stepUpBtn.addTarget(self, action:#selector(incrementBtnClicked(_:)), forControlEvents: UIControlEvents.TouchUpInside)
            cell.stepdownBtn.tag = indexPath.section
            cell.stepdownBtn.addTarget(self, action:#selector(decrementBtnClicked(_:)), forControlEvents: UIControlEvents.TouchUpInside)
            
            
            cell.checkMarkBtn.tag = indexPath.section
            cell.checkMarkBtn.addTarget(self, action:#selector(descriptionLblTapped(_:)), forControlEvents: UIControlEvents.TouchUpInside)
            
            
            cell.descriptionLbl.tag = indexPath.section
            cell.descriptionLbl.addTarget(self, action:#selector(descriptionLblTapped(_:)), forControlEvents: UIControlEvents.TouchUpInside)
            
            let medicineDoseArr = conditionDict[StringConstants.MedicineDose] as! [AnyObject]
            self.doseArrIndex =  (conditionDict[StringConstants.SelectedDosage]) as? Int
            cell.dosageLbl.text = medicineDoseArr[self.doseArrIndex!] as? String
            
           return cell
        }
        func incrementBtnClicked(sender :UIButton ) {
            let indexPath = NSIndexPath(forRow: 0, inSection: sender.tag)
            let cell = self.medicationTV.cellForRowAtIndexPath(indexPath) as! StepperCell
            let conditionDict = self.dataArr[sender.tag]
            let medicineDoseArr = conditionDict[StringConstants.MedicineDose] as! [AnyObject]
            if self.doseArrIndex < medicineDoseArr.count - 1{
                 self.doseArrIndex = self.doseArrIndex! + 1
            cell.dosageLbl.text = (medicineDoseArr[self.doseArrIndex!] as! String)
            }
            conditionDict.setValue(self.doseArrIndex, forKey: StringConstants.SelectedDosage)
            self.handleStepperCell(cell, index: sender.tag)
        }
        
        func decrementBtnClicked(sender :UIButton ) {
            let indexPath = NSIndexPath(forRow: 0, inSection: sender.tag)
            let cell = self.medicationTV.cellForRowAtIndexPath(indexPath) as! StepperCell
            let conditionDict = self.dataArr[sender.tag]
            let medicineDoseArr = conditionDict[StringConstants.MedicineDose] as! [AnyObject]
            if self.doseArrIndex > 0 && self.doseArrIndex < medicineDoseArr.count{
            self.doseArrIndex = self.doseArrIndex! - 1
            cell.dosageLbl.text = (medicineDoseArr[self.doseArrIndex!] as! String)
            }
            conditionDict.setValue(self.doseArrIndex, forKey: StringConstants.SelectedDosage)
            self.handleStepperCell(cell, index: sender.tag)
        }
        
        func handleTextViewUI(textView: UITextView) {
            if self.isTextViewMarkedRed == false {
                self.normalizeOtherCommentsTextView(textView)
            } else {
                self.highlightOtherCommentsTextView(textView)
            }
        }
        func highlightOtherCommentsTextView(textView: UITextView) {
            self.commentsTV.layer.borderColor = UIColor.redColor().CGColor
        }
        func normalizeOtherCommentsTextView(textView: UITextView) {
            self.commentsTV.layer.borderColor = ColorPicker.lightBlueGray2().CGColor
        }
        // MARK: - Keyboard Notification Handling
        override func keyboardWillShow(notification: NSNotification) {
            
            if let keyboardSize = (notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.CGRectValue() {
                UIView.animateWithDuration(0.25, animations: { () -> Void in
                    let contentInset = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
                    self.condtionScrollView.scrollEnabled = true
                    self.condtionScrollView.contentInset = contentInset
                    self.condtionScrollView.scrollIndicatorInsets = contentInset
                    let indexPath = NSIndexPath(forRow: 0, inSection: self.dataArr.count - 1)
                    let commentCell = self.methodsTV.cellForRowAtIndexPath(indexPath) as! OthersCustomCell
                    self.condtionScrollView.scrollRectToVisible(commentCell.frame, animated: true)
                })
            }
            
        }
        override func keyboardWillHide(notification: NSNotification) {
            UIView.animateWithDuration(0.25, animations: { () -> Void in
                self.condtionScrollView.contentInset = UIEdgeInsetsZero
            })
        }
}
extension MethodsViewController: UITextViewDelegate {
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        self.commentsTV = textView
        textView.inputAccessoryView = self.inputToolbar
        self.updateKeyboardToolbar(textView)
        return true
    }
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        isMedicalHistoryDataChanged = true
        if(text == "\n") {
            textView.becomeFirstResponder()
            return true
        }
        let updatedString = (textView.text as NSString?)?.stringByReplacingCharactersInRange(range, withString: text)
        if (updatedString?.characters.count)! > 139 {
            return false
        }
        else if ((updatedString?.characters.count) > 0 && updatedString![(updatedString?.startIndex.advancedBy(0))!] == " ") {
            return false
        }
        return true
    }
}
@IBDesignable class MEDPaddingLbl: UILabel {
    override func drawTextInRect(rect: CGRect) {
        let insets = UIEdgeInsets(top: 0, left: 10.0, bottom: 0, right: 0)
        super.drawTextInRect(UIEdgeInsetsInsetRect(rect, insets))
    }
}