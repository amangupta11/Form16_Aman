//  MEDStopTreatmentCustomCell.swift
//  Copyright © 2017 Medtronic. All rights reserved.

import UIKit

class MEDStopTreatmentCustomCell: UITableViewCell {

    @IBOutlet weak var trtCheckMarkIV: UIImageView!
    @IBOutlet weak var trtReasonLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

}
