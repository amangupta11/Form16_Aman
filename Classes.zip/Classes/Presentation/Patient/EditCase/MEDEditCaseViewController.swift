//  MEDEditCaseViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import Firebase
enum PickerViewIdentifiers: String {
    case PaymentType = "paymentType"
    case CountryName = "countryName"
    case CountryCode = "CountryCode"
    case ComplaintType = "complaintType"
}
class MEDEditCaseViewController: MEDBaseViewController {
    @IBOutlet var citizenshipButtonLabel: UILabel!
    @IBOutlet var triageTimeEditedTextLabel: UILabel!
    @IBOutlet var triageTimeMaxAttemptLabel: UILabel!
    @IBOutlet var triageTimerImage: UIButton!
    @IBOutlet var triageDateButton: MEDBorderedButton!
    @IBOutlet var onsetTimeEditedTextLabel: UILabel!
    @IBOutlet var onsetTimeMaxAttemptLabel: UILabel!
    @IBOutlet var onsetTimerImage: UIButton!
    @IBOutlet var onsetDateButton: MEDBorderedButton!
    @IBOutlet var middleNameTF: MEDBorderedTextField!
    @IBOutlet var doorInTimeTimerImage: UIButton!
    @IBOutlet var doorInTimeEditedTextLabel: UILabel!
    @IBOutlet var doorInTimeMaxAttemptLabel: UILabel!
    @IBOutlet var icNumORPassportTF: MEDBorderedTextField!
    @IBOutlet var citizenshipButtonOutlet: MEDBorderedButton!
    @IBOutlet weak var countryCodeLabel: UILabel!
    @IBOutlet weak var paymentTypeButtonLabel: UILabel!
    @IBOutlet weak var femaleButtonOutlet: UIButton!
    @IBOutlet weak var maleButtonOutlet: UIButton!
    @IBOutlet weak var caseIDLable: UILabel!
    @IBOutlet weak var paymentTypeButton: UIButton!
    @IBOutlet weak var phoneNumberTF: MEDBorderedTextField!
    @IBOutlet weak var firstNameTF: MEDBorderedTextField!
    @IBOutlet weak var lastNameTF: MEDBorderedTextField!
    @IBOutlet weak var ageTextTF: MEDBorderedTextField!
    @IBOutlet weak var paymentTypeTextField: MEDBorderedTextField!
    @IBOutlet weak var doorInDateButton: MEDBorderedButton!
    @IBOutlet weak var phoneNumberExtensionButton: MEDBorderedButton!
    @IBOutlet var editCaseScrollView: UIScrollView!
    @IBOutlet var viewHeightConstraint: NSLayoutConstraint!
    var pickerContainerDelegate: MEDPickerContainerDelegate!
    var pickerContainerView: UIView!
    var pickerView: UIPickerView!
    var pickerViewtag: Int!
    var activeTextField: MEDBorderedTextField!
    var dataSourceArray = NSArray()
    var pickerViewIdentifierString: PickerViewIdentifiers!
    var paymentTypeArray: NSArray!
    var citizenshipTypeArray: NSArray!
    var countryCodesArray: NSMutableArray!
    var countryCodesAndNamesArray: NSMutableArray!
    var countryNamesArray: NSMutableArray!
    var cameFromViewSummary: Bool = false
    var authorizationAlert:Bool = false
    static var defaultPaymentType = "None"
    struct EditPatientInfoConstants {
        static  var AlertTitle = NSLocalizedString("ATTENTION", comment: "")
        static  var AlertMessage = NSLocalizedString("THERE_HAS_BEEN_AN_UPDATE_ON_THIS_CASE", comment: "")
    }
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp("")
        //        patientInfo?.countryCode = "+60"
    }
    override func viewDidAppear(animated: Bool) {
        super.addKeyboardObserver(self)
        super.viewDidAppear(animated)
    }
    override func viewDidDisappear(animated: Bool) {
        super.removeKeyBoardObserver(self)
        super.viewDidDisappear(animated)
    }
    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
        super.viewWillDisappear(animated)
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        if Patient.sharedInfo.patientInfo != nil {
            startTimer()
       }
        updateUI()
        FIRAnalytics.setScreenName(FireBaseConstants.editInfo, screenClass: FireBaseConstants.editInfo)
    }
}
// MARK: - @IBAction Actions
extension MEDEditCaseViewController {
    
    @IBAction func fmcDoorInDateButtonAction(sender: AnyObject) {
        addPickerForFmcDoorIn(sender.tag)
    }
    @IBAction func onsetDateAction(sender: AnyObject) {
        addPickerForOnsetDate(sender.tag)
    }
    @IBAction func triageDateAction(sender: AnyObject) {
        addPickerForTriageDate(sender.tag)
    }
    @IBAction func doorInDateButtonAction(sender: AnyObject) {
        addPickerForFmcDoorIn(sender.tag)
    }
    @IBAction func onsetDateButtonAction(sender: AnyObject) {
        addPickerForOnsetDate(sender.tag)
    }
    @IBAction func triageDateButtonAction(sender: AnyObject) {
        addPickerForTriageDate(sender.tag)
    }
    @IBAction func citizenshipButtonAction(sender: AnyObject) {
        self.view.endEditing(true)
        var selectedIndex: Int = 0
        if self.citizenshipButtonLabel.text?.characters.count > 0 {
            for i in 0..<self.citizenshipTypeArray.count {
                if self.citizenshipButtonLabel.text! == self.citizenshipTypeArray[i] as? String {
                    selectedIndex = i
                    break
                }
            }
        }
        self.initializePickerContainerView()
        self.pickerContainerDelegate.index = selectedIndex
        self.pickerContainerView =
            self.pickerContainerDelegate.customPickerView(self.citizenshipTypeArray)
        self.makeTransparentScreenColor()
        self.pickerViewIdentifierString = PickerViewIdentifiers.CountryName
        if(self.citizenshipButtonLabel.text == nil || self.citizenshipButtonLabel.text == "") {
            self.pickerContainerDelegate.pickerView.selectRow(self.citizenshipTypeArray.indexOfObject(MEDPatientGeneralInfoViewController.defaultCountryName), inComponent: 0, animated: true)

        } else {
            self.pickerContainerDelegate.pickerView.selectRow(self.citizenshipTypeArray.indexOfObject(self.citizenshipButtonLabel.text!), inComponent: 0, animated: true)
        }
        self.addPickerContainerView()
    }
    @IBAction func paymentTypeButtonAction(sender: AnyObject) {
        self.view.endEditing(true)
        var selectedIndex: Int = 0
        if self.paymentTypeButtonLabel.text?.characters.count > 0 {
            for i in 0..<self.paymentTypeArray.count {
                if self.paymentTypeButtonLabel.text! == self.paymentTypeArray[i] as? String {
                    selectedIndex = i
                    break
                }
            }
        }
        self.initializePickerContainerView()
        self.pickerContainerDelegate.index = selectedIndex
        self.pickerContainerView =
            self.pickerContainerDelegate.customPickerView(self.paymentTypeArray)
        self.makeTransparentScreenColor()
        self.pickerViewIdentifierString = PickerViewIdentifiers.PaymentType
        if(self.paymentTypeButtonLabel.text == nil || self.paymentTypeButtonLabel.text == "") {
            self.pickerContainerDelegate.pickerView.selectRow(self.paymentTypeArray.indexOfObject(MEDEditCaseViewController.defaultPaymentType), inComponent: 0, animated: true)
        } else {
            self.pickerContainerDelegate.pickerView.selectRow(self.paymentTypeArray.indexOfObject(self.paymentTypeButtonLabel.text!), inComponent: 0, animated: true)
        }
        self.addPickerContainerView()
    }
    @IBAction func countryCodeButtonAction(sender: AnyObject) {
        self.view.endEditing(true)
        var selectedIndex: Int = 0
        if self.countryCodeLabel.text?.characters.count > 0 {
            for i in 0..<self.countryCodesArray.count {
                if self.countryCodeLabel.text == self.countryCodesArray[i] as? String {
                    selectedIndex = i
                    break
                }
            }
        }
        self.initializePickerContainerView()
        self.pickerContainerDelegate.index = selectedIndex
        self.pickerContainerView = self.pickerContainerDelegate.customPickerView(self.countryCodesAndNamesArray)
        self.makeTransparentScreenColor()
        self.pickerViewIdentifierString = PickerViewIdentifiers.CountryCode
        self.pickerContainerDelegate.pickerView.selectRow(selectedIndex, inComponent: 0, animated: true)
        self.addPickerContainerView()
    }
    @IBAction func saveButtonAction(sender: AnyObject) {
        // Validate the Fields
        self.normalizeTheLabelsColor()
        self.view.endEditing(true)
        let isValid = self.validateFields()
        if isValid == true {
            Patient.sharedInfo.patientInfo?.firstName = self.firstNameTF.text!.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
            Patient.sharedInfo.patientInfo?.lastName = self.lastNameTF.text!.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
            Patient.sharedInfo.patientInfo?.middleName = self.middleNameTF.text!.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
            Patient.sharedInfo.patientInfo?.icNoOrPassport = self.icNumORPassportTF.text
            Patient.sharedInfo.patientInfo?.age = self.ageTextTF.text
            Patient.sharedInfo.patientInfo?.mobileNumber = self.phoneNumberTF.text
            convertAllTimesFromStringToDate()
            Patient.sharedInfo.patientInfo?.countryCode = self.countryCodeLabel.text
            if(self.citizenshipButtonLabel.text?.isEmpty == false) {
                Patient.sharedInfo.patientInfo?.citizenship = self.citizenshipButtonLabel.text
            }
            if(self.paymentTypeButtonLabel.text?.isEmpty == false) {
               Patient.sharedInfo.patientInfo?.paymentType = self.paymentTypeButtonLabel.text
            }
            performEditCaseGeneralInfo()
        }
    }
    @IBAction func genderButtonAction(sender: AnyObject) {
        let buttonTag = sender.tag
        switch buttonTag {
        case GenderButtonTag.Male.rawValue:
            self.maleButtonOutlet.selected = true
            Patient.sharedInfo.patientInfo?.gender = "1"
            self.femaleButtonOutlet.selected = !self.maleButtonOutlet.selected
        case GenderButtonTag.Female.rawValue:
            self.femaleButtonOutlet.selected = true
            Patient.sharedInfo.patientInfo?.gender = "0"
            self.maleButtonOutlet.selected = !self.femaleButtonOutlet.selected
        default: break

        }
    }
}

// MARK: - Picker Delegates
extension MEDEditCaseViewController: pickerViewProtocol {
    //Picker View delegates
    func datePickerDoneButtonTapped(selectedTime: String!, selectedDate: String!) {
        if(pickerViewtag == 0) {
            self.doorInDateButton.setTitle(selectedDate+" "+selectedTime, forState: .Normal)
        } else if(pickerViewtag == 1) {
            self.onsetDateButton.setTitle(selectedDate+" "+selectedTime, forState: .Normal)
        } else if (pickerViewtag == 2) {
            self.triageDateButton.setTitle(selectedDate+" "+selectedTime, forState: .Normal)
        }
    }
    func pickerViewDoneButtonTapped(selectedString: String!, index: Int) {
        switch self.pickerViewIdentifierString.rawValue {
        case PickerViewIdentifiers.PaymentType.rawValue:
            if(selectedString == "None") {
                self.paymentTypeButtonLabel.text = "None"
            }
            if selectedString != "" {
                self.paymentTypeButtonLabel.text = selectedString
                Patient.sharedInfo.patientInfo?.paymentTypeID = String(index)
                Patient.sharedInfo.patientInfo?.paymentType = self.paymentTypeButtonLabel.text
            } else if selectedString == "" && (self.paymentTypeButtonLabel.text == nil || self.paymentTypeButtonLabel.text == "") {
                self.paymentTypeButtonLabel.text = MEDEditCaseViewController.defaultPaymentType
                let payTypeID = self.paymentTypeArray.indexOfObject(MEDEditCaseViewController.defaultPaymentType)
                Patient.sharedInfo.patientInfo?.paymentTypeID = String(payTypeID)
            }
        case PickerViewIdentifiers.CountryName.rawValue:
            if selectedString != "" {
                self.citizenshipButtonLabel.text = selectedString
                Patient.sharedInfo.patientInfo?.citizenshipTypeID = String(index)
                Patient.sharedInfo.patientInfo?.citizenship = self.citizenshipButtonLabel.text
            } else if selectedString == "" && (self.citizenshipButtonLabel.text == nil || self.citizenshipButtonLabel.text == "") {
                self.citizenshipButtonLabel.text = MEDPatientGeneralInfoViewController.defaultCountryName
                let citizenShipType = self.citizenshipTypeArray.indexOfObject(MEDPatientGeneralInfoViewController.defaultCountryName)
                Patient.sharedInfo.patientInfo?.citizenshipTypeID = String(citizenShipType)
            }
        case PickerViewIdentifiers.CountryCode.rawValue:
            if selectedString != "" {
                self.countryCodeLabel.text = self.countryCodesArray[index] as? String
            }
        default:
            return
        }
    }
}
// MARK: - Custom Actions
extension MEDEditCaseViewController {
    override func initialSetUp(bgImage: String) {
        startTimer()
        self.loadPaymentTypeAndCountryCodes()
        //setScrollViewContainerViewHeight()
        self.setTapGestureForView()
        setNavigationBackButtonImage()
    }
    
    func addPickerForFmcDoorIn(tag:Int){
        self.view.endEditing(true)
        initializePickerContainerView()
        self.pickerContainerView = self.pickerContainerDelegate.datePickerView()
        pickerViewtag = tag
        var date: NSDate
        if Patient.sharedInfo.patientInfo?.timeLine?.addNewCaseTime != nil {
            date = NSDate(timeIntervalSince1970: (Patient.sharedInfo.patientInfo?.timeLine?.addNewCaseTime)!)} else {
            date = NSDate(timeIntervalSince1970: (Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInTime)!)
        }
        self.pickerContainerDelegate.datePicker.maximumDate = date
        self.pickerContainerDelegate.datePicker.minimumDate = date.dateByAddingTimeInterval(-3600*4)
        self.makeTransparentScreenColor()
        self.addPickerContainerView()
    }
    func addPickerForOnsetDate(tag:Int){
        self.view.endEditing(true)
        initializePickerContainerView()
        self.pickerContainerView = self.pickerContainerDelegate.datePickerView()
        pickerViewtag = tag
        var date: NSDate
        date = NSDate(timeIntervalSince1970: DateUtility.getCurrentTimeInGMT())
        self.pickerContainerDelegate.datePicker.maximumDate = date
        self.makeTransparentScreenColor()
        self.addPickerContainerView()
    }
    func addPickerForTriageDate(tag:Int){
        self.view.endEditing(true)
        initializePickerContainerView()
        self.pickerContainerView = self.pickerContainerDelegate.datePickerView()
        pickerViewtag = tag
        var date: NSDate
        date = NSDate(timeIntervalSince1970: DateUtility.getCurrentTimeInGMT())
        self.pickerContainerDelegate.datePicker.maximumDate = date
        self.makeTransparentScreenColor()
        self.addPickerContainerView()

    }
    func showUnauthorizationAlert() {
        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        alertView = alertController.showSimpleAlert(EditPatientInfoConstants.AlertTitle, message:EditPatientInfoConstants.AlertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)
    }
    
    func navigateToHome() {
        if self.navigationController?.viewControllers.first is MEDHomeViewController
        {
            let topViewController = self.navigationController?.viewControllers.first as! MEDHomeViewController
            topViewController.shouldTableViewRefresh = true
        }
        //DataOperation.sharedDataOperation.deleteManagedObject(patientInfo!)
        self.navigationController?.popToRootViewControllerAnimated(true)
    }

    
     func convertAllTimesFromStringToDate() {
        self.saveFMCDoorInTime()
        self.saveonSetTime()
        self.saveTriageTime()
    }
    func saveFMCDoorInTime(){
        let count = Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInEditCount
        if count != nil{
            let numberFromString = Int(count!)
            if numberFromString < 3 {
                if self.doorInDateButton.titleLabel?.text != nil {
                    let dateString = String(format: "%@", (self.doorInDateButton.titleLabel?.text)!)
                    Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInTime = DateUtility.convertStringToDate(dateString)
                }
            }
        }
        else{
            if self.doorInDateButton.titleLabel?.text != nil {
                let dateString = String(format: "%@", (self.doorInDateButton.titleLabel?.text)!)
                Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInTime = DateUtility.convertStringToDate(dateString)
            }
        }
    }

    func saveonSetTime(){
        let onsetCount = Patient.sharedInfo.patientInfo?.timeLine?.onsetEditCount
        if onsetCount != nil{
        let onsetNumberFromString = Int(onsetCount!)
        if onsetNumberFromString < 3 {
            if self.onsetDateButton.titleLabel?.text != nil {
                let dateString = String(format: "%@", (self.onsetDateButton.titleLabel?.text)!)
                Patient.sharedInfo.patientInfo?.timeLine?.onSetTime = DateUtility.convertStringToDate(dateString)
            }
        }
        }
        else{
            if self.onsetDateButton.titleLabel?.text != nil {
                let dateString = String(format: "%@", (self.onsetDateButton.titleLabel?.text)!)
                Patient.sharedInfo.patientInfo?.timeLine?.onSetTime = DateUtility.convertStringToDate(dateString)
            }
        }
    }
    func saveTriageTime(){
        let triageCount = Patient.sharedInfo.patientInfo?.timeLine?.triageEditCount
        if triageCount != nil{
            let triageNumberFromString = Int(triageCount!)
            if triageNumberFromString < 3 {
                if self.triageDateButton.titleLabel?.text != nil {
                    let dateString = String(format: "%@", (self.triageDateButton.titleLabel?.text)!)
                    Patient.sharedInfo.patientInfo?.timeLine?.triageTime = DateUtility.convertStringToDate(dateString)
                }
            }
        }
        else{
            if self.triageDateButton.titleLabel?.text != nil {
                let dateString = String(format: "%@", (self.triageDateButton.titleLabel?.text)!)
                Patient.sharedInfo.patientInfo?.timeLine?.triageTime = DateUtility.convertStringToDate(dateString)
            }
        }
    }
    func makeTransparentScreenColor() {
        self.pickerContainerView.backgroundColor = ColorPicker.transparentScreenBackgroundColor()
    }
    //TODO : Use this commom func
    func addPickerContainerView() {
        let window = UIApplication.sharedApplication().delegate?.window
        window!!.addSubview(self.pickerContainerView)
    }
    func initializePickerContainerView() {
        self.pickerContainerDelegate = MEDPickerContainerDelegate(frame: self.navigationController!.view.frame)
        self.pickerContainerDelegate.delegate = self
    }
    func updateUI() {
        if(Patient.sharedInfo.patientInfo?.hospitalCaseID != nil) {
            caseIDLable.text = Patient.sharedInfo.patientInfo?.hospitalCaseID
        } else {
            caseIDLable.text = Patient.sharedInfo.patientInfo?.caseID
        }
        firstNameTF.text                 = Patient.sharedInfo.patientInfo?.firstName
        middleNameTF.text                = Patient.sharedInfo.patientInfo?.middleName
        lastNameTF.text                  = Patient.sharedInfo.patientInfo?.lastName
        ageTextTF.text                   = Patient.sharedInfo.patientInfo?.age
        self.paymentTypeButtonLabel.text = Patient.sharedInfo.patientInfo?.paymentType
        self.citizenshipButtonLabel.text =  Patient.sharedInfo.patientInfo?.citizenship
        self.icNumORPassportTF.text      = Patient.sharedInfo.patientInfo?.icNoOrPassport
        self.countryCodeLabel.text       = (Patient.sharedInfo.patientInfo?.countryCode != nil && Patient.sharedInfo.patientInfo?.countryCode != "") ? Patient.sharedInfo.patientInfo?.countryCode : "+60"
        phoneNumberTF.text = Patient.sharedInfo.patientInfo?.mobileNumber
        if(Patient.sharedInfo.patientInfo?.gender == "1") {
            self.maleButtonOutlet.selected = true
            self.femaleButtonOutlet.selected = false
        } else { self.femaleButtonOutlet.selected = true
            self.maleButtonOutlet.selected = false
        }
        updateFmcDoorInTime()
        updateOnsetTime()
        updateTriageTime()
    }
    func updateFmcDoorInTime() {
        let fmcDoorInTimeStr  = Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInTime
        if fmcDoorInTimeStr != nil{
        let string  = Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInEditedText
        if string != nil {
            let attributeString: NSMutableAttributedString =  NSMutableAttributedString(string:  string! )
            attributeString.addAttribute(NSStrikethroughStyleAttributeName, value: 2, range: NSMakeRange(0, attributeString.length))
            doorInTimeTimerImage.hidden = false
            self.doorInDateButton.userInteractionEnabled = true
            doorInTimeEditedTextLabel.attributedText = attributeString
        }

        self.doorInTimeMaxAttemptLabel.text =  ButtonTitles.attemptRemainingString
        if((Patient.sharedInfo.patientInfo?.caseStatus != statusKey.New.rawValue) && (Patient.sharedInfo.patientInfo?.caseStatus != statusKey.Undiagnosed.rawValue) && (Patient.sharedInfo.patientInfo?.caseStatus != statusKey.STEMI.rawValue) || Int((Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInEditCount)!) == 3){
            self.doorInTimeTimerImage.hidden = true
            self.doorInDateButton.userInteractionEnabled = false
            self.doorInTimeMaxAttemptLabel.hidden = true
            self.doorInDateButton.setTitleColor(ColorPicker.ligthGrey(), forState: .Normal)
            self.doorInDateButton.titleLabel?.textColor = ColorPicker.ligthGrey()
        }
        else{
            self.doorInTimeMaxAttemptLabel.text =  "\(3 - Int((Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInEditCount)!)!)" + ButtonTitles.attemptsRemainingString
        }

        let fmcDoorInTime = Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInTime
        let doorInTimeString = DateUtility.convertGMTtoTime(fmcDoorInTime!)
        let fmcDoorInDate = Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInTime
        let doorInDateString = DateUtility.convertGMTtoShortDate(fmcDoorInDate!)
        if(Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInTime != nil && Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInTime != 0) {
            self.doorInDateButton.setTitle(doorInDateString+" "+doorInTimeString, forState: .Normal)}
        }
    }
    func updateOnsetTime() {
        let onSetTimeStr  = Patient.sharedInfo.patientInfo?.timeLine?.onSetTime
        if onSetTimeStr != nil {
        let string  = Patient.sharedInfo.patientInfo?.timeLine?.onsetEditedText
            if string != nil {
            let attributeString: NSMutableAttributedString =  NSMutableAttributedString(string:  string! )
            attributeString.addAttribute(NSStrikethroughStyleAttributeName, value: 2, range: NSMakeRange(0, attributeString.length))
                print(attributeString)
            onsetTimerImage.hidden = false
            self.onsetDateButton.userInteractionEnabled = true
            onsetTimeEditedTextLabel.attributedText = attributeString
        }
        self.onsetTimeMaxAttemptLabel.text =  ButtonTitles.attemptRemainingString
        if Int((Patient.sharedInfo.patientInfo?.timeLine?.onsetEditCount)!) == 3 {
            self.onsetTimerImage.hidden = true
            self.onsetTimeMaxAttemptLabel.hidden = true
            self.onsetDateButton.userInteractionEnabled = false
            self.onsetDateButton.setTitleColor(ColorPicker.ligthGrey(), forState: .Normal)
            self.onsetDateButton.titleLabel?.textColor = ColorPicker.ligthGrey()
        }
        else{
            self.onsetTimeMaxAttemptLabel.text =  "\(3 - Int((Patient.sharedInfo.patientInfo?.timeLine?.onsetEditCount)!)!)" + ButtonTitles.attemptsRemainingString
        }

        let onsetTime = Patient.sharedInfo.patientInfo?.timeLine?.onSetTime
        let onsetTimeString = DateUtility.convertGMTtoTime(onsetTime!)
        let onsetDate = Patient.sharedInfo.patientInfo?.timeLine?.onSetTime
        let onsetDateString = DateUtility.convertGMTtoShortDate(onsetDate!)
        if(Patient.sharedInfo.patientInfo?.timeLine?.onSetTime != nil && Patient.sharedInfo.patientInfo?.timeLine?.onSetTime != 0) {
            self.onsetDateButton.setTitle(onsetDateString+" "+onsetTimeString, forState: .Normal)}
        }
    }

    func updateTriageTime() {
        let triageTimeStr  = Patient.sharedInfo.patientInfo?.timeLine?.triageTime
        if triageTimeStr != nil{
        
        
        let string  = Patient.sharedInfo.patientInfo?.timeLine?.triageEditedText
            if string != nil {
            let attributeString: NSMutableAttributedString =  NSMutableAttributedString(string:  string! )
            attributeString.addAttribute(NSStrikethroughStyleAttributeName, value: 2, range: NSMakeRange(0, attributeString.length))
            triageTimerImage.hidden = false
            self.triageDateButton.userInteractionEnabled = true
            triageTimeEditedTextLabel.attributedText = attributeString
        }
        let triageTime = Patient.sharedInfo.patientInfo?.timeLine?.triageTime
        let triageTimeString = DateUtility.convertGMTtoTime(triageTime!)
        let triageDate = Patient.sharedInfo.patientInfo?.timeLine?.triageTime
        let triageDateString = DateUtility.convertGMTtoShortDate(triageDate!)
        if(Patient.sharedInfo.patientInfo?.timeLine?.triageTime != nil && Patient.sharedInfo.patientInfo?.timeLine?.triageTime != 0) {
            self.triageDateButton.setTitle(triageDateString+" "+triageTimeString, forState: .Normal)}
        }
       // self.triageTimeMaxAttemptLabel.text =  ButtonTitles.attemptRemainingString
        if Int((Patient.sharedInfo.patientInfo?.timeLine?.triageEditCount)!) == 3 {
            self.triageTimerImage.hidden = true
            self.triageTimeMaxAttemptLabel.hidden = true
            self.triageDateButton.userInteractionEnabled = false
            self.triageDateButton.setTitleColor(ColorPicker.ligthGrey(), forState: .Normal)
            self.triageDateButton.titleLabel?.textColor = ColorPicker.ligthGrey()
        }
        else{
            self.triageTimeMaxAttemptLabel.text =  "\(3 - Int((Patient.sharedInfo.patientInfo?.timeLine?.triageEditCount)!)!)" + ButtonTitles.attemptsRemainingString
        }
    }
    override func backButtonAction(button: UIButton) {
        FIRAnalytics.logEventWithName(FireBaseEvents.editInfoToSummary, parameters:nil)
        if(cameFromViewSummary == true) {
            self.performSegueWithIdentifier(SegueIdentifierConstants.EditCaseToViewSummarySegueIdentifier, sender: nil)
        } else {
            if let viewControllers = navigationController?.viewControllers {
                var i = 0
                for viewController in viewControllers {
                    i += 1
                    if viewController.isKindOfClass( MEDViewSummaryViewController) {
                        self.navigationController?.popViewControllerAnimated(true)
                        return
                    }
                }
                //DataOperation.sharedDataOperation.deleteManagedObject(patientInfo!)
                self.navigationController?.popToRootViewControllerAnimated(true)
            }
        }
    }
    func normalizeTheLabelsColor() {
        self.firstNameTF.customBorder.borderColor = ColorPicker.warmGreyColor().CGColor
        self.lastNameTF.customBorder.borderColor = ColorPicker.warmGreyColor().CGColor
        self.doorInDateButton.customBorder.borderColor = ColorPicker.warmGreyColor().CGColor
        self.phoneNumberTF.customBorder.borderColor = ColorPicker.warmGreyColor().CGColor
        self.phoneNumberExtensionButton.customBorder.borderColor = ColorPicker.warmGreyColor().CGColor
        self.ageTextTF.customBorder.borderColor = ColorPicker.warmGreyColor().CGColor
    }
    func loadPaymentTypeAndCountryCodes() {
        let metaDataPList: NSDictionary!
        if let path = FileUtility.getPlistPath() {
            metaDataPList = NSDictionary(contentsOfFile: path)
            self.citizenshipTypeArray = self.setCountryNames((metaDataPList.objectForKey("CountryCodes") as? NSArray)!)
            self.paymentTypeArray = metaDataPList.objectForKey("PaymentType") as? NSArray
            self.setCountryCodes((metaDataPList.objectForKey("CountryCodes") as? NSArray)!)
        }
    }
    func setCountryNames(countryCodeArray: NSArray) -> NSMutableArray {
        self.countryNamesArray = NSMutableArray()
        for i in 0..<countryCodeArray.count {
            let dict = countryCodeArray[i] as! NSMutableDictionary
            let countryName =    dict.objectForKey("CountryName") as! String
            countryNamesArray.addObject(countryName)
        }
        self.countryNamesArray.insertObject("None", atIndex: 0)
        return self.countryNamesArray
    }

    func setCountryCodes(countryCodeArray: NSArray) {
        self.countryCodesAndNamesArray = NSMutableArray()
        self.countryCodesArray = NSMutableArray()
        for i in 0..<countryCodeArray.count {
            let dict = countryCodeArray[i] as! NSMutableDictionary
            let countryName =    dict.objectForKey("CountryName") as! String
            let countryCode =    dict.objectForKey("CountryCode") as! String
            let countryCodeWithName = countryName.stringByAppendingString(" (").stringByAppendingString(countryCode).stringByAppendingString(")")
            self.countryCodesAndNamesArray.addObject(countryCodeWithName)
            self.countryCodesArray.addObject(countryCode as String)
        }
    }
    func performNavigation() {
        cameFromViewSummary = true
        if let viewControllers = navigationController?.viewControllers {
            var count = 0
            for viewController in viewControllers {
                count += 1
                if viewController.isKindOfClass( MEDViewSummaryViewController) {
                    self.navigationController?.popViewControllerAnimated(true)
                    return
                }
            }
            pushAddNewCaseToViewSummaryController(count, viewControllers: viewControllers)
        }
    }
    func changeStatusOfDoorInTimeButton(count: String) {
        let numberFromString = Int(count)
        if numberFromString > 3 {
            disableDoorInTimeButon()
        } else {
            enableDoorInTimeButon()
        }
    }
    func disableDoorInTimeButon() {
        self.doorInDateButton.enabled = false
        self.doorInDateButton.setTitleColor(ColorPicker.ligthGrey(), forState: .Normal)
    }

    func enableDoorInTimeButon() {
        self.doorInDateButton.enabled = true
        self.doorInDateButton.setTitleColor(ColorPicker.lightBlackColor(), forState: .Normal)
    }

    // Setting tap gesture
    func setTapGestureForView() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:) ))
        self.view.addGestureRecognizer(tapGesture)
    }
    func handleTap(sender: UIView) {
        view.endEditing(true)
    }
    // MARK: - Segue Methods
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        self.hidesBottomBarWhenPushed = false
        for viewController in (self.navigationController?.viewControllers)! {
            viewController.hidesBottomBarWhenPushed = false
        }
        let vc = segue.destinationViewController as! MEDViewSummaryViewController
        vc.hidesBottomBarWhenPushed = false
        //vc.patientInfo = patientInfo
    }
    func pushAddNewCaseToViewSummaryController(count: Int, viewControllers: [UIViewController]) {
        if(count == viewControllers.count) {
            self.performSegueWithIdentifier(SegueIdentifierConstants.EditCaseToViewSummarySegueIdentifier, sender: nil)
        }
    }
}
//MARK: - Keyboard Notification Handling
extension MEDEditCaseViewController {

    override func keyboardWillHide(notification: NSNotification) {
        UIView.animateWithDuration(0.25, animations: { () -> Void in
            self.editCaseScrollView.contentInset = UIEdgeInsetsZero
            self.view.frame.origin.y = 64
        })
    }
    override func keyboardWillShow(notification: NSNotification) {
        if self.activeTextField == self.firstNameTF || self.activeTextField == self.icNumORPassportTF || self.activeTextField == self.middleNameTF {
            return}
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.CGRectValue() {
            UIView.animateWithDuration(0.25, animations: { () -> Void in
                let contentInset = UIEdgeInsetsMake(0, 0, keyboardSize.height-50, 0)
                self.editCaseScrollView.contentInset = contentInset
                self.editCaseScrollView.scrollIndicatorInsets = contentInset
            })
        }
    }
}
// MARK: - UITextFieldDelegate
extension MEDEditCaseViewController: UITextFieldDelegate {
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        textField.inputAccessoryView = self.inputToolbar
        updateKeyboardToolbar(textField)
        return true
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        currentTextFieldTag = textField.tag
        if textField == self.firstNameTF || textField == self.lastNameTF  || textField == self.middleNameTF {
            textField.autocorrectionType = UITextAutocorrectionType.No
            textField.autocapitalizationType = UITextAutocapitalizationType.Sentences
        }
        self.activeTextField = textField as! MEDBorderedTextField
    }
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        let customTextField = textField as! MEDBorderedTextField
        let updatedString = (customTextField.text as NSString?)?.stringByReplacingCharactersInRange(range, withString: string)
        if customTextField == self.firstNameTF || customTextField == self.lastNameTF  || customTextField == self.middleNameTF {
            if MEDPatientValidations.validateFirstORLastName(updatedString!) == false {
                return false}
            if (customTextField.text == "" && updatedString == " " ) {
                return false
            }
        } else if customTextField == self.ageTextTF {
            if updatedString! == "" {
                return true
            }
            if MEDPatientValidations.isValidAge(updatedString!) == false {
                return false
            }}
        if customTextField == self.icNumORPassportTF {
            if MEDPatientValidations.isValidPassportORIc(updatedString!) == false {
                return false
            }} else if customTextField == self.phoneNumberTF {
            if updatedString?.characters.count > 10 {
                return false}
        }
        return true}
}
// MARK: - Validations
extension MEDEditCaseViewController {
    func validateFields() -> Bool {
        // Validate fields
        var isValid = true
        // Checking invalid details
        if self.firstNameTF.text?.characters.count == 0 {
            self.firstNameTF.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
            isValid = false
        }
        if self.lastNameTF.text?.characters.count == 0 {
            self.lastNameTF.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
            isValid = false
        }
        if MEDPatientValidations.validateFirstORLastName(self.firstNameTF.text!) == false {
            self.firstNameTF.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
            isValid = false
        }
        if MEDPatientValidations.validateFirstORLastName(self.lastNameTF.text!) == false {
            self.lastNameTF.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
            isValid = false
        }
        if self.phoneNumberTF.text?.characters.count > 0 {
            if self.countryCodeLabel.text?.characters.count == nil {
                self.phoneNumberTF.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
                self.phoneNumberExtensionButton.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
                isValid = false
            } else if MEDPatientValidations.isValidPhoneNumber(self.phoneNumberTF.text!) == false {
                self.phoneNumberTF.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
                self.phoneNumberExtensionButton.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
                isValid = false
            }
        }
        if self.doorInDateButton.titleLabel?.text == nil {
            self.doorInDateButton.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
            isValid = false
        }
        if self.ageTextTF.text?.characters.count == 0||(self.ageTextTF.text! as NSString).integerValue > 110 {
            self.ageTextTF.customBorder.borderColor = ColorPicker.textFieldHighlightedColor().CGColor
            isValid = false
        }
        return isValid
    }
}
//MARK: - Alert view delegates
extension MEDEditCaseViewController: AlertViewControllerProtocol {
    func cancelButtonAction(alertController: UIAlertController) {
    }
    func OKButtonAction(alertController: UIAlertController) {
    }
    func defaultButtonAction(alertController: UIAlertController) {
        if (authorizationAlert == true){
            navigateToHome()
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }
        else{
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }
    }
}
