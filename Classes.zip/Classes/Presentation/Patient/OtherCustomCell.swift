//  OtherCustomCell.swift
//  Copyright © 2017 Medtronic. All rights reserved.

import UIKit

class OtherCustomCell: UITableViewCell {

    @IBOutlet weak var checkMarkIV: UIImageView!
    @IBOutlet weak var otherLbl: UILabel!
    @IBOutlet weak var commentsTV: UITextView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
