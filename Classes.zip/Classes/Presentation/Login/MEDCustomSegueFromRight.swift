// MEDCustomSegueFromRight.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

class MEDCustomSegueFromRight: UIStoryboardSegue {
    override func perform() {
        let src = self.sourceViewController
        let dst = self.destinationViewController

        dst.view.transform = CGAffineTransformMakeTranslation(2*src.view.frame.size.width, 0)
        UIView.animateWithDuration(0.25,
                                   delay: 0.0,
                                   options: UIViewAnimationOptions.CurveEaseInOut,
                                   animations: {
                                    dst.view.transform = CGAffineTransformMakeTranslation(0, 0)
            },
                                   completion: { finished in
                                    src.presentViewController(dst, animated: false, completion: nil)
            }
        )
    }

}
