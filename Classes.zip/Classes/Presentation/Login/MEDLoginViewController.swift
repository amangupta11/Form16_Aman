//  MEDLoginViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import Firebase
class MEDLoginViewController: MEDBaseViewController,AlertViewControllerProtocol{
    @IBOutlet var userEmailTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    @IBOutlet var loginButton: UIButton!
    @IBOutlet var userEmailCrossButton: UIButton!
    @IBOutlet var passswordCrossButton: UIButton!
    @IBOutlet var passwordLineLabel: UILabel!
    @IBOutlet var userEmailLineLabel: UILabel!
    var alertView: UIAlertController?
    var isPasswordEntered: Bool = false
    var updateURL:String?
    var currentAlertViewTag: loginAlertTags!
    enum LineLabelColor {
        case selected
        case unSelected
        var color: UIColor {
            switch self {
            case .selected: return UIColor(red: 113/255, green: 197/255, blue: 232/255, alpha: 1)
            case .unSelected: return UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
            }
        }
    }
    enum textfieldTag: Int {
        case usernameTextFld = 100
        case passwordTxtFld = 101
    }
    enum loginAlertTags: Int {
        case criticalupdate = 10
    }
    // MARK: - UIView Life Cycle Method
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        initialSetUp(LoginStringConstants.logInBackgroundImage)
    }
    override func viewDidAppear(animated: Bool) {
        super.addKeyboardObserver(self)
        super.viewDidAppear(animated)
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.clearTextField(self.passwordTextField, hidden:true)
        self.clearTextField(self.userEmailTextField, hidden:true)
        FIRAnalytics.setScreenName(FireBaseConstants.login, screenClass: FireBaseConstants.login)
    }
    override func viewDidDisappear(animated: Bool) {
        super.removeKeyBoardObserver(self)
        super.viewDidDisappear(animated)
    }
}
// MARK: - UITextFieldDelegate
extension MEDLoginViewController: UITextFieldDelegate {
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        textField.inputAccessoryView = self.inputToolbar
        self.updateKeyboardToolbar(textField)
        return true
    }
    func textFieldDidBeginEditing(textField: UITextField) {
        currentTextFieldTag = textField.tag
        setTextFieldLineLabelColor(textField, lineColor:LineLabelColor.selected.color )
        if((textField.text?.isEmpty)==false) {
            setCrossButtonHidden(textField, hidden: false)
        } else {
            setCrossButtonHidden(textField, hidden: true)
        }
    }
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        let nextTage=textField.tag+1
        let nextResponder=textField.superview?.viewWithTag(nextTage) as UIResponder!
        if (nextResponder != nil) {
            nextResponder?.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        return false
    }
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        let updatedString = (textField.text as NSString?)?.stringByReplacingCharactersInRange(range, withString: string)
        switch textField.tag {
        case textfieldTag.usernameTextFld.rawValue:
            if((updatedString!.isEmpty)==false) && (updatedString != " ") {
                setCrossButtonHidden(textField, hidden: false)
                logInButtonEnabeld()
            } else {
                setCrossButtonHidden(textField, hidden: true)
                logInButtonEnabeldWithClearTextField(false)
            }
        case textfieldTag.passwordTxtFld.rawValue:
            if((updatedString!.isEmpty)==false) && (updatedString != " "){
                updatePasswordTextFieldString(textField)
            } else {
                setCrossButtonHidden(textField, hidden: true)
                logInButtonEnabeldWithClearTextField(false)
            }
        default:
            break
        }
        if (string == " ") {
            return false
        }
        setTextFieldLineLabelColor(textField, lineColor:LineLabelColor.selected.color )
        return (textField.text?.utf16.count ?? 0) + string.utf16.count - range.length <= 15
    }
    func textFieldDidEndEditing(textField: UITextField) {
        if(textField.tag == textfieldTag.passwordTxtFld.rawValue && (textField.text?.isEmpty)==false) {
            isPasswordEntered = true
        }
        if((textField.text?.isEmpty)!) {
            setTextFieldLineLabelColor(textField, lineColor:LineLabelColor.unSelected.color )
            setCrossButtonHidden(textField, hidden: true)
        }
        logInButtonEnabeld()
    }
    func textFieldShouldEndEditing(textField: UITextField) -> Bool {
        setTextFieldLineLabelColor(textField, lineColor:LineLabelColor.unSelected.color )
        setCrossButtonHidden(textField, hidden: true)
        return true
    }
}
// MARK: - Custom Actions
extension MEDLoginViewController {
    override func initialSetUp(bgImage: String) {
        super.setBackgroundImageToView(bgImage)
        setTapGestureForView()
        hideCrossButton(true)
    }
    private func clearTextField(textField: UITextField, hidden: Bool) {
        textField.text = nil
        logInButtonEnabeld()
        setTextFieldLineLabelColor(textField, lineColor:LineLabelColor.unSelected.color )
        setCrossButtonHidden(textField, hidden: hidden)
    }
    func setTapGestureForView() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:) ))
        self.view.addGestureRecognizer(tapGesture)
    }
    func handleTap(sender: UIView) {
        view.endEditing(true)
    }
    func hideCrossButton(hidden: Bool) {
        userEmailCrossButton.hidden = hidden
        passswordCrossButton.hidden = hidden
    }
    private func setCrossButtonHidden(textField: UITextField, hidden: Bool) {
        switch textField.tag {
        case textfieldTag.usernameTextFld.rawValue:
            textField.returnKeyType = .Next
            userEmailCrossButton.hidden = hidden
        case textfieldTag.passwordTxtFld.rawValue:
            textField.returnKeyType = .Done
            passswordCrossButton.hidden = hidden
        default:
            break
        }
    }
    private func setTextFieldLineLabelColor(textField: UITextField, lineColor: UIColor) {
        switch textField.tag {
        case textfieldTag.usernameTextFld.rawValue:
            userEmailLineLabel.backgroundColor = lineColor
        case textfieldTag.passwordTxtFld.rawValue:
            passwordLineLabel.backgroundColor = lineColor
        default:
            break
        }
    }
    private func logInButtonEnabeldWithClearTextField(enable: Bool) {
        loginButton.enabled = enable
    }
    private func logInButtonEnabeld() {
        if((userEmailTextField.text!.isEmpty == false) && (passwordTextField.text!.isEmpty == false)) {
            loginButton.enabled = true
        } else {
            loginButton.enabled = false
        }
    }
    private func handleLogInButtonAction() {
        let notificationManager = NotificationManager()
        notificationManager.restart()
        handleTap(self.view)
        validateUserAndPassTextField()
        setTextFieldLineLabelColor(userEmailTextField, lineColor:LineLabelColor.unSelected.color )
        setTextFieldLineLabelColor(passwordTextField, lineColor:LineLabelColor.unSelected.color )
    }
    private func updatePasswordTextFieldString(textField: UITextField) {
        if(isPasswordEntered == true) {
            isPasswordEntered = false
            setCrossButtonHidden(textField, hidden: true)
            logInButtonEnabeldWithClearTextField(false)
        } else {
            setCrossButtonHidden(textField, hidden: false)
            logInButtonEnabeld()
        }
    }
    func performNavigation () {
        self.performSegueWithIdentifier(SegueIdentifierConstants.loginToHomeSegue, sender: nil)
    }
}
extension MEDLoginViewController{
    func showCriticalUpdateErrorMessage(){
        var alertView: UIAlertController?
        let alertController = AlertController()
        currentAlertViewTag = loginAlertTags.criticalupdate
        alertController.delegate = self
        alertView = alertController.showCustomAlertWithOneActions(NSLocalizedString("AppUpdateTitle", comment: ""), message: NSLocalizedString("AppUpdateMsg", comment: ""), btnTitle: NSLocalizedString("AppUpdateBtnTitle", comment: ""), preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)
    }
    func defaultButtonAction(alertController: UIAlertController) {
        switch currentAlertViewTag.rawValue {
        case loginAlertTags.criticalupdate.rawValue:
            if let urlString = self.updateURL{
                let url: NSURL = NSURL(string:urlString)!
                UIApplication.sharedApplication().openURL(url)
            }
        default:
            self.view.endEditing(true)
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }
    }
    func cancelButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func OKButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
}

// MARK: - Valdiations
extension MEDLoginViewController {
    private  func validateUserAndPassTextField() {
        if(MEDLoginValidations.isValidUserName(userEmailTextField.text!)) {
            validatePasswordTextField()
        } else {
            clearTextField(passwordTextField, hidden:true)
            showAlert(LoginStringConstants.InvalidInputAlertTitle, alertMsg: LoginStringConstants.InvalidInputAlertMsg )
        }
    }
    private func doLogin() {
        if(NetworkUtil.isConnected()) {
            performLogin()
        } else {
            clearTextField(passwordTextField, hidden:true)
            showAlert(NetworkStringConstants.NetworkConnectionAlertTitle, alertMsg: NetworkStringConstants.NetworkConnectionAlertMsg )
        }
    }
    private func validatePasswordTextField() {
        //if(MEDLoginValidations.isValidPassword(passwordTextField.text!)) {
        doLogin()
        //        } else {
        //            clearTextField(passwordTextField, hidden:true)
        //            showAlert(LoginStringConstants.InvalidInputAlertTitle, alertMsg: LoginStringConstants.InvalidInputAlertMsg )
        //        }
    }
}
// MARK: - @IBAction Actions
extension MEDLoginViewController {
    @IBAction func LoginButtonAction(sender: AnyObject) {
        FIRAnalytics.logEventWithName(kFIREventLogin, parameters:["SCREEN_NAME":"LoginIn"])
        handleLogInButtonAction()
    }
    @IBAction func clearUserNameTextField(sender: AnyObject?) {
        clearTextField(userEmailTextField, hidden:true)
    }
    @IBAction func clearPasswordTextField(sender: AnyObject?) {
        clearTextField(passwordTextField, hidden:true)
    }
}
