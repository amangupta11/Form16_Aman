//  MEDLoginViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
// MARK: -  Server Interaction
extension MEDLoginViewController {
    func getUserDetails() {
        checkInternet()
        if (Patient.sharedInfo.userInfo != nil) {
            APIRequest.sharedAPI.getUserDetails({ (jsonString, successful, error, response) in
                dispatch_async(dispatch_get_main_queue(), {
                    self.performNavigation()
                })
            })
        }
    }
    
    func performLogin() {
        ActivityIndicatorView.sharedActivityView.showOverlay()
        APIRequest.sharedAPI.requestLogin(username: userEmailTextField.text!, password:passwordTextField.text!,chanelId: NotificationManager.chanelId()) { (data, successful, error, response)in
            dispatch_async(dispatch_get_main_queue(), {
                if successful {
                    if let isUpdateAvailable = data?[StringConstants.IsUpgradeRequired]{
                        if isUpdateAvailable{
                            self.updateURL = data?[StringConstants.OTALink].stringValue
                            ActivityIndicatorView.sharedActivityView.hideOverlayView()
                            self.showCriticalUpdateErrorMessage()
                        }
                        else{
                            self.getUserDetails()
                        }
                    }
                } else {
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    var title = NSLocalizedString("ERROR", comment: "")
                    self.clearPasswordTextField(nil)
                    switch response!.statusCode{
                    case ErrorCode.UserBlockedCode.rawValue:
                        super.showAlert(title, alertMsg:NSLocalizedString("AccLocked", comment: ""))
                    case ErrorCode.LoginAttemptLeftCode.rawValue:
                        super.showAlert(title, alertMsg:NSLocalizedString("LoginAtmpCode", comment: ""))
                    default:
                        var errorMessage = " "
                        if let error = error {
                            errorMessage = error.localizedDescription
                            if( error.localizedFailureReason?.isEmpty == false ) {
                                title = error.localizedFailureReason!
                            }
                        }
                        super.showAlert(title, alertMsg:errorMessage)
                    }
                }
            })
        }
    }
}