//  MEDHospitalListViewController+API.swift
//  Copyright © 2016 Medtronic. All rights reserved.
import Foundation
// MARK: -  Server Interaction
extension MEDHospitalListViewController {
        func performSpokeTransfer() {
            checkInternet()
            var dict: NSDictionary? = nil

            Patient.sharedInfo.patientInfo?.timeLine?.spokeTransferTime  = DateUtility.getCurrentTimeInGMT()
            Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutTime =  nil ;


            var spokeTransferTime: [String:AnyObject] = [:]
            spokeTransferTime[TimeLineKey.Comment.rawValue] = nil
            spokeTransferTime[TimeLineKey.Location.rawValue] = nil
            let myDouble = NSNumber(double: (Patient.sharedInfo.patientInfo?.timeLine?.spokeTransferTime)!)
            spokeTransferTime[TimeLineKey.Time.rawValue] = myDouble.stringValue

            var fmcDoorOutTime: [String:AnyObject] = [:]
            fmcDoorOutTime[TimeLineKey.Comment.rawValue] = nil
            fmcDoorOutTime[TimeLineKey.Location.rawValue] = nil
            fmcDoorOutTime[TimeLineKey.Time.rawValue] = nil


            dict = [PatientInfoKey.CaseID.rawValue:(Patient.sharedInfo.patientInfo?.caseID)!, "transferHospitalID":hospitalID, TimeLineKey.SpokeTransferTime.rawValue: spokeTransferTime, TimeLineKey.FmcDoorOutTime.rawValue:fmcDoorOutTime ]
            APIRequest.sharedAPI.performSpokeTransfer(dict, completion: {
                (jsonString, successful, error, response) in
                dispatch_async(dispatch_get_main_queue(), {
                    ActivityIndicatorView.sharedActivityView.hideOverlayView()
                    if successful {
                        self.getFMCDoorOutForPatient()
                    } else {
                        var errorMessage = StringConstants.ErrorTitle
                        let title = StringConstants.ErrorTitle
                        if let error = error {
                            errorMessage = error.localizedDescription
                        }
                        if(response?.statusCode == 425) {
                            // Present custom alert
                            self.showCustomAlertWithOneButton(title, message: errorMessage, alertTag: customAlertTags.AlreadyTransfered)
                        } else {
                        super.showAlert(title, alertMsg:errorMessage)
                        }
                    }
                })
            })
    }
    func getFMCDoorOutForPatient() {
        checkInternet()
        var dict: NSDictionary? = nil
        dict = [PatientInfoKey.CaseID.rawValue:(Patient.sharedInfo.patientInfo?.caseID)!]
        APIRequest.sharedAPI.getFMCDetails(dict, completion: {
            (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                ActivityIndicatorView.sharedActivityView.hideOverlayView()
                if successful {
                    self.navigateToSpokeNurseTimeLine()
                    //Save Patient info
                } else {
                    super.handleError(error)
                }
            })
        })
    }
}
