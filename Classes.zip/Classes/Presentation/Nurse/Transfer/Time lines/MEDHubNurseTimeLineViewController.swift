//  MEDHubNurseTimeLineViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import Firebase
class MEDHubNurseTimeLineViewController: MEDBaseViewController {
    
    @IBOutlet var doorInAtHubOutlet: UIButton!
    @IBOutlet weak var fmcDoorOutEditedText: UILabel!
    @IBOutlet weak var maxAttemptLabel: UILabel!
    @IBOutlet weak var hubDoorInEditedTextLabel: UILabel!
    @IBOutlet var doorInAtHubLineLabel: UILabel!
    @IBOutlet weak var fmcDoorOutDateLabel: UILabel!
    @IBOutlet weak var fmcDoorOutTimeLabel: UILabel!
    @IBOutlet weak var transferToCathLabButtonOutlet: UIButton!
    @IBOutlet weak var editHubDoorInButtonOutlet: UIButton!
    @IBOutlet weak var hubDoorInDateLabel: UILabel!
    @IBOutlet weak var hubDoorInTimeLabel: UILabel!
    @IBOutlet weak var hubDoorInCheckMarkButton: UIButton!
    
    @IBOutlet weak var fmcDoorOutButton: UIButton!
    @IBOutlet weak var fmcDoorOutLineLabel: UILabel!
    
    @IBOutlet weak var cathLabReadyCallButton: UIButton!
    @IBOutlet weak var cathLabReadyLabel: UILabel!
    @IBOutlet weak var cathLabReadyView: UIView!
    @IBOutlet weak var fmcDoorOutSepLabel: UILabel!
    var currentAlertViewTag: hubDoorInCustomAlertTags!
    var pickerContainerDelegate: MEDPickerContainerDelegate!
    struct HubNurseTimeLineConstants {
        static var ConfirmationAlertTitle = NSLocalizedString("CONFIRMATION", comment: "")
        static var TransferAlertMsg   =   NSLocalizedString("ARE_YOU_SURE_YOU_WANT_TO_TRANSFER_THIS_CASE_TO_CATH_LAB", comment: "")
        static var AttentionTitle = NSLocalizedString("ATTENTION", comment: "")
        static var cathLabReady = NSLocalizedString("CATH_LAB_IS_READY", comment: "")
    }
    enum hubDoorInCustomAlertTags: Int {
        case AlreadyTransfered = 101
    }
    var pickerContainerView: UIView!
    var selectedDateString: String? = nil
    var selectedTimeString: String? = nil
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
        // Do any additional setup after loading the view.
    }
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        invalidateTimer()
    }
    override func viewWillAppear(animated: Bool) {
        if Patient.sharedInfo.patientInfo != nil {
            startTimer()
            updateUI()
        }
        FIRAnalytics.setScreenName(FireBaseConstants.hubDoorIn, screenClass: FireBaseConstants.hubDoorIn)
    }
}


// MARK: - Custom Actions
extension MEDHubNurseTimeLineViewController {
    func navigateToHome() {
        if self.navigationController?.viewControllers.first is MEDHomeViewController
        {
            let topViewController = self.navigationController?.viewControllers.first as! MEDHomeViewController
            topViewController.shouldTableViewRefresh = true
        }
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    func initialSetup() {
        self.navigationItem.rightBarButtonItem = nil
        self.transferToCathLabButtonOutlet.hidden = true
        setNavigationBackButtonImage()
    }
    override func backButtonAction(button: UIButton) {
        FIRAnalytics.logEventWithName(FireBaseEvents.doorInToSummary, parameters:nil)
        self.navigationController?.popViewControllerAnimated(true)
    }
    func enableHubDoorInButton() {
        self.editHubDoorInButtonOutlet.hidden = false
    }
    func addPickerForDoorInAtHub(){
        self.view.endEditing(true)
        self.pickerContainerDelegate = MEDPickerContainerDelegate(frame: self.navigationController!.view.frame)
        self.pickerContainerDelegate.delegate = self
        self.pickerContainerView = self.pickerContainerDelegate.datePickerView()
        var date: NSDate
        date = NSDate(timeIntervalSince1970: (Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutTime)!)
        self.pickerContainerDelegate.datePicker.maximumDate = NSDate()
        self.pickerContainerDelegate.datePicker.minimumDate = date
        self.pickerContainerView.backgroundColor = ColorPicker.transparentScreenBackgroundColor()
        let window = UIApplication.sharedApplication().delegate?.window
        window!!.addSubview(self.pickerContainerView)
        
        FIRAnalytics.logEventWithName(FireBaseEvents.doorIn, parameters:nil)

    }

    func udpateHubDoorInTime() {
        let hubDoorInTime = Patient.sharedInfo.patientInfo?.timeLine?.hubDoorInTime
        let doorInTimeString = DateUtility.convertGMTtoTime(hubDoorInTime!)
        let doorInDateString = DateUtility.convertGMTtoShortDate(hubDoorInTime!)
        self.hubDoorInDateLabel.text = doorInDateString
        self.hubDoorInTimeLabel.text = doorInTimeString
    }
    func updateFMCDoorOutTime() {
        let fmcDoorOutTime: NSTimeInterval
        if(Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutTime != nil && Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutTime != 0){
             fmcDoorOutTime = (Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutTime )!
        let fmcDoorOutTimeString = DateUtility.convertGMTtoTime(fmcDoorOutTime)
        let fmcDoorOutDateString = DateUtility.convertGMTtoShortDate(fmcDoorOutTime)
        self.fmcDoorOutDateLabel.text = fmcDoorOutDateString
        self.fmcDoorOutTimeLabel.text = fmcDoorOutTimeString
         updateFMCDoorOutUI()
        let  fmcEditedText  = Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutEditedText
        if fmcEditedText != nil && fmcEditedText != "0" {
        self.fmcDoorOutEditedText.attributedText = StringUtility.strikeText(fmcEditedText!)
        } else {
            self.fmcDoorOutEditedText.text = ""
         }
        }
    }
    func updateFMCDoorOutUI(){
        self.fmcDoorOutTimeLabel.textColor = ColorPicker.steelGreyColor()
        self.fmcDoorOutDateLabel.textColor = ColorPicker.steelGreyColor()
        self.fmcDoorOutLineLabel.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
        self.fmcDoorOutSepLabel.backgroundColor = ColorPicker.peaGreenColor()
        self.fmcDoorOutButton.selected = true
    }
    func changeFontColorForDateLabel(color: UIColor) {
        self.hubDoorInTimeLabel.textColor = color
        self.hubDoorInDateLabel.textColor = color
    }
    func updateUIAfterEditingHubDoorInTime() {
        self.transferToCathLabButtonOutlet.hidden = false
        self.hubDoorInCheckMarkButton.selected = true
        self.doorInAtHubOutlet.userInteractionEnabled = true
        enableHubDoorInButton()
        udpateHubDoorInTime()
        changeFontColorForDateLabel(ColorPicker.charcoalGrey())
    }
    func updateUI() {
        let hubDoorInTime = Patient.sharedInfo.patientInfo?.timeLine?.hubDoorInTime
        self.doorInAtHubOutlet.userInteractionEnabled = false
        if  hubDoorInTime != nil && hubDoorInTime != 0 {
            // Populate the hub Door In time
            updateUIAfterEditingHubDoorInTime()
        }
        updateFMCDoorOutTime()
        
        self.maxAttemptLabel.text =  ButtonTitles.attemptRemainingString
        if Int((Patient.sharedInfo.patientInfo?.timeLine?.hubDoorInEditCount)!) == 3 {
            changeFontColorForDateLabel(ColorPicker.steelGreyColor())
            self.doorInAtHubLineLabel.backgroundColor = ColorPicker.warmGreyColorWithOpacity()
            self.editHubDoorInButtonOutlet.hidden = true
            self.doorInAtHubOutlet.userInteractionEnabled = false
            self.maxAttemptLabel.hidden = true
        }
        else{
            self.maxAttemptLabel.text =  "\(3 - Int((Patient.sharedInfo.patientInfo?.timeLine?.hubDoorInEditCount)!)!)" + ButtonTitles.attemptsRemainingString
        }
       
        let editedText  = Patient.sharedInfo.patientInfo?.timeLine?.hubDoorInEditedText
         if editedText != nil && editedText != "0" {
            self.hubDoorInEditedTextLabel.attributedText = StringUtility.strikeText(editedText!)
        } else {
           self.hubDoorInEditedTextLabel.text = ""
        }
        if(Patient.sharedInfo.patientInfo?.isCathLabReady == true){
            self.cathLabReadyView.backgroundColor = ColorPicker.peaGreenColor()
            self.cathLabReadyLabel.text = HubNurseTimeLineConstants.cathLabReady
        }
        let countryCode = Patient.sharedInfo.patientInfo?.treatmentCenter?.countryCode as String!
        let mobileNumber = Patient.sharedInfo.patientInfo?.treatmentCenter?.phoneNumber as String!
        if(mobileNumber != nil) {
            if(countryCode != nil && mobileNumber.isEmpty == false) {
                self.cathLabReadyCallButton.titleLabel?.text = countryCode + mobileNumber
            }
        }
    }

    func showTransferConfirmationAlert(alertTile: String, alertMsg: String) {
        let alertCntrl = AlertController()
        alertCntrl.delegate = self
        let alertController = alertCntrl.showCustomAlertWithTwoActions(alertTile, message:alertMsg, okTitle: NSLocalizedString("NO", comment: ""), cancelTitle: NSLocalizedString("YES", comment: ""), prefereredStyle: UIAlertControllerStyle.Alert, tag:0)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }

    //MARK: - Custom alert view
    func showCustomAlertWithOneButton(alertTitle: String, message: String, alertTag: hubDoorInCustomAlertTags) {
        var alertView: UIAlertController?
        let alertController = AlertController()
        alertController.delegate = self
        currentAlertViewTag = alertTag
        alertView = alertController.showSimpleAlert(alertTitle, message:message, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertView!, animated: true, completion: nil)

    }
}


// MARK: - @IBAction Methods
extension MEDHubNurseTimeLineViewController: pickerViewProtocol {

    @IBAction func transferToCathlabAction(sender: AnyObject) {
        FIRAnalytics.logEventWithName(FireBaseEvents.intTransfer, parameters:nil)
        self.showTransferConfirmationAlert(HubNurseTimeLineConstants.ConfirmationAlertTitle, alertMsg: HubNurseTimeLineConstants.TransferAlertMsg)
    }
    @IBAction func checkHubDoorInButtonAction(sender: AnyObject) {
        FIRAnalytics.logEventWithName(FireBaseEvents.doorIn, parameters:nil)
        if((sender as! UIButton).selected == false) {
        let formatter = NSDateFormatter()
        formatter.dateFormat = "dd-MMM-yyyy h:mma"
        let selectedDateAndTime  = NSDate()
        let dateString = formatter.stringFromDate(selectedDateAndTime)
        Patient.sharedInfo.patientInfo?.timeLine?.hubDoorInTime = DateUtility.convertStringToDate(dateString)
        self.editHubDoorInTime()
        }
    }
    
    @IBAction func cathLabReadyCallAction(sender: AnyObject) {
        FIRAnalytics.logEventWithName(FireBaseEvents.callCathLab, parameters:nil)
        if(self.cathLabReadyCallButton.titleLabel?.text?.isEmpty == false) {
            SocialNetwork.makeCall((cathLabReadyCallButton.titleLabel?.text)!)
        }
    }
   
    @IBAction func doorInAtHubButtonAction(sender: AnyObject) {
        addPickerForDoorInAtHub()
    }
    

    @IBAction func editHubDoorInTimeButtonAction(sender: AnyObject) {
        addPickerForDoorInAtHub()
    }
}

// MARK: - Picker Delegates
extension MEDHubNurseTimeLineViewController {
    func datePickerDoneButtonTapped(selectedTime: String!, selectedDate: String!) {
        let dateString = String(format: "%@ %@", selectedDate, selectedTime)
        Patient.sharedInfo.patientInfo?.timeLine?.hubDoorInTime = DateUtility.convertStringToDate(dateString)
        editHubDoorInTime()
    }
}


//MARK: - Alert view delegates
extension MEDHubNurseTimeLineViewController: AlertViewControllerProtocol {
    func cancelButtonAction(alertController: UIAlertController) {
        performHubNurseInternalTransfer()
    }
    func OKButtonAction(alertController: UIAlertController) {

        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
    func defaultButtonAction(alertController: UIAlertController) {
        switch self.currentAlertViewTag.rawValue {
        case 101:
            navigateToHome()
            alertController.dismissViewControllerAnimated(true, completion: nil)
        default:
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }


    }
}
