//  MEDHubNurseInternalTransferViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.


import UIKit
import Firebase
class MEDHubNurseInternalTransferViewController: MEDBaseViewController {
    @IBOutlet weak var cathLabReadyCallButton: UIButton!
    @IBOutlet weak var cathLabReadyLabel: UILabel!
    @IBOutlet weak var cathLabReadyView: UIView!
    var currentAlertViewTag: hubDoorInCustomAlertTags!
    struct InternalTransferConstants {
        static var AttentionAlertTitle = NSLocalizedString("ATTENTION", comment: "")
        static var AttentionAlertMsg   =  NSLocalizedString("THIS_CASE_HAS_ALREADY_BEEN_TRANSFERED", comment: "")
        static var ConfirmationAlertTitle = NSLocalizedString("CONFIRMATION", comment: "")
        static var ConfirmationAlertMsg   =  NSLocalizedString("ARE_YOU_SURE_YOU_WANT_TO_TRANSFER_THIS_CASE_TO_CATH_LAB", comment: "")
        static var cathLabReady = NSLocalizedString("CATH_LAB_IS_READY", comment: "")
    }
    enum hubDoorInCustomAlertTags: Int {
        case AlreadyTransfered = 101
    }
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp("")
    }
    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
        super.viewWillDisappear(animated)
    }
    override func viewWillAppear(animated: Bool) {
        if Patient.sharedInfo.patientInfo != nil {
            updateUI()
            startTimer()
        }
        FIRAnalytics.setScreenName(FireBaseConstants.hubIntTransfer, screenClass: FireBaseConstants.hubIntTransfer)
    }
}
// MARK: -  Custom Actions
extension MEDHubNurseInternalTransferViewController {
    override func initialSetUp(bgImage: String) {
        self.setNavigationBackButtonImage()
    }
    override func backButtonAction(button: UIButton) {
        FIRAnalytics.logEventWithName(FireBaseEvents.hubIntTransfertoSummary, parameters:nil)
        if let viewControllers = navigationController?.viewControllers {
            var i = 0
            for viewController in viewControllers {
                i += 1
                if viewController.isKindOfClass( MEDViewSummaryViewController) {
                    self.navigationController?.popViewControllerAnimated(true)
                    return
                }
            }
            self.navigateToViewSummary()
        }

    }
//    func navigateToHomeListScreen() {
//        self.navigationController?.popToRootViewControllerAnimated(true)
//    }
    func CheckPatientCaseStatus() {
        self.showConfirmationAlert(InternalTransferConstants.ConfirmationAlertTitle, alertMsg:InternalTransferConstants.ConfirmationAlertMsg)
    }
    func navigateToViewSummary() {
        let storyBoard: UIStoryboard = UIStoryboard(name: StroryBoardNameConstants.SBNameECGCapture, bundle:nil)
        let vc = storyBoard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.viewSummaryScreenSBID) as! MEDViewSummaryViewController
        self.hidesBottomBarWhenPushed = false
        for viewController in (self.navigationController?.viewControllers)! {
            viewController.hidesBottomBarWhenPushed = false
        }
        vc.hidesBottomBarWhenPushed = false
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func updateUI(){
        if(Patient.sharedInfo.patientInfo?.isCathLabReady == true){
            self.cathLabReadyView.backgroundColor = ColorPicker.peaGreenColor()
            self.cathLabReadyLabel.text = InternalTransferConstants.cathLabReady
        }
        let countryCode = Patient.sharedInfo.patientInfo?.treatmentCenter?.countryCode as String!
        let mobileNumber = Patient.sharedInfo.patientInfo?.treatmentCenter?.phoneNumber as String!
        if(mobileNumber != nil) {
            if(countryCode != nil && mobileNumber.isEmpty == false) {
                self.cathLabReadyCallButton.titleLabel?.text = countryCode + mobileNumber
            }
        }
    }
    func navigateToHome() {
        if self.navigationController?.viewControllers.first is MEDHomeViewController
        {
            let topViewController = self.navigationController?.viewControllers.first as! MEDHomeViewController
            topViewController.shouldTableViewRefresh = true
        }
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    func showAttentionAlert(alertTag: hubDoorInCustomAlertTags) {
        let alertCntrl = AlertController()
        alertCntrl.delegate = self
        currentAlertViewTag = alertTag
        let alertController = alertCntrl.showSimpleAlert(InternalTransferConstants.AttentionAlertTitle, message: InternalTransferConstants.AttentionAlertMsg, preferredStyle: UIAlertControllerStyle.Alert)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
    func showConfirmationAlert(alertTile: String, alertMsg: String) {
        let alertCntrl = AlertController()
        alertCntrl.delegate = self
        let alertController = alertCntrl.showCustomAlertWithTwoActions(alertTile, message: alertMsg, okTitle:NSLocalizedString("NO", comment: ""), cancelTitle: NSLocalizedString("YES", comment: ""), prefereredStyle: UIAlertControllerStyle.Alert, tag:0)
        self.presentViewController(alertController, animated: true, completion: {
        })
    }
}
// MARK: - @IBAction Actions
extension MEDHubNurseInternalTransferViewController {
    @IBAction func transferToCathlabButtonTapped(sender: AnyObject) {
        FIRAnalytics.logEventWithName(FireBaseEvents.walkInIntCathLab, parameters:nil)
        CheckPatientCaseStatus()
    }
    @IBAction func cathLabReadyCallAction(sender: AnyObject) {
        FIRAnalytics.logEventWithName(FireBaseEvents.walkInCallCathLab, parameters:nil)
        if(self.cathLabReadyCallButton.titleLabel?.text?.isEmpty == false) {
            SocialNetwork.makeCall((cathLabReadyCallButton.titleLabel?.text)!)
        }
    }
}

// MARK: - AlertView delegates
extension MEDHubNurseInternalTransferViewController: AlertViewControllerProtocol {
    func cancelButtonAction(alertController: UIAlertController) {
        performHubNurseInternalTransfer()
    }
    func OKButtonAction(alertController: UIAlertController) {
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
    func defaultButtonAction(alertController: UIAlertController) {
        switch self.currentAlertViewTag.rawValue {
        case 101:
            navigateToHome()
            alertController.dismissViewControllerAnimated(true, completion: nil)
        default:
            alertController.dismissViewControllerAnimated(true, completion: nil)
        }
    }
}
