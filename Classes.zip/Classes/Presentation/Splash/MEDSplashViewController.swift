//  MEDSplashViewController.swift
//  Copyright © 2016 Medtronic. All rights reserved.


import UIKit

class MEDSplashViewController: MEDBaseViewController {
    @IBOutlet weak var titleImageView: UIImageView!
    var imageArray: [UIImage] = []
    @IBOutlet weak var ecgAnimationImageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialSetUp(nil)
        // Do any additional setup after loading the view, typically from a ni
    }
}
// MARK: - Custom Actions
extension MEDSplashViewController {
    override func initialSetUp(bgImage: String?) {
        self.setBackgroundImageToView("Home_image")
        self.navigationController?.navigationBarHidden = true
        setupImagesArray()
        animateImages()
    }
    func setupImagesArray() {
        for i in 1...25 {
            imageArray.append(UIImage(named: StringConstants.ecgAnimationImagesStringExtenstion.stringByAppendingString(String(i)))!)
        }
    }
    //MARK: - Animating Images
    func animateImages() {
        self.ecgAnimationImageView.animationImages = imageArray
        self.ecgAnimationImageView.animationDuration = 2.0
        self.ecgAnimationImageView.startAnimating()
        self.performSelector(#selector(MEDSplashViewController.animationFinished), withObject: nil, afterDelay:1 )
    }
    func animationFinished() {
        // Moving the user to login screen
        let loginStoryboard: UIStoryboard = UIStoryboard(name: StroryBoardNameConstants.SBNameLogin, bundle:nil)
        let loginViewController = loginStoryboard.instantiateViewControllerWithIdentifier(StroryBoardViewConstants.loginSBID) as! MEDLoginViewController
        self.navigationController?.pushViewController(loginViewController, animated: true)
    }
}
