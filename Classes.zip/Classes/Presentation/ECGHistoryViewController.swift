//  ECGHistoryViewController.swift

import UIKit
import Firebase
class ECGHistoryViewController: MEDBaseViewController {
    
    @IBOutlet weak var scrollContentView: UIView!
    @IBOutlet weak var ecgImageView: UIImageView!
    @IBOutlet weak var downloadingSyncButtonOutlet: UIButton!
    @IBOutlet weak var ecgHistoryCollectionView: UICollectionView!
    @IBOutlet weak var infarctTableViewOutlet: UITableView!
    @IBOutlet weak var scrollContentViewHeightConstraint: NSLayoutConstraint!
    enum ECGHistoryConstants: String {
        case InfarctAreaCellIdentifier = "InfractAreaCell"
        case OtherCommentsLabel = "Others/Comments"
        case InfractAreaCellWithTextViewIdentifier = "InfractAreaCellWithTextView"
        
    }
    private var infractAreaRowHeight = 60
    let defaultImage = UIImage(named: "defaultECGImage")
    var defaultScrollContentViewHeight = 720
    var otherCommentsNumberOfLines: Int = -1
    var otherCommentsText = ""
    var isOtherComments = false
    var infractAreaArray: NSMutableArray = NSMutableArray()
    var ecgImage: UIImage? = nil
    var selectedCellIndex: Int = 0
    var infarctAreaHistoryArray = NSMutableArray()
    var ecgImagesArray = NSMutableArray()
    var ecgURLArray = NSMutableArray()
    var ecgFileNamesArray = NSMutableArray()
    var localImagePathArray = NSMutableArray()
    var ecgImageDict = NSMutableDictionary()
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUp("")
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(animated: Bool) {
        if Patient.sharedInfo.patientInfo != nil{
            startTimer()
        }
        FIRAnalytics.setScreenName(FireBaseConstants.ecgScreen, screenClass: FireBaseConstants.ecgScreen)
    }

    override func viewWillDisappear(animated: Bool) {
        invalidateTimer()
    }
    
    override func viewDidLayoutSubviews() {
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
// MARK:- Custom Functions
extension ECGHistoryViewController {
    
    func ecgButtonTapped(sender: UIButton) {
        if sender.tag == selectedCellIndex {
            // Return same button tapped
            return
        }
        
        // Different Button Tapped
        let previousCellIndex = selectedCellIndex
        selectedCellIndex = sender.tag
        // Reload the collection view
        self.ecgHistoryCollectionView.reloadItemsAtIndexPaths([NSIndexPath(forItem: previousCellIndex, inSection: 0), NSIndexPath(forItem: selectedCellIndex, inSection: 0)])
        
        self.updateInfarctAreas(sender.tag)
        self.reloadInfarctAreaTable()
        self.ecgHistoryCollectionView.reloadItemsAtIndexPaths([NSIndexPath(forItem: previousCellIndex, inSection: 0),NSIndexPath(forItem: selectedCellIndex, inSection: 0)])
        
        
        let dict = infarctAreaHistoryArray[sender.tag] as? NSMutableDictionary
        let url = "\(ecgPath)/\((Patient.sharedInfo.patientInfo?.caseID)!)/\((dict?.valueForKey("ecgName") as! String))"
        let image = self.ecgImageDict.objectForKey(url) as? UIImage
        
        if image != defaultImage {
            showImageToImageView()
        }else{
            self.showRetryButton(false, isRotating: true)
            self.downloadECGImage(url)
        }
        
        
    }
    func reloadInfarctAreaTable() {
        self.scrollContentViewHeightConstraint.constant = CGFloat(defaultScrollContentViewHeight) - CGFloat((9 - (self.infractAreaArray
            .count))) * 50
        if isOtherComments == true {
            self.scrollContentViewHeightConstraint.constant += 80
        }
        self.view.layoutIfNeeded()
        self.infarctTableViewOutlet.reloadData()
        
    }
    override func initialSetUp(bgImage: String) {
        setNavigationBackButton()
        getAWSBucketInformation()
        setTapActionOnImageView()
        infarctTableViewOutlet.scrollEnabled = false
        ecgImage = defaultImage
    }
    func setNavigationBackButton() {
        let image = UIImage(named: ButtonTitles.BackIcon)
        let backButton = UIButton(type: UIButtonType.Custom)
        backButton.addTarget(self, action: #selector(backBtnAction), forControlEvents: UIControlEvents.TouchUpInside)
        backButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: -30, bottom: 0, right: -10)
        backButton.setImage(image, forState: UIControlState.Normal)
        backButton.sizeToFit()
        let backButtonItem = UIBarButtonItem(customView: backButton)
        self.navigationItem.leftBarButtonItem = backButtonItem
    }
    func backBtnAction(button: UIButton) {
        FIRAnalytics.logEventWithName(FireBaseEvents.ecgToSummary, parameters:nil)
        self.navigationController?.popViewControllerAnimated(true)
    }

    func updateUIAfterLoading(){
        self.updateInfarctAreas(0)
        self.updateURLArray()
        self.reloadInfarctAreaTable()
        self.ecgHistoryCollectionView.reloadData()
        let dict = self.infarctAreaHistoryArray[0] as? NSMutableDictionary
        let url = "\(ecgPath)/\((Patient.sharedInfo.patientInfo?.caseID)!)/\((dict?.valueForKey("ecgName") as! String))"
        print("url",url)
        self.downloadECGImage(url)
    }
    func setTapActionOnImageView() {
        let tapGestureRecognizer = UITapGestureRecognizer(target:self, action:#selector(MEDPatientECGViewController.imageTapped(_:)))
        self.ecgImageView.userInteractionEnabled = true
        self.ecgImageView.addGestureRecognizer(tapGestureRecognizer)
    }
    
    func imageTapped(img: AnyObject) {
        if self.downloadingSyncButtonOutlet.hidden == true {
        if ecgImage != defaultImage{
        //Present ecg preview controller screen to zoom in and out
        self.presenetECGImagePreviewScreen()
        }
        }
    }
    func presenetECGImagePreviewScreen() {
        let ecgPreviewScreen = UIStoryboard(name: StroryBoardNameConstants.SBCreateCase, bundle: nil).instantiateViewControllerWithIdentifier(StroryBoardViewConstants.ecgPreviewScreenSBID) as? MEDPatientECGPreviewViewController
        ecgPreviewScreen?.ecgImage = self.ecgImage
        ecgPreviewScreen?.hidesBottomBarWhenPushed = true
        ecgPreviewScreen?.title = "ECG"
        self.navigationController?.pushViewController(ecgPreviewScreen!, animated: true)
    }
    func downloadECGImage(downloadURL: String!) {
        if NetworkUtil.isConnected() == false {
            showRetryButton(false, isRotating: false)
            return
        }
        showRetryButton(false, isRotating: true)
        let filePathUrl = NSURL.fileURLWithPath(downloadURL)
        downloadImage(NSURL.fileURLWithPath(NSTemporaryDirectory().stringByAppendingString(filePathUrl.lastPathComponent!)), s3DownloadKeyName:downloadURL)
        
    }
    func handleDownloadError() {
        // handle the error and show the respective UI
        let dict = infarctAreaHistoryArray[selectedCellIndex] as! NSMutableDictionary
        let url = "\(ecgPath)/\((Patient.sharedInfo.patientInfo?.caseID)!)/\((dict.valueForKey("ecgName") as! String))"
        
        if ecgImageDict.objectForKey(url) as? UIImage == defaultImage{
            showRetryButton(false, isRotating: false)
        }
        
    }
    func updateECGImage(url: String, localPath: String) {
        
        let ecgFileName = NSURL(fileURLWithPath: url).lastPathComponent
        let caseID = Patient.sharedInfo.patientInfo?.caseID
        if caseID != nil {
            let filePath = String(format: "%@/%@", FileUtility.getECGFolder(caseID!), ecgFileName!)
            if let image = UIImage(contentsOfFile: filePath){
            self.ecgImageDict.setValue(image, forKey: url)
            }
        }
        showImageToImageView()
    }
    
    //    if let localPath = Patient.sharedInfo.patientInfo?.ecgInfo?.localPath {
    //        let image    = UIImage(contentsOfFile: localPath)
    //        self.ecgImage = image
    //        self.ecgImageView.image = self.ecgImage
    //        self.editInfarctAreaButtn.alpha = 1.0
    //    }

    
    func showImageToImageView(){
        let dict = infarctAreaHistoryArray[selectedCellIndex] as! NSMutableDictionary
        let url = "\(ecgPath)/\((Patient.sharedInfo.patientInfo?.caseID)!)/\((dict.valueForKey("ecgName") as! String))"
        let image = self.ecgImageDict.objectForKey(url) as? UIImage
        if image  != defaultImage{
            // Image is downloaded
            // Show it to view
            self.ecgImage = image
            self.ecgImageView.image = self.ecgImage
            showRetryButton(true, isRotating: false)
        }else {
            self.ecgImageView.image = image
            showRetryButton(false, isRotating: true)
        }
    }
    func showRetryButton(isHide: Bool, isRotating: Bool) {
        if isHide == false {
            self.ecgImageView.image = defaultImage
        }
        self.downloadingSyncButtonOutlet.hidden = isHide
        if isRotating == true {
            rotateView(self.downloadingSyncButtonOutlet)
            self.downloadingSyncButtonOutlet.userInteractionEnabled = false
        } else {
            self.downloadingSyncButtonOutlet.userInteractionEnabled = true
            stopRotatingView(self.downloadingSyncButtonOutlet)
        }
    }
    
    func rotateView(view: UIView, duration: Double = 1) {
        if view.layer.animationForKey(kRotationAnimationKey) == nil {
            let rotationAnimation = CABasicAnimation(keyPath: "transform.rotation")
            
            rotationAnimation.fromValue = 0.0
            rotationAnimation.toValue = Float(M_PI * 2.0)
            rotationAnimation.duration = duration
            rotationAnimation.repeatCount = Float.infinity
            view.layer.addAnimation(rotationAnimation, forKey: kRotationAnimationKey)
        }
    }
    func stopRotatingView(view: UIView) {
        if view.layer.animationForKey(kRotationAnimationKey) != nil {
            view.layer.removeAnimationForKey(kRotationAnimationKey)
        }
    }
    func updateURLArray(){
        for i in 0..<self.infarctAreaHistoryArray.count{
            let dict = infarctAreaHistoryArray[i] as? NSMutableDictionary
            let url = "\(ecgPath)/\((Patient.sharedInfo.patientInfo?.caseID)!)/\((dict?.valueForKey("ecgName") as! String))"
            self.ecgImageDict.setObject(defaultImage!, forKey: url)
            
        }
    }
    func updateInfarctAreas(fromIndex: Int) {
        let metaDataPList: NSDictionary!
        if let path = FileUtility.getPlistPath() {
            metaDataPList = NSDictionary(contentsOfFile: path)
            self.infractAreaArray = (metaDataPList.objectForKey("InfractAreaDetails")?.mutableCopy() as? NSMutableArray)!
        }
        let infarctDict = self.infarctAreaHistoryArray[fromIndex] as! NSMutableDictionary
        let infarctAreaKeys = ["anteroseptal", "anterior", "lateral", "extensiveAnterolateral", "inferior", "posterior", "rightSided", "leftMainStem", "others"]
        let tempArray = NSMutableArray()
        for i in 0..<self.infractAreaArray.count {
            if infarctDict.valueForKey(infarctAreaKeys[i])!.boolValue == true {
                tempArray.addObject((self.infractAreaArray.objectAtIndex(i)))
            }
        }
        isOtherComments = false
        if infarctDict.valueForKey("others")?.boolValue == true {
            isOtherComments = true
            self.otherCommentsText = String(infarctDict.valueForKey("comment")!)
        }
        self.infractAreaArray = tempArray
        
    }
    
    
    func checkIfInfractAreaSelected(index: Int) -> Bool {
        if(index == 0) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.anteroseptal != false ? true:false
        } else if(index == 1) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.anterior != false ? true:false
        } else if(index == 2) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.lateral != false ? true:false
        } else if(index == 3) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.extensiveanterolateral != false ? true:false
        } else if(index == 4) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.inferior != false ? true:false
        } else if(index == 5) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.posterior != false ? true:false
        } else if(index == 6) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.rightsided != false ? true:false
        } else if(index == 7) {
            return Patient.sharedInfo.patientInfo?.patientHistory?.leftmainstem != false ? true:false
        } else if(index == 8) {
            if Patient.sharedInfo.patientInfo?.patientHistory!.others == true {
                self.isOtherComments = true
                if Patient.sharedInfo.patientInfo?.patientHistory?.otherscomments != nil {
                    otherCommentsText = (Patient.sharedInfo.patientInfo?.patientHistory?.otherscomments)!
                }
            } else {
                self.isOtherComments = false
                otherCommentsNumberOfLines = 0
            }
            return Patient.sharedInfo.patientInfo?.patientHistory?.others != false ? true:false
        }
        return false
    }
    func getNumberOfLines(label: UILabel) -> Int {
        var lineCount = 0
        let textSize = CGSizeMake(label.frame.size.width, CGFloat(Float.infinity))
        let rHeight = lroundf(Float(label.sizeThatFits(textSize).height))
        let charSize = lroundf(Float(label.font.lineHeight))
        lineCount = rHeight/charSize
        return lineCount
    }
    func normalizeOtherCommentsTextView(textView: UITextView) {
        textView.layer.borderColor = ColorPicker.lightBlueGray2().CGColor
        textView.layer.borderWidth = 1
    }
    func UTCToLocalTime(date: String) -> String{
        // create dateFormatter with UTC time format
        let dateFormatter = NSDateFormatter()
        let dateFormatterDate: NSDate!
        // create   date from string
        dateFormatter.timeZone = NSTimeZone(name: "UTC")
        // change to a readable time format and change to local time zone
        dateFormatter.dateFormat = "HH:mm:ss"
        dateFormatterDate = dateFormatter.dateFromString(date)
        if dateFormatterDate != nil{
            dateFormatter.timeZone = NSTimeZone.localTimeZone()
            dateFormatter.dateFormat = "hh:mm"
            let date = dateFormatter.stringFromDate(dateFormatterDate)
            return date
        }else{
            return date
        }
        
    }
    
    func addSwipeEvents() {
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(ECGHistoryViewController.respondToSwipeGesture(_:)))
        swipeRight.direction = UISwipeGestureRecognizerDirection.Right
        self.view.addGestureRecognizer(swipeRight)
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(ECGHistoryViewController.respondToSwipeGesture(_:)))
        swipeLeft.direction = UISwipeGestureRecognizerDirection.Left
        self.view.addGestureRecognizer(swipeLeft)
    }
    func getECGFileName(url: String) -> String{
        var fileName =  NSURL.fileURLWithPath(url).lastPathComponent
        fileName = fileName?.stringByReplacingOccurrencesOfString(".jpeg", withString: "")
        fileName = fileName?.stringByReplacingOccurrencesOfString("ECG_", withString: "")
        fileName = self.UTCToLocalTime(fileName!)
        fileName = "ECG_".stringByAppendingString(fileName!)
        return fileName!

    }
    func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizerDirection.Right:
                if selectedCellIndex == 0 {
                    return
                }
                selectedCellIndex = selectedCellIndex - 1
                self.ecgHistoryCollectionView.scrollToItemAtIndexPath(NSIndexPath(forItem: selectedCellIndex, inSection: 0), atScrollPosition: UICollectionViewScrollPosition.CenteredHorizontally, animated: false)
                
                self.ecgHistoryCollectionView.reloadItemsAtIndexPaths([NSIndexPath(forItem: selectedCellIndex+1, inSection: 0), NSIndexPath(forItem: selectedCellIndex, inSection: 0)])
                
            case UISwipeGestureRecognizerDirection.Left:
                if selectedCellIndex == 9 {
                    return
                }
                selectedCellIndex = selectedCellIndex + 1
                
                self.ecgHistoryCollectionView.scrollToItemAtIndexPath(NSIndexPath(forItem: selectedCellIndex, inSection: 0), atScrollPosition: UICollectionViewScrollPosition.CenteredHorizontally, animated: false)
                
                self.ecgHistoryCollectionView.reloadItemsAtIndexPaths([NSIndexPath(forItem: selectedCellIndex-1, inSection: 0), NSIndexPath(forItem: selectedCellIndex, inSection: 0)])
            default:
                break
            }
        }
    }
    
    
    
}
// MARK:- Collection view delegates
extension ECGHistoryViewController:UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return infarctAreaHistoryArray.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell =    collectionView.dequeueReusableCellWithReuseIdentifier("ECGCustomCell", forIndexPath: indexPath) as?ECGCustomCollectionViewCell
        if let _ = cell {
            
            let dict = infarctAreaHistoryArray[indexPath.row] as! NSMutableDictionary
            let url = "\(ecgPath)/\((Patient.sharedInfo.patientInfo?.caseID)!)/\((dict.valueForKey("ecgName") as! String))"
           
            let fileName = self.getECGFileName(url)
            cell!.ecgButtonOutlet.setTitle(fileName, forState: UIControlState.Normal)
            cell!.bottomLineLabel.hidden = true
            cell?.ecgButtonOutlet.setTitleColor(UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0 / 255.0, alpha: 0.40), forState: UIControlState.Normal)
        }
        if indexPath.row == selectedCellIndex {
            cell!.bottomLineLabel.hidden = false
            cell?.ecgButtonOutlet.setTitleColor(UIColor.whiteColor(), forState: UIControlState.Normal)
            
        }
        cell?.ecgButtonOutlet.addTarget(self, action: #selector(ecgButtonTapped), forControlEvents: .TouchUpInside)
        cell?.ecgButtonOutlet.tag = indexPath.row
        return cell!
    }
}

// MARK: - @IBAction Methods
extension ECGHistoryViewController {
    
    @IBAction func retryButtonClick(sender: AnyObject) {
        
        let dict = infarctAreaHistoryArray[selectedCellIndex] as? NSMutableDictionary
        let url = "\(ecgPath)/\((Patient.sharedInfo.patientInfo?.caseID)!)/\((dict?.valueForKey("ecgName") as! String))"
        downloadECGImage(url)
    }
}
// MARK: - TableView Datasourse methods
extension  ECGHistoryViewController:UITableViewDataSource {
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if isOtherComments {
            if indexPath.section == self.infractAreaArray.count - 1 {
                let cell = tableView.dequeueReusableCellWithIdentifier(ECGHistoryConstants.InfractAreaCellWithTextViewIdentifier.rawValue, forIndexPath: indexPath) as! ECGHistoryInfarctAreaCellTableViewCell
                configureOtherCommentsCell(cell, indexPath: indexPath)
                return cell
            }
        }
        
        
        let cell = tableView.dequeueReusableCellWithIdentifier(ECGHistoryConstants.InfarctAreaCellIdentifier.rawValue, forIndexPath: indexPath) as! ECGHistoryInfarctAreaCellTableViewCell
        
        configureCell(cell, indexPath: indexPath)
        return cell
    }
    func configureCell(cell: ECGHistoryInfarctAreaCellTableViewCell, indexPath: NSIndexPath) {
        cell.infractAreaNameLabel.text = self.infractAreaArray[indexPath.section] as? String
        let infractAreaDict = self.infractAreaArray.objectAtIndex(indexPath.section)
        cell.infractAreaNameLabel.text = infractAreaDict.valueForKey("InfractAreaName") as? String
        cell.STNameLabel.text = infractAreaDict.valueForKey("STElevationName") as? String
        cell.STNameLabel.lineBreakMode = .ByTruncatingTail
        cell.STNameLabel.numberOfLines = 1
        self.view.layoutIfNeeded()
    }
    
    func configureOtherCommentsCell(cell: ECGHistoryInfarctAreaCellTableViewCell, indexPath: NSIndexPath) {
        cell.otherCommentsTextView.text = otherCommentsText
        cell.infractAreaNameLabel.text = ECGHistoryConstants.OtherCommentsLabel.rawValue
        cell.otherCommentsTextView.userInteractionEnabled = false
        normalizeOtherCommentsTextView(cell.otherCommentsTextView)
    }
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return UIView()
    }
    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 6
    }
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return self.infractAreaArray.count
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if isOtherComments {
            if indexPath.section == self.infractAreaArray.count - 1 {
                return CGFloat(infractAreaRowHeight) + 70
            }
        }
        return CGFloat(infractAreaRowHeight)
    }
    
}
