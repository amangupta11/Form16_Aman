//  MEDTabBarController.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
class MEDTabBarController: UITabBarController {
    let notificationTabIndex = 1

//MARK: Notification handling start
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        NSNotificationCenter.defaultCenter().addObserver(
            self,
            selector: #selector(receivedNotification),
            name: StringConstants.RemoteNotification,
            object: nil)
    }
    
    func receivedNotification(notification: NSNotification) {
        let notification = notification.object as! Notification
        updateBadge(notification.badge)
        if UIApplication.sharedApplication().applicationState != .Active{
            navigateToNotificationSummary()
        }
    }
    
    private func navigateToNotificationSummary()
    {
        self.selectedIndex = notificationTabIndex
        if let notifNavController = notificationNavController()
        {
            notifNavController.popToRootViewControllerAnimated(true)
            if let notifVC = notificationVC()
            {
                notifVC.loadData()
            }
        }
    }
    
    func updateBadge(badge: Int)
    {
        UIApplication.sharedApplication().applicationIconBadgeNumber = badge
        if(self.tabBar.items?.count > notificationTabIndex)
        {
            let tabItem : UITabBarItem = self.tabBar.items![notificationTabIndex]
            tabItem.badgeValue = badge > 0 ? String(badge) : nil
        }
    }
    
    private func notificationNavController() -> UINavigationController?
    {
        if self.viewControllers == nil && self.viewControllers!.count <= notificationTabIndex{
            return nil}
        return self.viewControllers![notificationTabIndex] as? UINavigationController;
    }
    
    private func notificationVC() -> MEDNotificationViewController?
    {
        if let notifNavController = notificationNavController(){
            if notifNavController.viewControllers.first is MEDNotificationViewController
            {
                return notifNavController.viewControllers.first as? MEDNotificationViewController
            }
        }
        return nil
    }
    
    deinit {
        NSNotificationCenter.defaultCenter().removeObserver(self, name: StringConstants.RemoteNotification, object: nil)
    }
    //MARK: Notification handling end
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addSeparatorLinesToTabBar()
        MEDNotificationViewController.unreadCount { (badge) in
            self.updateBadge(badge)
        }
    }
    
    func stopDownloadingImages(navCntrl : UINavigationController) {
        for viewController in navCntrl.viewControllers{
            if viewController.isKindOfClass(MEDOnCallCardioDiagnosisVC){
                (viewController as! MEDOnCallCardioDiagnosisVC).stopDownloadingImage()
                return
            }
//            if viewController.isKindOfClass(MEDCardiologistECGViewController){
//                (viewController as! MEDCardiologistECGViewController).stopDownloadingImage()
//                return
//            }
        }
    }
    override func tabBar(tabBar: UITabBar, didSelectItem item: UITabBarItem) {
        //This method will be called when user changes tab.
        if self.selectedIndex == 0 {
            let homeNavController =  self.viewControllers?.first as! UINavigationController
            self.stopDownloadingImages(homeNavController)
            let homeController = homeNavController.viewControllers.first as! MEDHomeViewController
            homeNavController.popToViewController(homeController, animated: false)
            if item.tag == 1 {
                homeController.stopRefreshingTable()
                UIView.animateWithDuration(0.2, animations: {
                    
                    homeController.homeScreenListTable.contentOffset = CGPoint(x: 0, y: 0)
                })
            }
        }
        else if self.selectedIndex == notificationTabIndex{
            if let notifNavController = notificationNavController(){
                self.stopDownloadingImages(notifNavController)
                notifNavController.popToRootViewControllerAnimated(false)
            }
            if let notifVC = self.notificationVC(){
                notifVC.scrollToTop()
            }
        }
        MEDNotificationViewController.unreadCount { (badge) in
            self.updateBadge(badge)
        }
    }
    
    
}


// MARK: - Custom Actions
extension MEDTabBarController {
    private func addSeparatorLinesToTabBar() {
        if let items = self.tabBar.items {
            let height = CGRectGetHeight(self.tabBar.bounds)
            let numItems = CGFloat(items.count)
            let itemSize = CGSize(width: tabBar.frame.width / numItems, height: tabBar.frame.height)
            UITabBar.appearance().selectionIndicatorImage = UIImage().makeImageWithColorAndSize(UIColor.init(red: 104/255, green: 177/255, blue: 211/255, alpha: 1), size: itemSize)
            for (index, _) in items.enumerate() {
                if index > 0 {
                    let xPosition = itemSize.width * CGFloat(index)
                    let separator = UIView(frame: CGRect(x: xPosition, y: 0, width: 0.8, height: height))
                    separator.backgroundColor = UIColor.init(red: 38/255, green: 62/255, blue: 97/255, alpha: 1)
                    tabBar.insertSubview(separator, atIndex: 1)
                }
            }
        }
    }
}
extension UIImage {
    func makeImageWithColorAndSize(color: UIColor, size: CGSize) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(size, false, 0)
        color.setFill()
        UIRectFill(CGRectMake(0, 0, size.width, size.height))
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
}
