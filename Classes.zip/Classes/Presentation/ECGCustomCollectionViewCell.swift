//  ECGCustomCollectionViewCell.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

class ECGCustomCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var bottomLineLabel: UILabel!

    @IBOutlet weak var ecgButtonOutlet: UIButton!
}
