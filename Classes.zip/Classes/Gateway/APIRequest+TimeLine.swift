//
//  APIRequest+TimeLine.swift
//  Medtronic
//
//  Created by Chandrika Bhat on 15/11/16.
//  Copyright © 2016 Medtronic. All rights reserved.
//

import Foundation
import SwiftyJSON
extension APIRequest {

    // MARK: - Time Line Functions
    func getTimeLineInfo(caseid caseid: String, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(getTimeLine, isCookieTobeAdded:false)
        let dictionary = [StringConstants.CaseID:caseid]
        do {
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(dictionary,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response:response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response:response)
                } else {
                    // Success
                    completion(jsonString:json, successful:true, error:nil, response:response)
                }
            }
        }
    }
    // MARK: - getCaseTimelineDetails
    func getCaseTimelineDetails(dictionary dictionary: NSDictionary, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(getCaseTimelines, isCookieTobeAdded:true)
        do {
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(dictionary,
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response: response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response: response)
                } else {
                    // Success
                    completion(jsonString:json, successful:true, error:nil, response: response)
                }
            }
        }
    }
}
