//
//  APIRequest+Notification.swift
//  Medtronic
//
//  Created by Saurav Satpathy on 16/11/16.
//  Copyright © 2016 Medtronic. All rights reserved.
//

import Foundation
import SwiftyJSON

extension APIRequest {
    
    func requestNotification(completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(getNotifications, isCookieTobeAdded:true)
        do {
            if let userID = Patient.sharedInfo.userInfo?.userID{
                let userData = [StringConstants.AuthDetail :
                    [UserInfoKey.HospitalID.rawValue : String(),
                        StringConstants.HospitalIDs : [],
                        UserInfoKey.HospitalTypeID.rawValue : String(),
                        UserInfoKey.RoleID.rawValue : String(),
                        UserInfoKey.UserID.rawValue : userID as! String,
                        StringConstants.UserType : String()
                    ]]
                request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(userData,options: NSJSONWritingOptions.PrettyPrinted)
            }
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let notifError = error {
                completion(jsonString:nil, successful:false, error:notifError, response:response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response:response)
                } else {
                    completion(jsonString:json, successful:true, error:nil, response:response)
                }
            }
        }
    }
    
    func requestRead (notification: Notification,completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void)
    {
        let request = postJSONRequest(readNotification, isCookieTobeAdded:true)
        do {
            let body = [StringConstants.CaseID: notification.caseID, StringConstants.NotificationId: notification.notificationId, StringConstants.ReadStatus: notification.isRead]
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(body,options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let notifError = error {
                completion(jsonString:nil, successful:false, error:notifError, response:response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response:response)
                } else {
                    completion(jsonString:json, successful:true, error:nil, response:response)
                }
            }
        }
    }
    
    
    func requestUnreadCount (completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void)
    {
        let request = postJSONRequest(unreadCount, isCookieTobeAdded:true)
        do {            
            if let userID = Patient.sharedInfo.userInfo?.userID{
                  let body = [StringConstants.UserID: userID]
                  request.HTTPBody = try NSJSONSerialization.dataWithJSONObject(body,options: NSJSONWritingOptions.PrettyPrinted)
            }
        } catch {
            print("HTTPBody error:\n \(error)")
        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let notifError = error {
                completion(jsonString:nil, successful:false, error:notifError, response:response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response:response)
                } else {
                    completion(jsonString:json, successful:true, error:nil, response:response)
                }
            }
        }
    }
    
}
