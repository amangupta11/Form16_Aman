//  APIRequest+Login.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import SwiftyJSON
extension APIRequest {

    func getBundleVersion() -> String{
        var bdlVerStr = ""
        let dictionary = NSBundle.mainBundle().infoDictionary!
        if let bundleVerStr = dictionary[bundleConstants.BundleVersion] as? String{
            bdlVerStr = bundleVerStr
        }
        return bdlVerStr
    }
    
    // MARK: - Login Functions
    func requestLogin(username username: String, password: String, chanelId: String, completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(userLogin, isCookieTobeAdded:false)
        // Getting public key
        let hashedPassword = CryptoUtility.performHashing((password.dataUsingEncoding(NSUTF8StringEncoding))!)
        let dataofHashedPassword = (hashedPassword.dataUsingEncoding(NSUTF8StringEncoding))
        let base64 = dataofHashedPassword!.base64EncodedStringWithOptions([])
        let appVersion = self.getBundleVersion()
        let dictionary = [StringConstants.Username:username, StringConstants.Password:base64, StringConstants.ChannelID: chanelId,StringConstants.AppVersion :appVersion, StringConstants.Platform:StringConstants.IOS]
        do {
            request.HTTPBody = try NSJSONSerialization.dataWithJSONObject((dictionary),
                                                                          options: NSJSONWritingOptions.PrettyPrinted)
        } catch {
            print("HTTPBody error:\n \(error)")

        }
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response:response)
            } else {
                let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response:response)
                } else {
                    // Success
                    LoginManager.manageLoggedInUserData(json)
                    completion(jsonString:json, successful:true, error:nil, response:response)
                }
            }
        }
    }
    func getUserDetails(completion: (jsonString: JSON?, successful: Bool, error: NSError?, response: NSHTTPURLResponse?) -> Void) {
        let request = postJSONRequest(userDetails, isCookieTobeAdded:true)
        sendRequest(request) { (innerData, innerSuccessful, error, response) in
            if let loginError = error {
                completion(jsonString:nil, successful:false, error:loginError, response:response)
            } else { let json = JSON(data:innerData!)
                if json[ExceptionConstants.ExpnCode] {
                    // Failure
                    let logError = self.handleError(json)
                    completion(jsonString:nil, successful:false, error:logError, response:response)
                } else {
                    // Success
                    // this updates the record
                    PatientManager.updateDetailProfile(json)
                    completion(jsonString:json, successful:true, error:nil, response:response)
                }
            }
        }
    }
}
