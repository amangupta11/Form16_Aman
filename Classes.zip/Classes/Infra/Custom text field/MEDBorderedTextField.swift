//  MEDBorderedTextField.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
class MEDBorderedTextField: UITextField {
    var customBorder: CALayer!
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        customBorder = CALayer()
        let borderWidth = CGFloat(1.0)
        customBorder.borderColor = ColorPicker.warmGreyColor().CGColor
        customBorder.frame = CGRectMake(0, self.frame.size.height - borderWidth, self.frame.size.width, self.frame.size.height)
        customBorder.borderWidth = borderWidth
        self.layer.addSublayer(customBorder)
        self.layer.masksToBounds = true
    }
}
