//  CustomButton.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
class MEDSelectionCustomButton: UIButton {
    override var highlighted: Bool {
        didSet {
            if (highlighted) {
                self.alpha = 0.95
            } else {
                self.alpha = 1
            }
        }
    }
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
