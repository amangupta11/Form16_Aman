//  NetworkUtil.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import ReachabilitySwift
class NetworkUtil: NSObject {
  class  func isConnected() -> Bool {
        do {
            let reachability: Reachability = try Reachability.reachabilityForInternetConnection()
            let networkStatus: Int = reachability.currentReachabilityStatus.hashValue
            return (networkStatus != 0)
        } catch {
            return false
        }
    }
}
