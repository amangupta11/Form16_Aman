//  MEDCryptoUtility.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit

class CryptoUtility {
    
    private static let kPublicKeyIdentifier = "com.techendeavour.mdetronic.public"
    private static let kPrivateKeyIdentifier = "com.techendeavour.mdetronic.private"
    private static let kServerPublicKeyIdentifier = "com.techendeavour.mdetronic.serverpublic"
    private static var publicKeyJava : String?

    //MARK: - SHA256
    
    class func performHashing(data : NSData) -> String {
        let res = NSMutableData(length: Int(CC_SHA256_DIGEST_LENGTH))
        CC_SHA256(data.bytes, CC_LONG(data.length), UnsafeMutablePointer(res!.mutableBytes))
        var  result = "\(res!)".stringByReplacingOccurrencesOfString("", withString: "").stringByReplacingOccurrencesOfString(" ", withString: "")
        result = result.stringByReplacingOccurrencesOfString(">", withString: "")
        result = result.stringByReplacingOccurrencesOfString("<", withString: "")
        return result
    }

    class func encryptStringUsingAES(string: String, key: String) -> String {
       return AESWrapper.encryptTheText(string, key: key)
    }
    // MARK: - AES String Decryption

    class func decryptStringUsingAES(string: String, key: String) -> String {
      return  AESWrapper.decryptTheText(string, key: key)
    }

    // MARK: - AES File Encryption

    class func encryptTheFile(filePath: String) -> String{
        let image = UIImage(contentsOfFile: filePath)
        if image != nil {
        let imageData: NSData = UIImageJPEGRepresentation(image!, 0.8)!
        let encryptedData = AESWrapper.encryptTheData(imageData, key: (Patient.sharedInfo.patientInfo?.caseKey)!)
        do {
            let encryptedPath = Patient.sharedInfo.patientInfo?.ecgInfo?.localPath
            _ = try Bool(encryptedData.writeToFile(encryptedPath!, options: NSDataWritingOptions.DataWritingAtomic))
            return (Patient.sharedInfo.patientInfo?.ecgInfo?.localPath)!
        } catch let error as NSError {
            print(error.localizedDescription)
        }
        return (Patient.sharedInfo.patientInfo?.ecgInfo?.localPath)!
        } else {
        return (Patient.sharedInfo.patientInfo?.ecgInfo?.localPath)!
        }

    }
    // MARK: - AES File Decryption
    class func decryptTheFile(filePath: String, key: String) -> String {
        do {
        let encryptedImageData = try NSData(contentsOfFile: filePath, options: .DataReadingMapped)
            let decryptedImageData = AESWrapper.decryptTheData(encryptedImageData, key:key)
            let path = Patient.sharedInfo.patientInfo?.ecgInfo?.localPath!
            do {
                _ = try Bool(decryptedImageData.writeToFile(path!, options: NSDataWritingOptions.DataWritingAtomic))
                return path!
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        } catch let error as NSError {
         print(error.localizedDescription)
        }
        return filePath
    }
    
    class func decryptImage(filePath: String, key: String, patient: PatientCaseInfo) -> UIImage? {
        do {
        let encryptedImageData = try NSData(contentsOfFile: filePath, options: .DataReadingMapped)
            let decryptedImageData = AESWrapper.decryptTheData(encryptedImageData, key:key)
           return UIImage(data: decryptedImageData)
        } catch let error as NSError {
            print(error.localizedDescription)
        }
        return nil
    }
    
    // MARK: - RSA encryption/decryption
    
    class func generateRSAKeys()
    {
        RSA.sharedInstance().setIdentifierForPublicKey(kPublicKeyIdentifier, privateKey: kPrivateKeyIdentifier, serverPublicKey: kServerPublicKeyIdentifier)
        RSA.sharedInstance().generateKeyPairRSACompleteBlock {
            publicKeyJava = RSA.sharedInstance().getPublicKeyAsBase64ForJavaServer()
        }
    }
    
    class func publicKeyForJava () -> String {
        return publicKeyJava!
    }
    
    class func decryptString (caseKey: String?) -> String?{
        let data = NSData.init(base64EncodedString: caseKey!, options:.IgnoreUnknownCharacters)
        return RSA.sharedInstance().decryptUsingPrivateKeyWithData(data);
    }

}
