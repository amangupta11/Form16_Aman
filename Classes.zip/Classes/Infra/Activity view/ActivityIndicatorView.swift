//  MEDActivityIndicatorView.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import Foundation
import UIKit
public class ActivityIndicatorView {
    var overlayView: UIView?
    var activityIndicator = UIActivityIndicatorView()
    var loadingLabel = UILabel()
    struct ActivityIndicatorStringConstants {
        static var loadingLabel = "Loading..."
    }
    class var sharedActivityView: ActivityIndicatorView {
        struct Singleton {
            static let instance: ActivityIndicatorView = ActivityIndicatorView()
        }
        return Singleton.instance
    }
}
// MARK: - Custom Actions
extension ActivityIndicatorView {
    public func showOverlay() {
        if  let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate,
            let window = appDelegate.window {
            if (overlayView == nil) {
            overlayView = UIView()
            overlayView!.frame = CGRectMake(0, 0, window.frame.width, window.frame.height)
            overlayView!.center = CGPointMake(window.frame.width / 2.0, window.frame.height / 2.0)
            overlayView!.backgroundColor = UIColor.blackColor()
            overlayView!.alpha = 0.6
            overlayView!.clipsToBounds = true
            activityIndicator.frame = CGRect(x: 0, y: 0, width: 40, height: 40)
            activityIndicator.activityIndicatorViewStyle = .WhiteLarge
            activityIndicator.center = CGPointMake(overlayView!.bounds.width/2, overlayView!.bounds.height/2)
            loadingLabel.text = ActivityIndicatorStringConstants.loadingLabel
            loadingLabel.textColor = UIColor.init(red: 255/255, green: 255/255, blue: 255/255, alpha: 1.0)
            loadingLabel.sizeToFit()
            loadingLabel.center =  CGPointMake(overlayView!.bounds.width/2+loadingLabel.frame.size.width/8, overlayView!.bounds.height/2+47)
            loadingLabel.font = UIFont.init(name: "effra-regular", size: 16)
            overlayView!.addSubview(activityIndicator)
            overlayView!.addSubview(loadingLabel)
            window.addSubview(overlayView!)
            }
            activityIndicator.startAnimating()
        }
    }
    public func hideOverlayView() {
        if (overlayView != nil) {
            activityIndicator.stopAnimating()
            overlayView!.removeFromSuperview()
            overlayView = nil
        }
    }
}
