//  MEDColorPicker.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
class ColorPicker: NSObject {
    class func navigationDeepSeaBlueColor() -> UIColor {
        return UIColor(red: 0.0 / 255.0, green: 75.0 / 255.0, blue: 135.0 / 255.0, alpha: 1.0)
    }
    class func scarletColor() -> UIColor {
        return UIColor(red: 208.0 / 255.0, green: 2.0 / 255.0, blue: 27.0 / 255.0, alpha: 1.0)
    }
    class func warmGreyColor() -> UIColor {
        return UIColor(red: 151.0 / 255.0, green: 151.0 / 255.0, blue: 151.0 / 255.0, alpha: 1.0)
    }
    class func warmGreyColor2() -> UIColor {
        return UIColor(red: 151.0 / 255.0, green: 151.0 / 255.0, blue: 151.0 / 255.0, alpha: 0.49)

    }
    class func lightWarmGreyColor() -> UIColor {
        return UIColor(red: 151.0 / 255.0, green: 151.0 / 255.0, blue: 151.0 / 255.0, alpha: 0.2)
    }
    class func lightBlueColor() -> UIColor {
        return UIColor(red: 113/255, green: 197/255, blue: 232/255, alpha: 1)
    }
    class func pickerViewDoneButtonBackgroundColor() -> UIColor {
         return UIColor(red: 29.0 / 255.0, green: 133.0 / 255.0, blue: 200.0 / 255.0, alpha: 1.0)
    }
    class func pickerViewCancelButtonBackgroundColor() -> UIColor {
        return UIColor(red: 165.0 / 255.0, green: 165.0 / 255.0, blue: 165.0 / 255.0, alpha: 1.0)
    }
    class func pickerViewButtonTitleColor() -> UIColor {
        return UIColor.whiteColor()
    }
    class func transparentScreenBackgroundColor() -> UIColor {
        return UIColor(red: 0 / 255.0, green: 0 / 255.0, blue: 0 / 255.0, alpha: 0.2)
    }
    class func textFieldHighlightedColor() -> UIColor {
        return UIColor(red: 226.0 / 255.0, green: 75.0 / 255.0, blue: 1.0 / 255.0, alpha: 1.0)

    }
    class func lightBlackColor() -> UIColor {
        return UIColor(red: 70.0 / 255.0, green: 70.0 / 255.0, blue: 70.0 / 255.0, alpha: 1.0)

    }
    class func ligthGrey() -> UIColor {
        return UIColor(red: 179.0 / 255.0, green: 179.0 / 255.0, blue: 179.0 / 255.0, alpha: 1.0)

    }
    class func LightBlueGreyTwoColor() -> UIColor {
        return UIColor(red: 184.0 / 255.0, green: 217.0 / 255.0, blue: 235.0 / 255.0, alpha: 1.0)
    }
    class func shadowColor() -> UIColor {
        return UIColor(red: 0 / 255.0, green: 0 / 255.0, blue: 0.0 / 255.0, alpha: 0.22)
    }
    class func peaGreenColor() -> UIColor {
        return UIColor(red: 114.0 / 255.0, green: 186.0 / 255.0, blue: 23.0 / 255.0, alpha: 1.0)
    }
    class func charcoalGrey() -> UIColor {
        return UIColor(red: 75.0 / 255.0, green: 76.0 / 255.0, blue: 76.0 / 255.0, alpha: 1.0)
    }
    class func steelGreyColor() -> UIColor {
        return UIColor(red: 136.0 / 255.0, green: 139.0 / 255.0, blue: 141.0 / 255.0, alpha: 1.0)
    }
    class func silverColor() -> UIColor {
        return UIColor(red: 199.0 / 255.0, green: 199.0 / 255.0, blue: 205.0 / 255.0, alpha: 1.0)
    }
    class func warmGreyColorWithOpacity() -> UIColor {
        return UIColor(red: 151.0 / 255.0, green: 151.0 / 255.0, blue: 151.0 / 255.0, alpha: 0.2)
    }
    class func lightBlueGray2() -> UIColor {
        return UIColor(red: 184.0 / 255.0, green: 217.0 / 255.0, blue: 235.0 / 255.0, alpha: 1.0)
    }
    class func tealish() -> UIColor {
        return UIColor(red: 55.0 / 255.0, green: 204.0 / 255.0, blue: 190.0 / 255.0, alpha: 1.0)
    }
    class func warmGrey15() -> UIColor {
        return UIColor(red: 150.0 / 255.0, green: 150.0 / 255.0, blue: 150.0 / 255.0, alpha: 0.15)
    }
    class func Black22() -> UIColor {
        return UIColor(red: 0.0 / 255.0, green: 0.0 / 255.0, blue: 0.0 / 255.0, alpha: 0.22)
    }
    class func deepOrange() -> UIColor {
        return UIColor(red: 227.0 / 255.0, green: 82.0 / 255.0, blue: 3.0 / 255.0, alpha: 1.0)
    }
    class func yellowOrange() -> UIColor {
        return UIColor(red: 247.0 / 255.0, green: 168.0 / 255.0, blue: 2.0 / 255.0, alpha: 1.0)
    }
    class func appleGreen() -> UIColor {
        return UIColor(red: 119.0 / 255.0, green: 188.0 / 255.0, blue: 33.0 / 255.0, alpha: 1.0)
    }
    class func battleshipGrey() -> UIColor {
        return UIColor(red: 121.0 / 255.0, green: 123.0 / 255.0, blue: 125.0 / 255.0, alpha: 1.0)
    }
    class func fadedOrange() -> UIColor {
        return UIColor(red: 231.0 / 255.0, green: 131.0 / 255.0, blue: 78.0 / 255.0, alpha: 1.0)
    }
    class func greyishBrown() -> UIColor {
        return UIColor(white: 70.0 / 255.0, alpha: 1.0)
    }
    class func duckEggBlue() -> UIColor {
        return UIColor(red: 239.0 / 255.0, green: 248.0 / 255.0, blue: 253.0 / 255.0, alpha: 1.0)
    }
    class func whiteColorFade() -> UIColor {
        return UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0 / 255.0, alpha: 0.4)
    }
    class func toastMsgBackgroundColor()-> UIColor {
        return UIColor(red: 0.0 / 255.0, green: 0.0 / 255.0, blue: 0.0 / 255.0, alpha: 0.6)
    }

}
