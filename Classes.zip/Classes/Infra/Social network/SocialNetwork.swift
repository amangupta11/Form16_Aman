//  MEDSocialNetwork.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
class SocialNetwork: NSObject {
    // MARK: - Custom Actions
    class func makeCall(phoneNumber: String) {
        let formatedNumber = phoneNumber.componentsSeparatedByCharactersInSet(NSCharacterSet.decimalDigitCharacterSet().invertedSet).joinWithSeparator("")
        let phoneUrl = "tel://\("+" + formatedNumber)"
        let url: NSURL = NSURL(string: phoneUrl)!
        UIApplication.sharedApplication().openURL(url)
    }
}
