//  StringUtility.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
class StringUtility: NSObject {
    class func uniqueId() -> String {
        let uuid = NSUUID().UUIDString
        return uuid
    }
    class func checkForSpecialCharacters(string: String!) -> Bool {
        let userNameRegex = "[\\w\\d]{0,30}"
        let UserNameTest = NSPredicate(format:"SELF MATCHES %@", userNameRegex)
        return UserNameTest.evaluateWithObject(string)
    }
    class func strikeText(text: String) -> NSMutableAttributedString {
            let attributeString: NSMutableAttributedString =  NSMutableAttributedString(string:  text )
            attributeString.addAttribute(NSStrikethroughStyleAttributeName, value: 1, range: NSMakeRange(0, attributeString.length))
            return attributeString
    }
}
