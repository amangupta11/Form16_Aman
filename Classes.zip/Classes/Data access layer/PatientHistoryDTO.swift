//
//  PatientHistoryDTO.swift
//  Medtronic
//
//  Created by Praveen Ambekar on 6/8/17.
//  Copyright © 2017 Medtronic. All rights reserved.
//
import UIKit
class PatientHistoryDTO{
    var systolic: String?
    var diastolic: String?
    var pulse: String?
    var temperature: String?
    var uncleatECGComments: String?
    var spo2: String?
    var otherscomments: String?
    var editInfarctArea: Bool?
    var isFreshUpload: NSNumber?
    var killipScore: NSNumber?
    var anteroseptal: NSNumber?
    var anterior: NSNumber?
    var lateral: NSNumber?
    var extensiveanterolateral: NSNumber?
    var inferior: NSNumber?
    var posterior: NSNumber?
    var rightsided: NSNumber?
    var leftmainstem: NSNumber?
    var others: NSNumber?
    init(){
        self.others = 0
        self.leftmainstem = 0
        self.rightsided = 0
        self.posterior = 0
        self.inferior = 0
        self.anterior = 0
        self.lateral = 0
        self.anteroseptal = 0
        self.lateral = 0
        self.extensiveanterolateral = 0
        self.editInfarctArea = false
    }
}
