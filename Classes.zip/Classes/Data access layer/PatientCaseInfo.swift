//
//  PatientCaseInfo.swift
//  Medtronic
//
//  Created by Praveen Ambekar on 5/30/17.
//  Copyright © 2017 Medtronic. All rights reserved.
//

import UIKit
import SwiftyJSON
class PatientCaseInfo{
    var caseKey:String?
    var firstName:String?
    var middleName:String?
    var lastName:String?
    var gender:String?
    var age:String?
    var treatmentCenter:TreatmentCenter?
    var fmcCenter:FmcCentre?
    var hospitalCaseID:String?
    var caseStatus:Int?
    var caseID:String?
    var tempCaseID:String?
    var caseCreatedUserName:String?
    var mobileNumber:String?
    var countryCode:String?
    var icNoOrPassport:String?
    var citizenship:String?
    var citizenshipTypeID:String?
    var paymentType:String?
    var paymentTypeID: String?
    var ecgURL: String?
    var localPath: String?
    var ecgFileName: String?
    var ecgInfo:ECGInfoDTO?
    var patientHistory:PatientHistoryDTO?
    var timeLine:TimeLineDTO?
    var isCathLabReady: Bool?
    init(){
        self.patientHistory = PatientHistoryDTO()
        self.timeLine = TimeLineDTO()
        self.ecgInfo = ECGInfoDTO()
        self.isCathLabReady = false
        self.caseStatus = 1
    }
    func updatePatientData(jsonString: JSON)
    {
        if(jsonString != nil){
            if (jsonString[PatientInfoKey.CaseKey.rawValue] != nil){
                let caseKey = CryptoUtility.decryptString(jsonString[PatientInfoKey.CaseKey.rawValue].stringValue)
                self.caseKey = caseKey
            }
            if (jsonString[PatientInfoKey.CaseStatus.rawValue] != nil){
                self.caseStatus = jsonString[PatientInfoKey.CaseStatus.rawValue].intValue
            }
            if (jsonString[PatientInfoKey.CaseID.rawValue] != nil){
                self.caseID = jsonString[PatientInfoKey.CaseID.rawValue].stringValue
            }
            if (jsonString[PatientInfoKey.FirstName.rawValue] != nil){
                self.firstName = self.decryptText(caseKey!, textToDecrypt:jsonString[PatientInfoKey.FirstName.rawValue].stringValue)
            }
            if (jsonString[PatientInfoKey.MiddleName.rawValue] != nil){
                self.middleName = self.decryptText(caseKey!, textToDecrypt:jsonString[PatientInfoKey.MiddleName.rawValue].stringValue)
            }
            if (jsonString[PatientInfoKey.LastName.rawValue] != nil){
                self.lastName = self.decryptText(caseKey!, textToDecrypt:jsonString[PatientInfoKey.LastName.rawValue].stringValue)
            }
            if (jsonString[PatientInfoKey.Gender.rawValue] != nil){
                self.gender = self.decryptText(caseKey!, textToDecrypt:jsonString[PatientInfoKey.Gender.rawValue].stringValue)
            }
            if (jsonString[PatientInfoKey.CountryCode.rawValue] != nil){
                self.countryCode = self.decryptText(caseKey!, textToDecrypt:jsonString[PatientInfoKey.CountryCode.rawValue].stringValue)
            }
            if (jsonString[PatientInfoKey.MobileNumber.rawValue] != nil) {
                self.mobileNumber = self.decryptText(caseKey!, textToDecrypt: jsonString[PatientInfoKey.MobileNumber.rawValue].stringValue)
            }
            if (jsonString[PatientInfoKey.ICOrPassport.rawValue] != nil){
                self.icNoOrPassport = self.decryptText(caseKey!, textToDecrypt: jsonString[PatientInfoKey.ICOrPassport.rawValue].stringValue)
            }
            if (jsonString[PatientInfoKey.CitizenshipType.rawValue] != nil){
                self.citizenship = self.decryptText(caseKey!, textToDecrypt: jsonString[PatientInfoKey.CitizenshipType.rawValue].stringValue)
            }
            if (jsonString[PatientInfoKey.PaymentType.rawValue] != nil){
                self.paymentType = self.decryptText(caseKey!, textToDecrypt: jsonString[PatientInfoKey.PaymentType.rawValue].stringValue)
            }
            let addNewCaseTimeDict = jsonString[TimeLineKey.AddNewCaseTime.rawValue].dictionaryObject!
            let addNewtimeLineDetailList = addNewCaseTimeDict[TimeLineKey.TimeLineDetailList.rawValue] as! [AnyObject]
            let addNewtimeLineArr = addNewtimeLineDetailList[0]
            self.timeLine?.addNewCaseTime = addNewtimeLineArr[TimeLineKey.Time.rawValue] as? NSTimeInterval
            
            let fmcDoorInTimeDict = jsonString[TimeLineKey.FmcDoorInTime.rawValue].dictionaryObject!
            let timeLineDetailList = fmcDoorInTimeDict[TimeLineKey.TimeLineDetailList.rawValue] as! [AnyObject]
            let timeLineArr = timeLineDetailList[0]
            self.timeLine?.fmcDoorInTime = timeLineArr[TimeLineKey.Time.rawValue] as? NSTimeInterval
            
            if (jsonString["treatmentCenter"] != nil){
                let treatmentCenter = TreatmentCenter()
                treatmentCenter.updateTreamentCenterInfo(jsonString["treatmentCenter"])
                self.treatmentCenter = treatmentCenter
            }
            if (jsonString["fmcCenter"] != nil){
                let fmcCenter = FmcCentre()
                fmcCenter.updateFMCInfo(jsonString["fmcCenter"])
                self.fmcCenter = fmcCenter
            }
            self.hospitalCaseID = jsonString[PatientInfoKey.HospitalCaseID.rawValue].stringValue
            self.caseCreatedUserName = jsonString["caseCreatedUserName"].stringValue
        }
    }
    var json: JSON {
        get {
            var dictionary: [String:AnyObject] = [:]
            dictionary[PatientInfoKey.Age.rawValue] = self.age
            dictionary[PatientInfoKey.CaseID.rawValue] = self.caseID
            dictionary[PatientInfoKey.TempCaseID.rawValue] = self.tempCaseID
            if let caseStatus = self.caseStatus{
               dictionary[PatientInfoKey.CaseStatus.rawValue] = String(caseStatus)
            }
            if(self.mobileNumber != "") {
                dictionary[PatientInfoKey.CountryCode.rawValue] = self.countryCode
                dictionary[PatientInfoKey.MobileNumber.rawValue] = self.mobileNumber
            }
            dictionary[PatientInfoKey.FirstName.rawValue] = self.firstName
            dictionary[PatientInfoKey.Gender.rawValue] = self.gender
            dictionary[PatientInfoKey.LastName.rawValue] = self.lastName
            dictionary[PatientInfoKey.MiddleName.rawValue] = self.middleName
            dictionary[PatientInfoKey.ICOrPassport.rawValue] = self.icNoOrPassport
            if (self.citizenship != nil) {
                var citizenship: [String:AnyObject] = [:]
                citizenship[PatientInfoKey.Value.rawValue] = self.citizenship
                citizenship[PatientInfoKey.ID.rawValue] = self.citizenshipTypeID
                dictionary[PatientInfoKey.CitizenshipType.rawValue] = citizenship
            }
            if (self.paymentType != nil) {
                var paymentType: [String:AnyObject] = [:]
                paymentType[PatientInfoKey.Value.rawValue] = self.paymentType
                paymentType[PatientInfoKey.ID.rawValue] = self.paymentTypeID
                dictionary[PatientInfoKey.PaymentType.rawValue] = paymentType
            }
            var timeLine: [String:AnyObject] = [:]
            timeLine[TimeLineKey.Comment.rawValue] = nil
            timeLine[TimeLineKey.Location.rawValue] = nil
    
            if let onSetTime = self.timeLine?.onSetTime{
                timeLine[TimeLineKey.Time.rawValue] =  String(NSNumber(double: onSetTime))
                dictionary[TimeLineKey.OnsetTime.rawValue] = timeLine
            }
            if let triageTime = self.timeLine?.triageTime {
                timeLine[TimeLineKey.Time.rawValue] = String(NSNumber(double: triageTime))
                dictionary[TimeLineKey.TriageTime.rawValue] = timeLine
            }
            if let addNewCaseTime = self.timeLine?.addNewCaseTime {
                timeLine[TimeLineKey.Time.rawValue] = String(NSNumber(double: addNewCaseTime))
                dictionary[TimeLineKey.AddNewCaseTime.rawValue] = timeLine
            }
            if let fmcDoorInTime = self.timeLine?.fmcDoorInTime {
                timeLine[TimeLineKey.Time.rawValue] = String(NSNumber(double: fmcDoorInTime))
                dictionary[TimeLineKey.FmcDoorInTime.rawValue] = timeLine
            }
            let json = JSON(dictionary)
            return json
        }
    }
    var vitalSignsJson: JSON {
        get {
            var dictionary: [String:AnyObject] = [:]
            dictionary[PatientInfoKey.CaseID.rawValue] = self.caseID
            dictionary[PatientInfoKey.CaseStatus.rawValue] = self.caseStatus
            if (self.patientHistory?.systolic != nil) {
                var vitalSigns: [String:AnyObject] = [:]
                vitalSigns[PatientHistoryInfoKey.Systolic.rawValue] = self.patientHistory?.systolic
                vitalSigns[PatientHistoryInfoKey.Diastolic.rawValue] = self.patientHistory?.diastolic
                vitalSigns[PatientHistoryInfoKey.Pulse.rawValue] = self.patientHistory?.pulse
                vitalSigns[PatientHistoryInfoKey.Temperature.rawValue] = self.patientHistory?.temperature
                vitalSigns[PatientHistoryInfoKey.Spo2.rawValue] = self.patientHistory?.spo2
                vitalSigns[PatientHistoryInfoKey.KillipScore.rawValue] = self.patientHistory?.killipScore
                dictionary[PatientHistoryInfoKey.VitalSigns.rawValue] = vitalSigns
                dictionary["versioningNeeded"] = self.patientHistory?.editInfarctArea?.boolValue
            }
            let json = JSON(dictionary)
            return json
        }
    }
    var infactAreaJson: JSON {
        get {
            var dictionary: [String:AnyObject] = [:]
            dictionary[PatientInfoKey.CaseID.rawValue] = self.caseID
            dictionary[PatientInfoKey.CaseStatus.rawValue] = self.caseStatus
            
            var timeLine: [String:AnyObject] = [:]
            timeLine[TimeLineKey.Comment.rawValue] = nil
            timeLine[TimeLineKey.Location.rawValue] = nil
            timeLine[TimeLineKey.Time.rawValue] = self.timeLine?.stemiTime
            dictionary[TimeLineKey.StemiTime.rawValue] = timeLine
            
            timeLine[TimeLineKey.Time.rawValue] = self.timeLine?.notAStemiTime
            dictionary[TimeLineKey.NotAStemiTime.rawValue] = timeLine
            
            timeLine[TimeLineKey.Time.rawValue] = self.timeLine?.diagnoseECGTime
            dictionary[TimeLineKey.DiagnoseECGTime.rawValue] = timeLine
            
            timeLine[TimeLineKey.Time.rawValue] = self.timeLine?.diagnoseTime
            dictionary[TimeLineKey.DaignoseTime.rawValue] = timeLine
            
            timeLine[TimeLineKey.Comment.rawValue] = self.patientHistory?.uncleatECGComments
            timeLine[TimeLineKey.Time.rawValue] = self.timeLine?.unclearECGTime
            dictionary[TimeLineKey.UnclearECGTime.rawValue] = timeLine
            
            timeLine[TimeLineKey.Comment.rawValue] = nil
            dictionary[TimeLineKey.FreshUpload.rawValue] = self.patientHistory?.isFreshUpload
            dictionary["versioningNeeded"] = self.patientHistory?.editInfarctArea?.boolValue
            if  self.timeLine?.diagnoseTime != 0 {
                dictionary[TimeLineKey.DiagnoseAsStemi.rawValue] = self.timeLine?.isStemi?.boolValue
            }
            var infarctArea: [String:AnyObject] = [:]
            infarctArea[ECGInfoKey.EcgURL.rawValue] = self.ecgInfo?.ecgURL
            infarctArea[ECGInfoKey.EcgName.rawValue] = self.ecgInfo?.ecgFileName
            infarctArea[PatientHistoryInfoKey.Anteroseptal.rawValue] = self.patientHistory?.anteroseptal?.boolValue
            infarctArea[PatientHistoryInfoKey.Anterior.rawValue] = self.patientHistory?.anterior?.boolValue
            infarctArea[PatientHistoryInfoKey.Lateral.rawValue] = self.patientHistory?.lateral?.boolValue
            infarctArea[PatientHistoryInfoKey.ExtensiveAnterolateral.rawValue] = self.patientHistory?.extensiveanterolateral?.boolValue
            infarctArea[PatientHistoryInfoKey.Inferior.rawValue] = self.patientHistory?.inferior?.boolValue
            infarctArea[PatientHistoryInfoKey.Posterior.rawValue] = self.patientHistory?.posterior?.boolValue
            infarctArea[PatientHistoryInfoKey.RightSided.rawValue] = self.patientHistory?.rightsided?.boolValue
            infarctArea[PatientHistoryInfoKey.Others.rawValue] = self.patientHistory?.others?.boolValue
            infarctArea[PatientHistoryInfoKey.LeftMainStem.rawValue] = self.patientHistory?.leftmainstem?.boolValue
            infarctArea[PatientHistoryInfoKey.Comments.rawValue] = self.patientHistory?.otherscomments != nil ? self.patientHistory?.otherscomments : ""
            dictionary[PatientHistoryInfoKey.InfarctAreas.rawValue] = infarctArea
            let json = JSON(dictionary)
            return json
        }
    }
    func decryptText(decryptedCaseKey: String, textToDecrypt : String) -> String
    {
        var decryptedText:String = textToDecrypt
        decryptedText = AESWrapper.decryptTheText(textToDecrypt, key: decryptedCaseKey)
        return decryptedText
    }
}