import Foundation
import UIKit
import SwiftyJSON
public class Patient{
    
    var patientInfo:PatientCaseInfo?
    var userInfo:UserInfoDTO?
    class var sharedInfo: Patient {
        struct Singleton {
            static let instance = Patient()
        }
        return Singleton.instance
    }
}
