//
//  ECGInfoDTO.swift
//  Medtronic
//
//  Created by Praveen Ambekar on 6/9/17.
//  Copyright © 2017 Medtronic. All rights reserved.
//

import UIKit

class ECGInfoDTO {
    var ecgURL:String?
    var localPath: String?
    var ecgFileName: String?
}
