//
//  TimeLineDTO.swift
//  Medtronic
//
//  Created by Praveen Ambekar on 6/8/17.
//  Copyright © 2017 Medtronic. All rights reserved.
//

import UIKit

class TimeLineDTO {
    
    var isStemi: NSNumber?
    var firstECGTime: NSTimeInterval?
    var stemiTime: NSTimeInterval?
    var notAStemiTime: NSTimeInterval?
    var hubInternalTransferTime: NSTimeInterval?
    var triageTime:NSTimeInterval?
    var firstEcgCaptureTime:NSTimeInterval?
    var diagnoseECGTime:NSTimeInterval?
    var diagnoseTime:NSTimeInterval?
    var unclearECGTime:NSTimeInterval?
    var activateStemiTime:NSTimeInterval?
    var notActivateStemiTime:NSTimeInterval?
    var caseTransferTime:NSTimeInterval?
    var fmcDoorOutTime:NSTimeInterval?
    var hubDoorInTime:NSTimeInterval?
    var cathlabAcceptedTime:NSTimeInterval?
    var deviceCrossTime:NSTimeInterval?
    var timerStopTime:NSTimeInterval?
    var cathlabExitTime:NSTimeInterval?
    var caseCompleteTime:NSTimeInterval?
    var notStemiTime:NSTimeInterval?
    var presentingComplaintTime:NSTimeInterval?
    var cathLabReadyToAcceptCaseTime:NSTimeInterval?
    var cancelTreatmentTime:NSTimeInterval?
    var onSetTime : NSTimeInterval?
    var spokeTransferTime: NSTimeInterval?
    var onsetEditedText: String?
    var onsetEditCount: String?
    var fmcDoorInEditCount: String?
    var fmcDoorInEditedText: String?
    var fmcDoorOutEditCount: String?
    var fmcDoorOutEditedText: String?
    var triageEditedText: String?
    var triageEditCount: String?
    var fmcDoorInTime : NSTimeInterval?
    var addNewCaseTime : NSTimeInterval?
    var stoppedTime: NSTimeInterval?
    var cathLabAcceptedTime: NSTimeInterval?
    var cathLabExitTime: NSTimeInterval?
    var cathLabAcceptedEditedText: String?
    var cathLabAcceptedEditCount: String?
    var deviceCrossTimeEditedText: String?
    var deviceCrossTimeEditCount: String?
    var cathLabExitEditedText: String?
    var cathLabExitEditCount: String?
    var treatmentCompletedTime: NSTimeInterval?
    var hubDoorInEditCount:String?
    var hubDoorInEditedText:String?
    init(){
        self.onsetEditedText = "0"
        self.onsetEditCount = "0"
        self.fmcDoorInEditCount = "0"
        self.fmcDoorInEditedText = "0"
        self.fmcDoorOutEditCount = "0"
        self.fmcDoorOutEditedText = "0"
        self.triageEditedText = "0"
        self.triageEditCount = "0"
        self.hubDoorInEditCount = "0"
        self.hubDoorInEditedText = "0"
        self.cathLabAcceptedEditedText = "0"
        self.cathLabAcceptedEditCount = "0"
        self.deviceCrossTimeEditedText = "0"
        self.deviceCrossTimeEditCount = "0"
        self.cathLabExitEditedText = "0"
        self.cathLabExitEditCount = "0"
        
        self.stemiTime = 0
        self.notAStemiTime = 0
        self.diagnoseECGTime = 0
        self.diagnoseTime = 0
        self.unclearECGTime = 0
        self.spokeTransferTime = 0
        self.hubDoorInTime = 0
        self.cathLabAcceptedTime = 0
        self.cathLabExitTime = 0
        self.deviceCrossTime = 0
        self.cathLabReadyToAcceptCaseTime = 0
        self.treatmentCompletedTime = 0
        self.fmcDoorOutTime = 0
        self.hubInternalTransferTime = 0
    }
}
