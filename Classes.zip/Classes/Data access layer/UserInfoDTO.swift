import UIKit

class UserInfoDTO{
    var countryCode:NSObject?
    var emailAddress:NSObject?
    var firstName:NSObject?
    var gender:String?
    var hospitalID:String?
    var hospitalName:String?
    var hospitalTypeID:String?
    var lastName:NSObject?
    var passcode:NSObject?
    var password:NSObject?
    var phoneNumber:NSObject?
    var profilePicURL:String?
    var roleID:String?
    var title:String?
    var accessToken:NSObject?
    var expiresIn:NSObject?
    var userID:NSObject?
    var username:NSObject?
    var refreshToken:NSObject?
    var uuID:NSObject?
    var designation:String?
}
