

import UIKit
import SwiftyJSON
class FmcCentre {
    var abbreviation: String?
    var addressLine1: String?
    var addressLine2: String?
    var availableCapacity: NSNumber?
    var city: String?
    var country: String?
    var countryCode: String?
    var hospitalID: String?
    var hospitalName: String?
    var hospitalType: String?
    var lattitude: String?
    var longitude: String?
    var phoneNumber: String?
    var reasonForDelay: String?
    var state: String?
    var zipCode: String?
    var consultant: String?
    func updateFMCInfo(jsonString: JSON) {
        if(jsonString != nil){
        self.abbreviation = jsonString["abbreviation"].stringValue
        self.consultant = jsonString["consultant"].stringValue
        self.hospitalName = jsonString["hospitalName"].stringValue
        self.hospitalID = jsonString["hospitalID"].stringValue
        }
    }
}