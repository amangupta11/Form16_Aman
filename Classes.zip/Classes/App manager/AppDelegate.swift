//  AppDelegate.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import UIKit
import Fabric
import Crashlytics
import Firebase
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    var notificationManager: NotificationManager?
    let  kServerSessionTimeoutInMinutes = 18
    var timeoutTimer: NSTimer!
    var idletimer: NSTimer!
    var refreshScreen : Bool = false
    var isCameraOpen : Bool = false
    var currentCaseStatus = Int()
    
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        initialSetup()
        return true
    }
    func applicationWillResignActive(application: UIApplication) {
        self.window?.hidden = true
    }
    func applicationDidEnterBackground(application: UIApplication) {
        application.ignoreSnapshotOnNextApplicationLaunch()
    }
    func applicationWillEnterForeground(application: UIApplication) {
        NSNotificationCenter.defaultCenter().postNotificationName(UIApplicationWillEnterForegroundNotification, object:nil)
    }
    func applicationDidBecomeActive(application: UIApplication) {
        self.window?.hidden = false
    }
    func applicationWillTerminate(application: UIApplication) {
        notificationManager!.stop()
    }
    func initialSetup() {
        let firebase = FireBaseManager()
        firebase.setUpFireBase()
      
        Fabric.with([Crashlytics.self])
        PatientManager.clearCache { (successful) in
        }
        createECGImageDirectory()
        notificationManager = NotificationManager()
        notificationManager?.register()
        CryptoUtility.generateRSAKeys()
        Patient.sharedInfo.userInfo = UserInfoDTO()
    }
    func  createECGImageDirectory() {
        FileUtility.createECGFolder()
    }
  }
