
import UIKit
import Foundation

class SessionManager: UIApplication {
    
    private var accessTokenExpiry: Int = 0
    private var idleTimer: NSTimer!
    private var elapsedIdleTime: Int = 0
    private var elapsedExtensionTime: Int = 0
    
    override func sendEvent(event: UIEvent) {
        super.sendEvent(event)
        if isTouchEvent(event) {
            if accessTokenExpiry > 0
            {
                elapsedIdleTime = 0
            }
        }
    }
    
    private func isTouchEvent(event: UIEvent) -> Bool {
        return event.type == .Touches
    }
    
    private func startIdleTimer() {
        accessTokenExpiry = accessTokenExpiresIn()
        if accessTokenExpiry > 0
        {
            idleTimer = NSTimer.scheduledTimerWithTimeInterval(1.0,
                                                               target: self,
                                                               selector:#selector(SessionManager.timerTicked),
                                                               userInfo: nil,
                                                               repeats: true)
        }
    }
    
    func timerTicked()
    {
        elapsedIdleTime += 1
        elapsedExtensionTime += 1
        if (elapsedIdleTime > accessTokenExpiry)
        {
            timedOut()
            return
        }
        if shouldGetNewToken()
        {
            self.extendAccessToken()
            elapsedExtensionTime = 0
        }
    }
    
    private func stopIdleTimer() {
        if let _ = idleTimer {
            elapsedIdleTime = 0
            elapsedExtensionTime = 0
            idleTimer.invalidate()
        }
    }
    
    func resetIdleTimer()
    {
        stopIdleTimer()
        startIdleTimer()
    }
    
    private func shouldGetNewToken() -> Bool
    {
        let extensionTime = Int((accessTokenExpiry * 90)/100)
        return elapsedExtensionTime == extensionTime
    }
    
    func timedOut() {
        dispatch_async(dispatch_get_main_queue(), {
            self.stopIdleTimer()
            self.showTimoutAlert()
        })
    }
    
    private func accessTokenExpiresIn() -> Int
    {
        var expiresIn = 0
            if Patient.sharedInfo.userInfo!.expiresIn != nil &&  (Patient.sharedInfo.userInfo!.expiresIn as! String).characters.count > 0
            {
                expiresIn = Int(Patient.sharedInfo.userInfo!.expiresIn as! String)!
            }
        return expiresIn
    }
    
    func extendAccessToken()
    {
        APIRequest.sharedAPI.extendAccessToken { (jsonString, successful, error, response) in
            dispatch_async(dispatch_get_main_queue(), {
                if !successful && jsonString == nil{
                    return
                }
                if Patient.sharedInfo.userInfo != nil{
                    Patient.sharedInfo.userInfo!.accessToken = jsonString![StringConstants.AccessToken].stringValue
                    var tokenType  = jsonString![StringConstants.TokenType].stringValue
                    tokenType = tokenType.stringByAppendingString(" \(Patient.sharedInfo.userInfo!.accessToken!)")
                    Patient.sharedInfo.userInfo!.accessToken = tokenType
                    Patient.sharedInfo.userInfo!.refreshToken = jsonString![StringConstants.refreshToken].stringValue
                    Patient.sharedInfo.userInfo!.expiresIn = jsonString![StringConstants.ExpiresIn].stringValue
                }
            })
        }
    }
    
    func showTimoutAlert() {
        dispatch_async(dispatch_get_main_queue(), {
            let application = UIApplication.sharedApplication().delegate!
            let navigation = application.window!!.rootViewController as! UINavigationController
            let login = navigation.viewControllers.last as! MEDLoginViewController
            if let tabBar = login.presentedViewController as? MEDTabBarController{
                let alertController = UIAlertController(title: APIRequestsConstants.Attention, message: APIRequestsConstants.SessionExpMessage, preferredStyle: .Alert)
                let defaultAction = UIAlertAction(title: NSLocalizedString("OK", comment: ""), style: .Default) {
                    UIAlertAction in
                    self.navigateToLogin()
                    alertController.dismissViewControllerAnimated(true, completion: nil)
                }
                alertController.addAction(defaultAction)
                if tabBar.presentedViewController is UIAlertController
                {
                    tabBar.presentedViewController?.dismissViewControllerAnimated(false, completion: { 
                        tabBar.presentViewController(alertController, animated: true, completion: nil)
                    })
                }
                else
                {
                    tabBar.presentViewController(alertController, animated: true, completion: nil)
                }
            }
        })
    }
    
    func navigateToLogin(){
        dispatch_async(dispatch_get_main_queue(), {
            let notificationManager = NotificationManager()
            notificationManager.stop()
            self.stopIdleTimer()
            let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
            appDelegate.window?.rootViewController?.dismissViewControllerAnimated(false, completion: nil)
        })
    }
    
    
}
