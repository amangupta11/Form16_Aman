//
//  DecryptionManager.swift
//  Medtronic
//
//  Created by Ankur Jain on 18/11/16.
//  Copyright © 2016 Medtronic. All rights reserved.
//

import UIKit
import SwiftyJSON
class DecryptionManager: NSObject {
//    let caseKey = json[PatientInfoKey.CaseKey.rawValue].stringValue
//    if (caseKey != "") {
//    if (json[PatientHistoryInfoKey.VitalSigns.rawValue].array != nil) {
//
//    let dictJson = json[PatientHistoryInfoKey.VitalSigns.rawValue].array?.first
//    patientHistory.systolic = AESWrapper.decryptTheText(String(dictJson! [PatientHistoryInfoKey.Systolic.rawValue].stringValue), key: caseKey)

    class func decryptECGInfarctAreaDetails(json: JSON, caseKey: String, completion: (decryptedArray: NSMutableArray?, error: NSError?) -> Void) {
    // Decrypt the data
    let encryptedCaseKey = caseKey
    if (encryptedCaseKey != "") {
    let caseKey = CryptoUtility.decryptString(encryptedCaseKey)
    if caseKey != ""{
    let infarctAreaArray = json.array
    let decryptedArray = NSMutableArray()
    for i in 0..<infarctAreaArray!.count {
    let dict = NSMutableDictionary()
    dict.setValue(AESWrapper.decryptTheText(infarctAreaArray![i]["ecgUrl"].stringValue, key: caseKey!), forKey: "ecgUrl")
    dict.setValue(AESWrapper.decryptTheText(infarctAreaArray![i]["ecgName"].stringValue, key: caseKey!), forKey: "ecgName")
    dict.setValue( AESWrapper.decryptTheText(infarctAreaArray![i]["anteroseptal"].stringValue, key: caseKey!), forKey: "anteroseptal")
    dict.setValue( AESWrapper.decryptTheText(infarctAreaArray![i]["anterior"].stringValue, key: caseKey!), forKey: "anterior")
    dict.setValue(  AESWrapper.decryptTheText(infarctAreaArray![i]["lateral"].stringValue, key: caseKey!), forKey: "lateral")
    dict.setValue(  AESWrapper.decryptTheText(infarctAreaArray![i]["extensiveAnterolateral"].stringValue, key: caseKey!), forKey: "extensiveAnterolateral")
    dict.setValue( AESWrapper.decryptTheText(infarctAreaArray![i]["inferior"].stringValue, key: caseKey!), forKey: "inferior")
    dict.setValue( AESWrapper.decryptTheText(infarctAreaArray![i]["posterior"].stringValue, key: caseKey!), forKey: "posterior")
    dict.setValue( AESWrapper.decryptTheText(infarctAreaArray![i]["rightSided"].stringValue, key: caseKey!), forKey: "rightSided")
    dict.setValue( AESWrapper.decryptTheText(infarctAreaArray![i]["leftMainStem"].stringValue, key: caseKey!), forKey: "leftMainStem")
    dict.setValue(  AESWrapper.decryptTheText(infarctAreaArray![i]["others"].stringValue, key: caseKey!), forKey: "others")
     dict.setValue( AESWrapper.decryptTheText(infarctAreaArray![i]["comment"].stringValue, key: caseKey!), forKey: "comment")

    // Adding decrypted info to decrypted array
    decryptedArray.addObject(dict)
    }

    completion(decryptedArray: decryptedArray, error: nil)
   }
  }
    // Case key is nil
   }
    class func decryptMedicalConditons(json: JSON, caseKey: String, completion: (decryptedDict: NSMutableDictionary?, error: NSError?) -> Void){
        let encryptedCaseKey = json[PatientInfoKey.CaseKey.rawValue].stringValue
        if (encryptedCaseKey != "") {
            let caseKey = CryptoUtility.decryptString(encryptedCaseKey)
            if caseKey != ""{
                let jsonDict =  json.dictionary
                let decryptedDict = NSMutableDictionary()
                let medicalConditionArray = jsonDict?[StringConstants.MedicalHistoryConditions]?.array
                let medicationArray = jsonDict?[StringConstants.PatientMedications]?.array
                let medicalHistoryImagesArray = jsonDict?[StringConstants.MedicalHistoryImages]?.array
                let decryptedConditionArray = NSMutableArray()
                let decryptedmedicationArray = NSMutableArray()
                let decryptedMedicalHistoryImagesArray = NSMutableArray()
                if medicationArray != nil{
                    for condition in medicationArray!{
                        let medicationDict = NSMutableDictionary()
                        medicationDict.setValue(AESWrapper.decryptTheText((condition[StringConstants.MedicineKey].string)!, key: caseKey!), forKey: StringConstants.MedicineKey)
                        medicationDict.setValue(AESWrapper.decryptTheText((condition[StringConstants.MedicineDescription].string)!, key: caseKey!), forKey: StringConstants.MedicineDescription)
                        medicationDict.setValue(AESWrapper.decryptTheText((condition[StringConstants.MedicineDose].string)!, key: caseKey!), forKey: StringConstants.MedicineDose)
                        decryptedmedicationArray.addObject(medicationDict)
                    }
                    decryptedDict.setValue(decryptedmedicationArray, forKey: StringConstants.PatientMedications)
                }
                if medicalConditionArray != nil{
                    for condition in medicalConditionArray!{
                        let condtionString =   AESWrapper.decryptTheText(condition.string!, key: caseKey!)
                        decryptedConditionArray.addObject(condtionString)
                    }
                    decryptedDict.setValue(decryptedConditionArray, forKey: StringConstants.MedicalHistoryConditions)
                }
                if let notes = jsonDict!["medicalHistoryNotes"]?.string{
                    decryptedDict.setValue(AESWrapper.decryptTheText(notes, key: caseKey!), forKey: "medicalHistoryNotes")
                }
                if medicalHistoryImagesArray != nil{
                    for condition in medicalHistoryImagesArray!{
                        let medicalHistoryImagesDict = NSMutableDictionary()
                        if(condition[StringConstants.Name].string != nil){
                            medicalHistoryImagesDict.setValue(AESWrapper.decryptTheText((condition[StringConstants.Name].string)!, key: caseKey!), forKey: StringConstants.Name)
                        }
                        if(condition[StringConstants.Url].string != nil){
                            medicalHistoryImagesDict.setValue(AESWrapper.decryptTheText((condition[StringConstants.Url].string)!, key: caseKey!), forKey: StringConstants.Url)
                        }
                        if(condition[StringConstants.ImageCaptureTime].dictionary != nil){
                            let dict = condition[StringConstants.ImageCaptureTime].dictionary
                            let time = dict![StringConstants.Time]?.string
                            medicalHistoryImagesDict.setValue(AESWrapper.decryptTheText(time!, key: caseKey!), forKey: StringConstants.ImageCaptureTime)
                        }
                        decryptedMedicalHistoryImagesArray.addObject(medicalHistoryImagesDict)
                    }
                    decryptedDict.setValue(decryptedMedicalHistoryImagesArray, forKey: StringConstants.MedicalHistoryImages)
                }
                completion(decryptedDict: decryptedDict, error: nil)
            }
            
        }
    }
    
    class func decryptClinicalExaminations(json: JSON, caseKey: String, completion: (decryptedDict: NSMutableDictionary?, error: NSError?) -> Void){
        let encryptedCaseKey = json[PatientInfoKey.CaseKey.rawValue].stringValue
        if (encryptedCaseKey != "") {
        let caseKey = CryptoUtility.decryptString(encryptedCaseKey)
        if caseKey != ""{
            let jsonDict =  json.dictionary
            let decryptedDict = NSMutableDictionary()
            
            let primaryComplaintDict = NSMutableDictionary()
            if let primaryComplaintTempDict = jsonDict![PatientHistoryInfoKey.PrimaryComplaint.rawValue]?.dictionary{
                
                if let id =  primaryComplaintTempDict[PatientHistoryInfoKey.Id.rawValue]?.intValue{
                    primaryComplaintDict.setValue(id, forKey: PatientHistoryInfoKey.Id.rawValue)
                }
                
                if let value = primaryComplaintTempDict[PatientHistoryInfoKey.Value.rawValue]?.string{
                    primaryComplaintDict.setValue(value, forKey: PatientHistoryInfoKey.Value.rawValue)
                }
                decryptedDict.setValue(primaryComplaintDict, forKey: PatientHistoryInfoKey.PrimaryComplaint.rawValue)
            }
            
            decryptedDict.setValue(jsonDict![PatientHistoryInfoKey.Description.rawValue]?.string, forKey: PatientHistoryInfoKey.Description.rawValue)
            
            
            if json [PatientHistoryInfoKey.Time.rawValue].dictionary != nil {
            var array = json [PatientHistoryInfoKey.Time.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            let onsetDateTimeString = DateUtility.convertGMTtoLongDate(firstEdit!)
            decryptedDict.setValue(onsetDateTimeString, forKey: PatientHistoryInfoKey.Time.rawValue)
            }
            
            let vitalSignsDict = NSMutableDictionary()
            
            if let vitalSignsEncryptedDict = jsonDict![PatientHistoryInfoKey.VitalSigns.rawValue]?.dictionary{
                
                if let patientSystolic = vitalSignsEncryptedDict[PatientHistoryInfoKey.Systolic.rawValue]?.string{
                    vitalSignsDict.setValue(Int(AESWrapper.decryptTheText(patientSystolic, key: caseKey!)), forKey: PatientHistoryInfoKey.Systolic.rawValue)
                }
                
                if let patientDiastolic = vitalSignsEncryptedDict[PatientHistoryInfoKey.Diastolic.rawValue]?.string{
                    vitalSignsDict.setValue(Int(AESWrapper.decryptTheText(patientDiastolic, key: caseKey!)), forKey: PatientHistoryInfoKey.Diastolic.rawValue)
                }
                
                if let patientPulse = vitalSignsEncryptedDict[PatientHistoryInfoKey.Pulse.rawValue]?.string{
                    vitalSignsDict.setValue(Int(AESWrapper.decryptTheText(patientPulse, key: caseKey!)), forKey: PatientHistoryInfoKey.Pulse.rawValue)
                }
                
                if let patientBodyTemperature = vitalSignsEncryptedDict[PatientHistoryInfoKey.Temperature.rawValue]?.string{
                    vitalSignsDict.setValue(Double(AESWrapper.decryptTheText(patientBodyTemperature, key: caseKey!)), forKey: PatientHistoryInfoKey.Temperature.rawValue)
                }
                
                if let patientSpO2 = vitalSignsEncryptedDict[PatientHistoryInfoKey.Spo2.rawValue]?.string{
                    vitalSignsDict.setValue(Int(AESWrapper.decryptTheText(patientSpO2, key: caseKey!)), forKey: PatientHistoryInfoKey.Spo2.rawValue)
                }
                
                if let killipScore = vitalSignsEncryptedDict[PatientHistoryInfoKey.KillipScore.rawValue]?.string{
                    vitalSignsDict.setValue(Int(AESWrapper.decryptTheText(killipScore, key: caseKey!)), forKey: PatientHistoryInfoKey.KillipScore.rawValue)
                }
                
                decryptedDict.setValue(vitalSignsDict, forKey: PatientHistoryInfoKey.VitalSigns.rawValue)
            }
            
            decryptedDict.setValue(jsonDict![PatientHistoryInfoKey.patientEstimatedWeight.rawValue]?.double, forKey: PatientHistoryInfoKey.patientEstimatedWeight.rawValue)
            decryptedDict.setValue(jsonDict![PatientHistoryInfoKey.patientTroponin.rawValue]?.intValue, forKey: PatientHistoryInfoKey.patientTroponin.rawValue)
            decryptedDict.setValue(jsonDict![PatientHistoryInfoKey.patientPointOfFMC.rawValue]?.intValue, forKey: PatientHistoryInfoKey.patientPointOfFMC.rawValue)
            completion(decryptedDict: decryptedDict, error: nil)
        }
    }
    }
}
