//
//  TimeLineManager.swift
//  Medtronic
//
//  Created by Praveen Ambekar on 6/23/17.
//  Copyright © 2017 Medtronic. All rights reserved.
//

import UIKit
import SwiftyJSON
class TimeLineManager{
    class func updateCaseTime(json : JSON?){
        if (json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.OnsetTime.rawValue].dictionary != nil){
            self.updateOnSetTime(json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.OnsetTime.rawValue])
        }
        else if(json?[TimeLineKey.OnsetTime.rawValue].dictionary != nil){
            self.updateOnSetTime(json?[TimeLineKey.OnsetTime.rawValue])
        }
        if (json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.FmcDoorInTime.rawValue].dictionary != nil){
            self.updateFmcDoorInTime(json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.FmcDoorInTime.rawValue])
        }
        else if(json?[TimeLineKey.FmcDoorInTime.rawValue].dictionary != nil){
            self.updateFmcDoorInTime(json?[TimeLineKey.FmcDoorInTime.rawValue])
        }
        if (json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.TriageTime.rawValue].dictionary != nil){
            self.updateTriageTime(json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.TriageTime.rawValue])
        }
        if (json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.UnclearECGTime.rawValue].dictionary != nil){
            self.updateUnclearECGTimeComment(json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.UnclearECGTime.rawValue])
        }
        if (json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.StemiTime.rawValue].dictionary != nil){
            self.updateSTEMITime(json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.StemiTime.rawValue])
        }
        if (json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.DiagnoseECGTime.rawValue].dictionary != nil){
            self.updateDiagnoseECGTime(json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.DiagnoseECGTime.rawValue])
        }
        if (json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.FmcDoorOutTime.rawValue].dictionary != nil){
            self.updateFmcDoorOutTime(json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.FmcDoorOutTime.rawValue])
        }
        if (json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.HubDoorInTime.rawValue].dictionary != nil){
            self.updateHubDoorInTime(json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.HubDoorInTime.rawValue])
        }
        if (json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.SpokeTransferTime.rawValue].dictionary != nil){
            self.updateSpokeTransferTime(json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.SpokeTransferTime.rawValue])
        }
        if (json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.HubInternalTransferTime.rawValue].dictionary != nil){
            self.updateHubInternalTransferTime(json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.HubInternalTransferTime.rawValue])
        }
        if (json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.CathLabAcceptedTime.rawValue].dictionary != nil){
            self.updateCathLabAcceptedTime(json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.CathLabAcceptedTime.rawValue])
        }
        if (json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.DeviceCrossTime.rawValue].dictionary != nil){
            self.updateDeviceCrossTime(json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.DeviceCrossTime.rawValue])
        }
        if (json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.CathLabExitTime.rawValue].dictionary != nil){
            self.updateCathLabExitTime(json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.CathLabExitTime.rawValue])
        }
        if (json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.TreatmentCompletedTime.rawValue].dictionary != nil){
            self.updateTreatmentCompletedTime(json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.TreatmentCompletedTime.rawValue])
        }
        if (json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.StoppedTime.rawValue].dictionary != nil){
            self.updateStoppedTime(json?[TimeLineKey.CaseTimeLines.rawValue][TimeLineKey.StoppedTime.rawValue])
        }
    }

    class func updateOnSetTime(json: JSON?){
        var array = json?[TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        if array?.count == 1{
            Patient.sharedInfo.patientInfo?.timeLine?.onsetEditCount = String(format:"%@","0")
        }
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            Patient.sharedInfo.patientInfo?.timeLine?.onsetEditCount = String(format:"%@",
                                                                              "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                Patient.sharedInfo.patientInfo?.timeLine?.onsetEditCount = String(format:"%@",
                                                                                  "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                Patient.sharedInfo.patientInfo?.timeLine?.onsetEditCount = String(format:"%@",
                                                                                  "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    Patient.sharedInfo.patientInfo?.timeLine?.onsetEditCount = String(format:"%@",
                                                                                      "3")
                }
            }
        }
        Patient.sharedInfo.patientInfo?.timeLine?.onsetEditedText  = editedText
        timeDict =  array![0].dictionary
        Patient.sharedInfo.patientInfo?.timeLine?.onSetTime = timeDict![TimeLineKey.Time.rawValue]?.double
        
    }
    
    class func updateFmcDoorInTime(json: JSON?){
        var array = json?[TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        if array?.count == 1{
            Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInEditCount = String(format:"%@","0")
        }
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInEditCount = String(format:"%@",
                                                                                  "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInEditCount = String(format:"%@",
                                                                                      "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInEditCount = String(format:"%@",
                                                                                      "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInEditCount = String(format:"%@",
                                                                                          "3")
                }
            }
        }
        Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInEditedText  = editedText
        timeDict =  array![0].dictionary
        Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorInTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }
    class func updateFmcDoorOutTime(json: JSON?){
        var array = json?[TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        if array?.count == 1{
            Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutEditCount = String(format:"%@","0")
        }
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutEditCount = String(format:"%@",
                                                                                   "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutEditCount = String(format:"%@",
                                                                                       "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutEditCount = String(format:"%@",
                                                                                       "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutEditCount = String(format:"%@",
                                                                                           "3")
                }
            }
        }
        Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutEditedText  = editedText
        timeDict =  array![0].dictionary
        Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }
    
    class func updateTriageTime(json: JSON?) {
        var array = json?[TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        
        if array?.count == 1{
            Patient.sharedInfo.patientInfo?.timeLine?.triageEditCount = String(format:"%@","0")
        }
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            Patient.sharedInfo.patientInfo?.timeLine?.triageEditCount = String(format:"%@",
                                                                               "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                Patient.sharedInfo.patientInfo?.timeLine?.triageEditCount = String(format:"%@",
                                                                                   "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                Patient.sharedInfo.patientInfo?.timeLine?.triageEditCount = String(format:"%@",
                                                                                   "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    Patient.sharedInfo.patientInfo?.timeLine?.triageEditCount = String(format:"%@",
                                                                                       "3")
                }
            }
        }
        Patient.sharedInfo.patientInfo?.timeLine?.triageEditedText  = editedText
        timeDict =  array![0].dictionary
        Patient.sharedInfo.patientInfo?.timeLine?.triageTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }

    class func updateHubDoorInTime(json: JSON?) {
        var array = json?[TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        
        if array?.count == 1{
            Patient.sharedInfo.patientInfo?.timeLine?.hubDoorInEditCount = String(format:"%@","0")
        }
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            Patient.sharedInfo.patientInfo?.timeLine?.hubDoorInEditCount = String(format:"%@",
                                                                                  "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                Patient.sharedInfo.patientInfo?.timeLine?.hubDoorInEditCount = String(format:"%@",
                                                                                      "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                Patient.sharedInfo.patientInfo?.timeLine?.hubDoorInEditCount = String(format:"%@",
                                                                                      "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    Patient.sharedInfo.patientInfo?.timeLine?.hubDoorInEditCount = String(format:"%@",
                                                                                          "3")
                }
            }
        }
        Patient.sharedInfo.patientInfo?.timeLine?.hubDoorInEditedText  = editedText
        timeDict =  array![0].dictionary
        Patient.sharedInfo.patientInfo?.timeLine?.hubDoorInTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }

    class func updateCathLabAcceptedTime(json: JSON?) {
        var array = json?[TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        
        if array?.count == 1{
            Patient.sharedInfo.patientInfo?.timeLine?.cathLabAcceptedEditCount = String(format:"%@","0")
        }
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            Patient.sharedInfo.patientInfo?.timeLine?.cathLabAcceptedEditCount = String(format:"%@",
                                                                                        "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                Patient.sharedInfo.patientInfo?.timeLine?.cathLabAcceptedEditCount = String(format:"%@",
                                                                                            "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                Patient.sharedInfo.patientInfo?.timeLine?.cathLabAcceptedEditCount = String(format:"%@",
                                                                                            "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    Patient.sharedInfo.patientInfo?.timeLine?.cathLabAcceptedEditCount = String(format:"%@",
                                                                                                "3")
                }
            }
        }
        Patient.sharedInfo.patientInfo?.timeLine?.cathLabAcceptedEditedText  = editedText
        timeDict =  array![0].dictionary
        Patient.sharedInfo.patientInfo?.timeLine?.cathLabAcceptedTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }
    class func updateCathLabExitTime(json: JSON?) {
        var array = json?[TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        
        if array?.count == 1{
            Patient.sharedInfo.patientInfo?.timeLine?.cathLabExitEditCount = String(format:"%@","0")
        }
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            Patient.sharedInfo.patientInfo?.timeLine?.cathLabExitEditCount = String(format:"%@",
                                                                                    "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                Patient.sharedInfo.patientInfo?.timeLine?.cathLabExitEditCount = String(format:"%@",
                                                                                        "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                Patient.sharedInfo.patientInfo?.timeLine?.cathLabExitEditCount = String(format:"%@",
                                                                                        "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    Patient.sharedInfo.patientInfo?.timeLine?.cathLabExitEditCount = String(format:"%@",
                                                                                            "3")
                }
            }
        }
        Patient.sharedInfo.patientInfo?.timeLine?.cathLabExitEditedText  = editedText
        timeDict =  array![0].dictionary
        Patient.sharedInfo.patientInfo?.timeLine?.cathLabExitTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }
    class func updateDeviceCrossTime(json: JSON?) {
        var array = json?[TimeLineKey.TimeLineDetailList.rawValue].array
        var editedText: String?
        var  timeDict:[String:JSON]?
        
        if array?.count == 1{
            Patient.sharedInfo.patientInfo?.timeLine?.deviceCrossTimeEditCount = String(format:"%@","0")
        }
        if array?.count > 1 {
            timeDict =  array![(array?.count)!-1].dictionary
            let firstEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            Patient.sharedInfo.patientInfo?.timeLine?.deviceCrossTimeEditCount = String(format:"%@",
                                                                                        "0")
            if firstEdit != nil {
                editedText = String(format:"%@",
                                    DateUtility.convertGMTtoShortTime(firstEdit!))
                Patient.sharedInfo.patientInfo?.timeLine?.deviceCrossTimeEditCount = String(format:"%@",
                                                                                            "1")
            }
        }
        if array?.count > 2 {
            timeDict =  array![(array?.count)!-2].dictionary
            let secondEdit = timeDict![TimeLineKey.Time.rawValue]?.double
            if secondEdit != nil {
                editedText = editedText! + " " +  DateUtility.convertGMTtoShortTime(secondEdit!)
                Patient.sharedInfo.patientInfo?.timeLine?.deviceCrossTimeEditCount = String(format:"%@",
                                                                                            "2")
            }
            if array?.count > 3 {
                timeDict =  array![(array?.count)!-3].dictionary
                let thirdEdit = timeDict![TimeLineKey.Time.rawValue]?.double
                
                if thirdEdit != nil {
                    editedText = editedText! + " "  +  DateUtility.convertGMTtoShortTime(thirdEdit!)
                    Patient.sharedInfo.patientInfo?.timeLine?.deviceCrossTimeEditCount = String(format:"%@",
                                                                                                "3")
                }
            }
        }
        Patient.sharedInfo.patientInfo?.timeLine?.deviceCrossTimeEditedText  = editedText
        timeDict =  array![0].dictionary
        Patient.sharedInfo.patientInfo?.timeLine?.deviceCrossTime = timeDict![TimeLineKey.Time.rawValue]?.double
    }
    class func updateDiagnoseECGTime(json: JSON?){
        var array = json?[TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict:[String:JSON]? = array?[0].dictionary
        Patient.sharedInfo.patientInfo?.timeLine?.diagnoseECGTime = timeDict?[TimeLineKey.Time.rawValue]?.double
    }
    class func updateSTEMITime(json: JSON?){
        var array = json?[TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict:[String:JSON]? = array?[0].dictionary
        Patient.sharedInfo.patientInfo?.timeLine?.stemiTime = timeDict?[TimeLineKey.Time.rawValue]?.double
    }
    class func updateUnclearECGTimeComment(json: JSON?){
        var array = json?[TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict:[String:JSON]? = array?[0].dictionary
        Patient.sharedInfo.patientInfo?.patientHistory?.uncleatECGComments = timeDict?["comment"]?.string
    }
    class func updateStoppedTime(json: JSON?){
        var array = json?[TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict:[String:JSON]? = array?[0].dictionary
        Patient.sharedInfo.patientInfo?.timeLine?.stoppedTime = timeDict?[TimeLineKey.Time.rawValue]?.double
    }
    class func updateTreatmentCompletedTime(json: JSON?){
        var array = json?[TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict:[String:JSON]? = array?[0].dictionary
        Patient.sharedInfo.patientInfo?.timeLine?.treatmentCompletedTime = timeDict?[TimeLineKey.Time.rawValue]?.double
    }
    class func updateSpokeTransferTime(json: JSON?){
        var array = json?[TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict:[String:JSON]? = array?[0].dictionary
        Patient.sharedInfo.patientInfo?.timeLine?.spokeTransferTime = timeDict?[TimeLineKey.Time.rawValue]?.double
    }
    class func updateHubInternalTransferTime(json: JSON?){
        var array = json?[TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict:[String:JSON]? = array?[0].dictionary
        Patient.sharedInfo.patientInfo?.timeLine?.hubInternalTransferTime = timeDict?[TimeLineKey.Time.rawValue]?.double
    }
}
extension TimeLineManager{
    class func updateCaseTimeLine(json: JSON) -> (NSMutableArray, NSString) {
        var timelineArray: NSMutableArray
        var timelineDate: NSString = ""
        timelineArray = NSMutableArray()
        if (json [TimeLineKey.OnsetTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.OnsetTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            timelineDate = DateUtility.convertGMTtoShortDate(time!)
        }
        if (json [TimeLineKey.FmcDoorInTime.rawValue].dictionary  != nil) {
            parseFmcDoorInTime(timelineArray, json: json)
        }
        parseDiagnoseAndUnclearECGTime(timelineArray, json:json)
        
        if (json [TimeLineKey.DaignoseTime.rawValue].dictionary  != nil) {
            parseDiagnosedTime(timelineArray, json: json)
        }
        if (json [TimeLineKey.StemiTime.rawValue].dictionary  != nil) {
            parseStemiTime(timelineArray, json: json)
        }
        if (json [TimeLineKey.SpokeTransferTime.rawValue].dictionary  != nil) {
            parseSpokeTransferTime(timelineArray, json: json)
        }
        if (json [TimeLineKey.FmcDoorOutTime.rawValue].dictionary  != nil) {
            parseFmcDoorOutTime(timelineArray, json: json)
        }
        if (json [TimeLineKey.HubDoorInTime.rawValue].dictionary  != nil) {
            parseHubDoorInTime(timelineArray, json: json)
        }
        if (json [TimeLineKey.HubInternalTransferTime.rawValue].dictionary  != nil) {
            parseHubInternalTransferTime(timelineArray, json: json)
        }
        parseCathlabTimeline(timelineArray, json:json)
        if (json [TimeLineKey.CancelTreatmentTime.rawValue].dictionary  != nil) {
            parseCancelTreatmentTime(timelineArray, json: json)
        }
        return (timelineArray, timelineDate)
    }
    class func parseDiagnosedTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.DaignoseTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.Diagnosed
        setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseStemiTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.StemiTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.STEMI
        setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseSpokeTransferTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.SpokeTransferTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.InTransit
        setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseFmcDoorOutTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.FmcDoorOutTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.FMCDoorOut
        setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseCancelTreatmentTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.CancelTreatmentTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let comment = timeDict![TimeLineKey.Comment.rawValue]?.string
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.TreatmentCancelled
        setValueToDict(timelineName, comment: comment!, timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseHubDoorInTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.HubDoorInTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.DoorinatHub
        setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseHubInternalTransferTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.HubInternalTransferTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.InternalTransfer
        setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseFmcDoorInTime(timelineArray:NSMutableArray, json:JSON){
        let timelineDict = NSMutableDictionary()
        var array = json [TimeLineKey.FmcDoorInTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
        var  timeDict =  array![0].dictionary
        let time = timeDict![TimeLineKey.Time.rawValue]?.double
        let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
        let timelineDate = DateUtility.convertGMTtoShortDate(time!)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
        let timelineName = CaseTimelineStringConstants.FMCDoorin as String
        setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
        timelineArray.addObject(timelineDict)
    }
    class func parseUndiagnosedTime(timelineArray:NSMutableArray,diagnoseECGTimeArray:NSMutableArray, i:Int){
        let timelineDictForUnDiag = NSMutableDictionary()
        let timeDict = diagnoseECGTimeArray[i] as! NSDictionary
        let time = timeDict[CaseTimelineKey.Time.rawValue] as! Double
        let hospitalType = timeDict[CaseTimelineKey.HospitalType.rawValue] as! String
        let timelineDate = DateUtility.convertGMTtoShortDate(time)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time)
        let timelineName = CaseTimelineStringConstants.Undiagnosed
        setValueForUndiagnosedTimeToDict(timelineName, timelineDate: timelineDate, timelineTime: timelineTime, time: time, hospitalType: hospitalType, timelineDict: timelineDictForUnDiag)
        timelineArray.addObject(timelineDictForUnDiag)
    }
    class func parseunclearECGTime(timelineArray:NSMutableArray,unclearECGTimeArray:NSMutableArray, i:Int){
        let timelineDictUnClr = NSMutableDictionary()
        let timeDict = unclearECGTimeArray[i] as! NSDictionary
        let time = timeDict[CaseTimelineKey.Time.rawValue] as! Double
        let hospitalType = timeDict[CaseTimelineKey.HospitalType.rawValue] as! String
        let timelineDate = DateUtility.convertGMTtoShortDate(time)
        let timelineTime = DateUtility.convertGMTto24HrFormatTime(time)
        let timelineName = CaseTimelineStringConstants.UnderObservation
        setValueForUndiagnosedTimeToDict(timelineName, timelineDate: timelineDate, timelineTime: timelineTime, time: time, hospitalType: hospitalType, timelineDict: timelineDictUnClr)
        timelineArray.addObject(timelineDictUnClr)
    }
    
    
    class func parseDiagnoseAndUnclearECGTime(timelineArray:NSMutableArray, json: JSON){
        var diagnoseECGTimeArray : NSMutableArray
        var unclearECGTimeArray : NSMutableArray
        diagnoseECGTimeArray = NSMutableArray()
        unclearECGTimeArray = NSMutableArray()
        if (json [TimeLineKey.DiagnoseECGTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.DiagnoseECGTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            for i in (0..<array!.count).reverse(){
                let timelineDict = NSMutableDictionary()
                var  timeDict =  array![i].dictionary
                let time = timeDict![TimeLineKey.Time.rawValue]?.double
                let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
                timelineDict[CaseTimelineKey.Time.rawValue] = time
                timelineDict[CaseTimelineKey.HospitalType.rawValue] = String(hospitalType!)
                diagnoseECGTimeArray.addObject(timelineDict)
            }
        }
        if (json [TimeLineKey.UnclearECGTime.rawValue].dictionary  != nil) {
            var array = json [TimeLineKey.UnclearECGTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            for i in (0..<array!.count).reverse(){
                let timelineDict = NSMutableDictionary()
                var  timeDict =  array![i].dictionary
                let time = timeDict![TimeLineKey.Time.rawValue]?.double
                let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
                timelineDict[CaseTimelineKey.Time.rawValue] = time
                timelineDict[CaseTimelineKey.HospitalType.rawValue] = String(hospitalType!)
                unclearECGTimeArray.addObject(timelineDict)
            }
        }
        if(diagnoseECGTimeArray.count > 0){
            for i in 0..<diagnoseECGTimeArray.count{
                parseUndiagnosedTime(timelineArray, diagnoseECGTimeArray: diagnoseECGTimeArray, i: i)
                if((unclearECGTimeArray.count>0) && (i<unclearECGTimeArray.count)){
                    parseunclearECGTime(timelineArray, unclearECGTimeArray: unclearECGTimeArray, i: i)
                }
            }
        }
    }
    
    class func parseCathlabTimeline(timelineArray:NSMutableArray, json: JSON){
        if (json [TimeLineKey.CathLabAcceptedTime.rawValue].dictionary  != nil) {
            let timelineDict = NSMutableDictionary()
            var array = json [TimeLineKey.CathLabAcceptedTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
            let timelineDate = DateUtility.convertGMTtoShortDate(time!)
            let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
            let timelineName = CaseTimelineStringConstants.CathLabAccepted
            setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
            timelineArray.addObject(timelineDict)
        }
        if (json [TimeLineKey.DeviceCrossTime.rawValue].dictionary  != nil) {
            let timelineDict = NSMutableDictionary()
            var array = json [TimeLineKey.DeviceCrossTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
            let timelineDate = DateUtility.convertGMTtoShortDate(time!)
            let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
            let timelineName = CaseTimelineStringConstants.DeviceCrossTime
            setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
            timelineArray.addObject(timelineDict)
        }
        if (json [TimeLineKey.CathLabExitTime.rawValue].dictionary  != nil) {
            let timelineDict = NSMutableDictionary()
            var array = json [TimeLineKey.CathLabExitTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
            let timelineDate = DateUtility.convertGMTtoShortDate(time!)
            let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
            let timelineName = CaseTimelineStringConstants.CathLabExit
            setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
            timelineArray.addObject(timelineDict)
        }
        if (json [TimeLineKey.TreatmentCompletedTime.rawValue].dictionary  != nil) {
            let timelineDict = NSMutableDictionary()
            var array = json [TimeLineKey.TreatmentCompletedTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            let hospitalType = timeDict![TimeLineKey.Location.rawValue]?.int
            let timelineDate = DateUtility.convertGMTtoShortDate(time!)
            let timelineTime = DateUtility.convertGMTto24HrFormatTime(time!)
            let timelineName = CaseTimelineStringConstants.CaseCompleted
            setValueToDict(timelineName, comment: "", timelineDate: timelineDate, timelineTime: timelineTime, time: time!, hospitalType: hospitalType!, timelineDict: timelineDict)
            timelineArray.addObject(timelineDict)
        }
    }
    
    class func setValueToDict(timelineName:String, comment: String, timelineDate:String,timelineTime:String,time:Double,hospitalType:Int,timelineDict:NSMutableDictionary){
        timelineDict[CaseTimelineKey.TimelineName.rawValue] = timelineName
        timelineDict[CaseTimelineKey.TimelineDate.rawValue] = timelineDate
        timelineDict[CaseTimelineKey.TimelineTime.rawValue] = timelineTime
        timelineDict[CaseTimelineKey.Time.rawValue] = time as Double
        timelineDict[CaseTimelineKey.Comment.rawValue] = comment
        timelineDict[CaseTimelineKey.HospitalType.rawValue] = String(hospitalType)
    }
    class func setValueForUndiagnosedTimeToDict(timelineName:String, timelineDate:String,timelineTime:String,time:Double,hospitalType:String,timelineDict:NSMutableDictionary){
        timelineDict[CaseTimelineKey.TimelineName.rawValue] = timelineName
        timelineDict[CaseTimelineKey.TimelineDate.rawValue] = timelineDate
        timelineDict[CaseTimelineKey.TimelineTime.rawValue] = timelineTime
        timelineDict[CaseTimelineKey.Time.rawValue] = time as Double
        timelineDict[CaseTimelineKey.HospitalType.rawValue] = String(hospitalType)
    }
}