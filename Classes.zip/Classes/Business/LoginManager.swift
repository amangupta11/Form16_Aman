//  LoginManager.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import SwiftyJSON
class LoginManager: NSObject {
    class func manageLoggedInUserData(jsonString: JSON) {
        PatientManager.updateUserInfoOnLogin(jsonString)
        dispatch_async(dispatch_get_main_queue(), {
            let sessionManager = UIApplication.sharedApplication() as! SessionManager
            sessionManager.resetIdleTimer()
        })
    }
    class func getUserRoleId() -> String {
        let userId = ""
        if let userID = Patient.sharedInfo.userInfo!.roleID{
            return userID
        }
        return userId
    }
}
