//  PatientManager.swift
//  Copyright © 2016 Medtronic. All rights reserved.

import SwiftyJSON
import Foundation
class PatientManager{
    class func clearCache(completion:(successful: Bool) -> Void) {
        if let documentDirectoryPath = FileUtility.getDocumentsDirectoryPath() {
            let path = documentDirectoryPath.stringByAppendingString(ecgFolderPath)
            FileUtility.deleteFileFromPath(path, completion: { (successful) in
                completion(successful:successful)
            })
        }
    }
    
    class func initializePatient(){
        Patient.sharedInfo.patientInfo = nil
        Patient.sharedInfo.patientInfo = PatientCaseInfo()
    }
    class func updateCaseDetailsOnStep1(jsonString: JSON?){
        if let caseID = jsonString?[PatientInfoKey.CaseID.rawValue]{
            Patient.sharedInfo.patientInfo?.caseID = caseID.stringValue
        }
        if let hospitalCaseID = jsonString?[PatientInfoKey.HospitalCaseID.rawValue]{
            Patient.sharedInfo.patientInfo?.hospitalCaseID = hospitalCaseID.stringValue
        }
        if let caseKey = jsonString?[PatientInfoKey.CaseKey.rawValue]{
            Patient.sharedInfo.patientInfo?.caseKey = CryptoUtility.decryptString(caseKey.stringValue)
        }
    }
    
    class func updateCaseDetails(json : JSON?){
        self.updateCaseStatus(json)
        self.updateCaseKey(json)
        self.updatePaymentType(json)
        self.updateAgeInfo(json)
        self.updateGenderInfo(json)
        self.updateCountryCode(json)
        self.updateMobileNumber(json)
        self.updateIcOrPassport(json)
        
        Patient.sharedInfo.patientInfo?.timeLine?.isStemi = false
        let isStemi = json?[TimeLineKey.DiagnosedAsStemi.rawValue].boolValue
        Patient.sharedInfo.patientInfo?.timeLine?.isStemi = isStemi
        
        TimeLineManager.updateCaseTime(json)
        self.updateCitizenShipInfo(json?[PatientInfoKey.CitizenshipType.rawValue]["value"])
        self.updatePatientInfarctInfo(json)
        self.updatePatientVitalSignInfo(json)
        self.updateCitizenShipInfo(json)
        self.updateTreatmentInfo(json)
        if(json?[PatientInfoKey.CathLabReady.rawValue].stringValue != ""){
            Patient.sharedInfo.patientInfo?.isCathLabReady  = json![PatientInfoKey.CathLabReady.rawValue].bool!
        }
    }
}
extension PatientManager{
    class func updatePatientInfoOnFMCDoorOut(jsonString: JSON) {
        Patient.sharedInfo.patientInfo?.caseID = jsonString[PatientInfoKey.CaseID.rawValue].stringValue
        if (jsonString[TimeLineKey.SpokeTransferTime.rawValue] != nil){
            var array = jsonString [TimeLineKey.SpokeTransferTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            Patient.sharedInfo.patientInfo?.timeLine?.spokeTransferTime  = time
        }
        if (jsonString[TimeLineKey.FmcDoorOutTime.rawValue] != nil){
            var array = jsonString [TimeLineKey.FmcDoorOutTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            Patient.sharedInfo.patientInfo?.timeLine?.fmcDoorOutTime  = time
        }
        if (jsonString[TimeLineKey.HubDoorInTime.rawValue] != nil){
            var array = jsonString [TimeLineKey.HubDoorInTime.rawValue][TimeLineKey.TimeLineDetailList.rawValue].array
            var  timeDict =  array![0].dictionary
            let time = timeDict![TimeLineKey.Time.rawValue]?.double
            Patient.sharedInfo.patientInfo?.timeLine?.hubDoorInTime  = time
        }
        if (jsonString["treatmentCenter"] != nil){
            let treatmentCentre = TreatmentCenter()
            treatmentCentre.updateTreamentCenterInfo(jsonString["treatmentCenter"])
            Patient.sharedInfo.patientInfo?.treatmentCenter = treatmentCentre
        }
    }
}
extension PatientManager{
    class func updateCaseStatus(json : JSON?){
        if let caseStatus = json?[PatientInfoKey.CaseStatus.rawValue]{
            if (caseStatus != nil){
                Patient.sharedInfo.patientInfo?.caseStatus = json![PatientInfoKey.CaseStatus.rawValue].intValue
            }
        }
    }
    class func updateCaseKey(json : JSON?){
        if let caseKey = json?[PatientInfoKey.CaseKey.rawValue]{
            if (caseKey != nil){
                Patient.sharedInfo.patientInfo?.caseKey = CryptoUtility.decryptString(caseKey.stringValue)
            }
        }
    }
    class func updatePaymentType(json : JSON?){
        if let paymentType = json?[PatientInfoKey.PaymentType.rawValue]["value"]{
            if (paymentType != nil){
                Patient.sharedInfo.patientInfo?.paymentType = Patient.sharedInfo.patientInfo?.decryptText((Patient.sharedInfo.patientInfo?.caseKey)!, textToDecrypt: paymentType.stringValue)
                Patient.sharedInfo.patientInfo?.paymentTypeID = Patient.sharedInfo.patientInfo?.decryptText((Patient.sharedInfo.patientInfo?.caseKey)!, textToDecrypt: json![PatientInfoKey.PaymentType.rawValue]["id"].stringValue)
            }
        }
    }
    class func updateAgeInfo(json : JSON?){
        if let age = json?[PatientInfoKey.Age.rawValue]{
            if (age != nil){
                Patient.sharedInfo.patientInfo?.age = Patient.sharedInfo.patientInfo?.decryptText((Patient.sharedInfo.patientInfo?.caseKey)!, textToDecrypt: age.stringValue)
            }
        }
    }
    class func updateGenderInfo(json : JSON?){
        if let gender = json?[PatientInfoKey.Gender.rawValue]{
            if (gender != nil){
                Patient.sharedInfo.patientInfo?.gender = Patient.sharedInfo.patientInfo?.decryptText((Patient.sharedInfo.patientInfo?.caseKey)!, textToDecrypt: gender.stringValue)
            }
        }
    }
    class func updateCitizenShipInfo(json : JSON?){
        if let citizenShipValue = json?[PatientInfoKey.CitizenshipType.rawValue]["value"]{
            if (citizenShipValue != nil){
                Patient.sharedInfo.patientInfo?.citizenship = Patient.sharedInfo.patientInfo?.decryptText((Patient.sharedInfo.patientInfo?.caseKey)!, textToDecrypt: citizenShipValue.stringValue)
                Patient.sharedInfo.patientInfo?.citizenshipTypeID = Patient.sharedInfo.patientInfo?.decryptText((Patient.sharedInfo.patientInfo?.caseKey)!, textToDecrypt: json![PatientInfoKey.CitizenshipType.rawValue]["id"].stringValue)
            }
        }
    }
    
    class func updateTreatmentInfo(json : JSON?){
        if let treatmentCenter = json?["treatmentCenter"]{
            if (treatmentCenter != nil){
                let treatmentCtr = TreatmentCenter()
                treatmentCtr.updateTreamentCenterInfo(treatmentCenter)
                Patient.sharedInfo.patientInfo?.treatmentCenter = treatmentCtr
            }
        }
    }
    class func updateCountryCode(json : JSON?){
        if let countryCode = json?[PatientInfoKey.CountryCode.rawValue]{
            if (countryCode != nil){
                Patient.sharedInfo.patientInfo?.countryCode = Patient.sharedInfo.patientInfo?.decryptText((Patient.sharedInfo.patientInfo?.caseKey)!, textToDecrypt: countryCode.stringValue)
            }
        }
    }
    class func updateMobileNumber(json : JSON?){
        if let mobileNumber = json?[PatientInfoKey.MobileNumber.rawValue]{
            if (mobileNumber != nil){
                Patient.sharedInfo.patientInfo?.mobileNumber = Patient.sharedInfo.patientInfo?.decryptText((Patient.sharedInfo.patientInfo?.caseKey)!, textToDecrypt: mobileNumber.stringValue)
            }
        }
    }
    class func updateIcOrPassport(json : JSON?){
        if let icNoOrPassport = json?[PatientInfoKey.ICOrPassport.rawValue]{
            if (icNoOrPassport != nil){
                Patient.sharedInfo.patientInfo?.icNoOrPassport = Patient.sharedInfo.patientInfo?.decryptText((Patient.sharedInfo.patientInfo?.caseKey)!, textToDecrypt: icNoOrPassport.stringValue)
            }
        }
    }
}

extension PatientManager{
    class func updatePatientVitalSignInfo(json: JSON?){
        let encryptedCaseKey = json?[PatientInfoKey.CaseKey.rawValue].stringValue
        if (encryptedCaseKey != nil && encryptedCaseKey != "") {
            let caseKey = CryptoUtility.decryptString(encryptedCaseKey)
            if (caseKey != "") {
                if (json?[PatientHistoryInfoKey.VitalSigns.rawValue].array != nil) {
                    
                    let dictJson = json?[PatientHistoryInfoKey.VitalSigns.rawValue].array?.first
                    Patient.sharedInfo.patientInfo?.patientHistory?.systolic = AESWrapper.decryptTheText(String(dictJson! [PatientHistoryInfoKey.Systolic.rawValue].stringValue), key: caseKey!)
                    Patient.sharedInfo.patientInfo?.patientHistory?.diastolic = AESWrapper.decryptTheText(String(dictJson![PatientHistoryInfoKey.Diastolic.rawValue].stringValue), key: caseKey!)
                    Patient.sharedInfo.patientInfo?.patientHistory?.pulse = AESWrapper.decryptTheText(String(dictJson![PatientHistoryInfoKey.Pulse.rawValue].stringValue), key: caseKey!)
                    Patient.sharedInfo.patientInfo?.patientHistory?.temperature = AESWrapper.decryptTheText(String(dictJson![PatientHistoryInfoKey.Temperature.rawValue].stringValue), key: caseKey!)
                    Patient.sharedInfo.patientInfo?.patientHistory?.spo2 = AESWrapper.decryptTheText(String(dictJson![PatientHistoryInfoKey.Spo2.rawValue].stringValue), key: caseKey!)
                    let killip  = AESWrapper.decryptTheText(String(dictJson![PatientHistoryInfoKey.KillipScore.rawValue].stringValue), key: caseKey!)
                    Patient.sharedInfo.patientInfo?.patientHistory?.killipScore = Int(killip)
                }
            }
        }
    }
    
    class func updatePatientInfarctInfo(json: JSON?){
        let encryptedCaseKey = json?[PatientInfoKey.CaseKey.rawValue].stringValue
        if (encryptedCaseKey != nil && encryptedCaseKey != "") {
            let caseKey = CryptoUtility.decryptString(encryptedCaseKey)
            if (caseKey != "") {
                if (json?[PatientHistoryInfoKey.InfarctArea.rawValue].array != nil) {
                    let dictJson = json?[PatientHistoryInfoKey.InfarctArea.rawValue].array?.first
                    Patient.sharedInfo.patientInfo?.ecgInfo?.ecgFileName =  AESWrapper.decryptTheText(dictJson![ECGInfoKey.EcgName.rawValue].stringValue, key: caseKey!)
                    Patient.sharedInfo.patientInfo?.ecgInfo?.ecgURL =  AESWrapper.decryptTheText(dictJson![ECGInfoKey.EcgURL.rawValue].stringValue, key: caseKey!)
                    
                    let anteroseptal = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.Anteroseptal.rawValue].stringValue, key: caseKey!)
                    Patient.sharedInfo.patientInfo?.patientHistory?.anteroseptal = false
                    if (anteroseptal == "true") {
                        Patient.sharedInfo.patientInfo?.patientHistory?.anteroseptal = true
                    }
                    let anterior = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.Anterior.rawValue].stringValue, key: caseKey!)
                    Patient.sharedInfo.patientInfo?.patientHistory?.anterior = false
                    if (anterior == "true") {
                        Patient.sharedInfo.patientInfo?.patientHistory?.anterior = true
                    }
                    
                    let lateral = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.Lateral.rawValue].stringValue, key: caseKey!)
                    Patient.sharedInfo.patientInfo?.patientHistory?.lateral = false
                    if (lateral == "true") {
                        Patient.sharedInfo.patientInfo?.patientHistory?.lateral = true
                    }
                    
                    let extensiveanterolateral = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.ExtensiveAnterolateral.rawValue].stringValue, key: caseKey!)
                    Patient.sharedInfo.patientInfo?.patientHistory?.extensiveanterolateral = false
                    if (extensiveanterolateral == "true") {
                        Patient.sharedInfo.patientInfo?.patientHistory?.extensiveanterolateral = true
                    }
                    
                    let inferior = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.Inferior.rawValue].stringValue, key: caseKey!)
                    Patient.sharedInfo.patientInfo?.patientHistory?.inferior = false
                    if (inferior == "true") {
                        Patient.sharedInfo.patientInfo?.patientHistory?.inferior = true
                    }
                    
                    let posterior = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.Posterior.rawValue].stringValue, key: caseKey!)
                    Patient.sharedInfo.patientInfo?.patientHistory?.posterior = false
                    if (posterior == "true") {
                        Patient.sharedInfo.patientInfo?.patientHistory?.posterior = true
                    }
                    let rightsided = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.RightSided.rawValue].stringValue, key: caseKey!)
                    Patient.sharedInfo.patientInfo?.patientHistory?.rightsided = false
                    if (rightsided == "true") {
                        Patient.sharedInfo.patientInfo?.patientHistory?.rightsided = true
                    }
                    
                    let leftMainStem = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.LeftMainStem.rawValue].stringValue, key: caseKey!)
                    Patient.sharedInfo.patientInfo?.patientHistory?.leftmainstem = false
                    if (leftMainStem == "true") {
                        Patient.sharedInfo.patientInfo?.patientHistory?.leftmainstem = true
                    }
                    
                    let others = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.Others.rawValue].stringValue, key: caseKey!)
                    Patient.sharedInfo.patientInfo?.patientHistory?.others = false
                    if (others == "true") {
                        Patient.sharedInfo.patientInfo?.patientHistory?.others = true
                    }
                    if (dictJson![PatientHistoryInfoKey.Comments.rawValue].stringValue != "") {
                        Patient.sharedInfo.patientInfo?.patientHistory?.otherscomments = AESWrapper.decryptTheText(dictJson![PatientHistoryInfoKey.Comments.rawValue].stringValue, key: caseKey!)
                    }
                }
            }
        }
    }
}

extension PatientManager{
    class func updateUserInfoOnLogin(json: JSON){
        Patient.sharedInfo.userInfo?.roleID  =  json[UserInfoKey.RoleID.rawValue].stringValue
        Patient.sharedInfo.userInfo?.userID  =  json[UserInfoKey.UserID.rawValue].stringValue
        Patient.sharedInfo.userInfo?.hospitalID  =  json[UserInfoKey.HospitalID.rawValue].stringValue
        Patient.sharedInfo.userInfo?.hospitalTypeID  =  json[UserInfoKey.HospitalTypeID.rawValue].stringValue
        Patient.sharedInfo.userInfo?.passcode =  json[UserInfoKey.Passcode.rawValue].numberValue
        Patient.sharedInfo.userInfo!.uuID =  json[UserInfoKey.UUID.rawValue].stringValue
        Patient.sharedInfo.userInfo!.accessToken = json[StringConstants.oAuthResponse][StringConstants.AccessToken].stringValue
        var tokenType  = json[StringConstants.oAuthResponse][StringConstants.TokenType].stringValue
        tokenType = tokenType.stringByAppendingString(" \(Patient.sharedInfo.userInfo!.accessToken!)")
        Patient.sharedInfo.userInfo!.accessToken = tokenType
        Patient.sharedInfo.userInfo!.refreshToken = json[StringConstants.oAuthResponse][StringConstants.refreshToken].stringValue
        Patient.sharedInfo.userInfo!.expiresIn = json[StringConstants.oAuthResponse][StringConstants.ExpiresIn].stringValue
    }
    
    class func updateDetailProfile(json: JSON){
        Patient.sharedInfo.userInfo?.emailAddress  =  json[UserInfoKey.EmailAddress.rawValue].stringValue
        Patient.sharedInfo.userInfo?.firstName  =  json[UserInfoKey.FirstName.rawValue].stringValue
        Patient.sharedInfo.userInfo?.hospitalName  =  json[UserInfoKey.HospitalName.rawValue].stringValue
        Patient.sharedInfo.userInfo?.hospitalID  =  json[UserInfoKey.HospitalID.rawValue].stringValue
        Patient.sharedInfo.userInfo?.hospitalTypeID  =  json[UserInfoKey.HospitalTypeID.rawValue].stringValue
        Patient.sharedInfo.userInfo?.lastName  =  json[UserInfoKey.LastName.rawValue].stringValue
        Patient.sharedInfo.userInfo?.phoneNumber  =  json[UserInfoKey.PhoneNumber.rawValue].stringValue
        Patient.sharedInfo.userInfo?.title  =  json[UserInfoKey.Title.rawValue].stringValue
        Patient.sharedInfo.userInfo?.gender  =  json[UserInfoKey.Gender.rawValue].stringValue
        Patient.sharedInfo.userInfo?.profilePicURL  =  json[UserInfoKey.ProfilePicURL.rawValue].stringValue
        Patient.sharedInfo.userInfo?.countryCode  =  json[UserInfoKey.CountryCode.rawValue].stringValue
        Patient.sharedInfo.userInfo?.designation  =  json[UserInfoKey.Designation.rawValue].stringValue
        Patient.sharedInfo.userInfo?.userID  =  json[UserInfoKey.UserID.rawValue].stringValue
    }
}